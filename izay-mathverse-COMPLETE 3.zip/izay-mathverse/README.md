# Izay MathVerse

**Professional Mathematics Learning Management System**
*Learn • Practice • Master Mathematics*

A database-driven, school-independent LMS built with Next.js 14, PostgreSQL,
and Prisma. See `docs/MASTER_BUILD_PROMPT.md` for the full specification this
build follows, and `docs/PHASE_LOG.md` for what's been built so far.

---

## Core principle

**The educational content is data, not code.** Courses, curriculum, lessons,
questions, quizzes — all live in the database and are managed from the
dashboard. Nothing school-specific or subject-specific is hard-coded into
the application.

---

## Tech stack

| Layer | Choice |
|---|---|
| Framework | Next.js 14 (App Router, TypeScript) |
| Database | PostgreSQL |
| ORM | Prisma |
| Auth | NextAuth.js (credentials + bcrypt, JWT sessions) |
| Styling | Tailwind CSS |
| Math rendering | KaTeX *(added in Phase 3, when lesson content lands)* |

---

## Getting started (local development)

### 1. Prerequisites
- Node.js ≥ 18.18
- A PostgreSQL database (local install, or a free hosted instance — e.g.
  [Neon](https://neon.tech) or [Supabase](https://supabase.com))

### 2. Install dependencies
```bash
npm install
```
This project's dependencies could not be installed or build-verified in the
sandbox that generated this code (no network access there) — please run
`npm install` and `npm run build` yourself as the first step, and report
back any errors so they can be fixed.

### 3. Configure environment
```bash
cp .env.example .env
```
Edit `.env` and set:
- `DATABASE_URL` — your PostgreSQL connection string
- `NEXTAUTH_SECRET` — generate with `openssl rand -base64 32`
- `NEXTAUTH_URL` — `http://localhost:3000` for local dev

### 4. Set up the database
```bash
npm run db:migrate            # creates tables from prisma/schema.prisma
npm run db:seed               # seeds a demo organization + one user per role + the two courses
npm run db:seed:curriculum    # seeds the SHS 1-3 curriculum structure + one verified content sample
```

### 5. Run the app
```bash
npm run dev
```
Visit `http://localhost:3000`.

### 6. Sign in
The seed script creates one account per role (password for all: `Password123!`):

| Role | Email |
|---|---|
| Super Admin (platform owner) | `owner@izaymathverse.example` |
| Admin (school-level) | `admin@demoshs.example` |
| Teacher | `teacher@demoshs.example` |
| Student | `student@demoshs.example` |

**Change these passwords / remove these accounts before any real deployment.**

---

## What's implemented (Phase 1 — Foundation)

- Full relational schema for every entity in the spec (57 Prisma models)
- Authentication (NextAuth, bcrypt-hashed passwords, JWT sessions)
- Role-based authorization enforced **on the backend** (`requireRole()` in
  every server action / route handler) — middleware is a UX convenience
  only, never the security boundary
- School-independent Organization model, with admin CRUD
- Academic Year / Term / Class scaffolding
- The two initial courses (Additional Mathematics — Available, Core
  Mathematics — Restricted) with a real, database-backed status toggle an
  admin can flip with no code change or redeploy
- The exact Core Mathematics locked-page experience from the spec
- Three role dashboards (Admin / Teacher / Student) with honest "not built
  yet" notices instead of dead buttons — nothing in the UI claims to do
  something it can't
- Audit logging wired into authentication and every admin mutation

## What's implemented (Phase 2 — Course and Curriculum)

- Full curriculum hierarchy: Course → Academic Level (SHS 1/2/3) → Strand →
  Sub-Strand → Topic → Content Standard → Learning Outcome / Learning
  Indicator → Activity / Assessment Note
- Curriculum browsing UI, shared by Admin and Teacher, matching the exact
  drill-down flow from spec §14
- Curriculum import: submit → **Import Preview** screen → Confirm/Reject
  (spec §46) — nothing reaches the live curriculum unreviewed
- Curriculum versioning (`CurriculumVersion`) so re-imports never destroy
  history (spec §47)
- The complete SHS 1–3 strand/sub-strand structure, verified against the
  curriculum document, plus one fully-verified deep-content example (see
  `docs/PHASE_LOG.md` for exactly what's transcribed vs. still pending)

## What's implemented (Phase 3 — Learning Content)

- Full lesson editor (title, objective, introduction, definitions,
  explanation, examples, real-life applications, formulae, notes) with
  Save Draft / Preview / Publish / Archive
- Math rendering via KaTeX — write `$inline$` or `$$display$$` LaTeX in any
  lesson text field
- Lesson reordering within a topic (real, persisted, database-backed)
- Images/diagrams/graphs, videos (YouTube auto-embed), GeoGebra & Desmos
  activities (auto-embed when the URL is from that provider, otherwise an
  "Open in ..." link), learning materials, and external resources — all
  attachable to a lesson
- Student-facing curriculum browsing (Course → Level → Strand → Sub-Strand →
  Topic → Lesson) and a lesson viewer, both enforcing course availability
  and lesson publication status **on the backend** — a restricted course or
  an unpublished lesson never renders, even via a direct URL guess

## What's implemented (Phase 4 — Question Bank)

- Full question CRUD: create, edit, duplicate, delete, archive/restore
- Search and filter by text, course, type, difficulty, status
- All 7 question types from spec §26, with type-appropriate editor UI
  (answer options for Multiple Choice/True-False; free-text correct
  answer + accepted-equivalents list for the rest)
- Multiple ordered Hints per question
- A Solution per question with an exam-time visibility toggle (off by
  default, per spec §30)
- Attaching bank questions to a Lesson's Practice Questions section —
  visible to students on published lessons (read-only for now; actual
  student answering/grading is Phase 5)
- A question preview that never leaks the correct answer or an
  exam-restricted solution

## What's implemented (Phase 5 — Practice Engine)

- Practice sessions scoped to a course and optionally a topic, in 4 modes
  (Learn & Practice, Quick Practice, Challenge Mode, Exam Mode)
- Automatic grading for Multiple Choice, True/False, Numerical (with
  floating-point tolerance), Short Answer, and Algebraic Expression —
  Structured/Diagram-Image questions are correctly routed to "pending
  manual review" instead of a fake auto-grade
- Real per-topic student progress, computed only from actual practice
  attempts
- Weak-topic detection (< 70% flagged "Needs Practice") with working
  Review Lesson / Practice Questions actions

## What's implemented (Phase 6 — Quizzes)

- Full quiz settings: question pool, random selection, question/option
  shuffling, timer/duration, attempt limits, open/close dates, hints and
  solutions toggles, configurable result visibility
- Question-set snapshotting — a submitted attempt's questions, order, and
  option order are frozen at start time and never change even if the
  underlying Question is later edited or deleted (spec §35)
- A real countdown timer, submit confirmation, attempt-limit enforcement,
  and automatic grading reusing the Phase 5 grading logic
- Student quiz list, detail/start page, attempt-taking flow, and a result
  page that honors the quiz's configured visibility rule

**Tests** share the exact same mechanism as Quizzes per the spec (§32–36
describe one pool→randomize→snapshot→grade pipeline) — the `Test` schema
exists from Phase 1, but a separate Test UI is deferred rather than
built as a shallow duplicate; see `docs/PHASE_LOG.md` for the reasoning
and what reusing `quizzes.ts` for it would look like.

## What's implemented (Phase 7 — Assignments and Results)

- Assignment creation with attachments, student submission (text and/or a
  file link) with automatic Late detection, and teacher marking with
  feedback and a controlled "return to student" step
- A shared grade-boundary lookup (`src/lib/grade-lookup.ts`) used by both
  Quiz results (Phase 6) and Assignment marking, so `/student/results`
  reflects both — no GPA, configurable boundaries, per spec §38

## What's implemented (Phase 8 — Analytics)

- Teacher/Admin analytics dashboard (`/analytics`) — lesson and question
  status breakdowns, quiz activity and average score, assignment
  submission stats, and class-wide topic performance, all computed live
  from the database, none simulated
- Curriculum Completeness dashboard (§48, `/curriculum/completeness`) —
  shows real Learning Indicator coverage by Lessons, Practice questions,
  and Quiz-pool inclusion; deliberately deferred until this phase since it
  had no real data to report on any earlier

## What's implemented (Phase 9 — Additional Features)

- **Class management** (`/admin/classes`) — the roster foundation that
  Attendance and Timetable depend on; this was a gap since Phase 1 despite
  the schema already having it
- Attendance, Timetable (Today/Tomorrow/Week), Announcements with real
  audience targeting, Notifications (announcement-triggered, with
  read/unread), WASSCE Preparation resources, a consolidated Downloads
  view, and database-backed Search
- Achievements — admin can create/enable/disable and manually award; there
  is deliberately no automatic-unlock detection (see `docs/PHASE_LOG.md`)

## What's implemented (Phase 10 — Security and Production)

- Server-side exam-timer enforcement (closes a gap flagged in Phase 6)
- Login brute-force lockout (5 failed attempts / 15 minutes)
- Security headers (`next.config.js`)
- `zod`-based structured input validation, starting with user creation as
  the reference pattern
- `docs/SECURITY.md` — full honest security posture: implemented,
  partial, and explicitly-not-done, plus backup/recovery guidance
- `docs/DEPLOYMENT.md` — environment setup, deploy steps, post-deploy
  checks

## Project status

All 10 phases from the master build prompt have been delivered. See
`docs/PHASE_LOG.md` for the complete phase-by-phase breakdown, including
every deliberately-deferred item and the reasoning for each. The two
highest-priority items before any real deployment:

1. **Run `npm install && npm run build`** — this codebase was written
   without network access to actually execute or compile it. It's been
   checked for internal consistency (schema/action/import alignment,
   brace balance, zero dead code) but never run.
2. **Real file storage** — every material, video, and image is currently
   a pasted URL rather than an upload, by design (spec §64: no pretend
   features) rather than oversight. See `docs/SECURITY.md` for what to
   add before wiring up uploads.

---

## Project structure

```
prisma/
  schema.prisma       Full database schema
  seed.ts              Foundation seed data
src/
  app/
    admin/             Admin dashboard, organizations, courses, users
    teacher/           Teacher dashboard
    student/           Student dashboard, course pages
    login/             Sign-in page
    api/auth/          NextAuth route handler
  lib/
    actions/           Server actions (organizations, courses, users)
    auth.ts            NextAuth configuration
    rbac.ts             requireRole() / getSessionUser() — backend authorization
    audit.ts            Audit log helper
    password.ts          bcrypt hashing
    prisma.ts            Prisma client singleton
  components/          Shared UI (dashboard shell, roadmap note, etc.)
  middleware.ts         Route-level auth gate (UX layer, not the security boundary)
```

---

## Deployment notes

- Any Next.js-compatible host works (Vercel, Render, Railway, a VPS with
  Node + PM2, etc.).
- Run `npm run db:deploy` (applies migrations without prompting) as part of
  your deploy pipeline, then `npm run build` and `npm start`.
- File storage (for uploads — lesson materials, images, videos, logos) is
  **not configured yet**. It's referenced in the schema (`fileUrl` fields)
  but no storage provider is wired up — that's explicit per spec §64 ("do
  not pretend an upload system exists unless actual file storage has been
  configured"). This will be addressed when Phase 3 (Learning Content)
  needs it — likely an S3-compatible bucket.
