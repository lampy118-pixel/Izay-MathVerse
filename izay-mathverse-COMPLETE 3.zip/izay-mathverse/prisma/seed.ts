/**
 * Seed script — Phase 1 foundation data only.
 *
 * Creates:
 *  - One sample Organization (schools are data, not code — see spec §4)
 *  - One user per role, so you can sign in and see each dashboard
 *  - The two Mathematics courses from spec §5, with correct initial status
 *  - Default grade boundaries (spec §38 — configurable, no GPA)
 *
 * Full curriculum import (SHS 1–3 strands/sub-strands/topics/learning
 * indicators from the Additional Mathematics curriculum document) is a
 * Phase 2 deliverable — intentionally not included here.
 *
 * Run with: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/password";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding Izay MathVerse foundation data...");

  const org = await prisma.organization.upsert({
    where: { slug: "demo-shs" },
    update: {},
    create: {
      name: "Demo Senior High School",
      slug: "demo-shs",
      type: "SCHOOL",
      contactEmail: "info@demoshs.example",
    },
  });

  const academicYear = await prisma.academicYear.upsert({
    where: { id: "seed-academic-year" },
    update: {},
    create: {
      id: "seed-academic-year",
      organizationId: org.id,
      name: "2025/2026",
      startDate: new Date("2025-09-01"),
      endDate: new Date("2026-07-31"),
      isCurrent: true,
    },
  });

  await prisma.term.upsert({
    where: { id: "seed-term-1" },
    update: {},
    create: {
      id: "seed-term-1",
      academicYearId: academicYear.id,
      name: "Term 1",
      startDate: new Date("2025-09-01"),
      endDate: new Date("2025-12-12"),
      isCurrent: true,
    },
  });

  const defaultPassword = await hashPassword("Password123!");

  const [superAdmin, admin, teacher, student] = await Promise.all([
    prisma.user.upsert({
      where: { email: "owner@izaymathverse.example" },
      update: {},
      create: {
        email: "owner@izaymathverse.example",
        passwordHash: defaultPassword,
        firstName: "Platform",
        lastName: "Owner",
        role: "SUPER_ADMIN",
      },
    }),
    prisma.user.upsert({
      where: { email: "admin@demoshs.example" },
      update: {},
      create: {
        email: "admin@demoshs.example",
        passwordHash: defaultPassword,
        firstName: "Ama",
        lastName: "Administrator",
        role: "ADMIN",
        organizationId: org.id,
      },
    }),
    prisma.user.upsert({
      where: { email: "teacher@demoshs.example" },
      update: {},
      create: {
        email: "teacher@demoshs.example",
        passwordHash: defaultPassword,
        firstName: "Kwame",
        lastName: "Mensah",
        role: "TEACHER",
        organizationId: org.id,
        teacherProfile: { create: { staffNumber: "T-0001" } },
      },
    }),
    prisma.user.upsert({
      where: { email: "student@demoshs.example" },
      update: {},
      create: {
        email: "student@demoshs.example",
        passwordHash: defaultPassword,
        firstName: "Efua",
        lastName: "Owusu",
        role: "STUDENT",
        organizationId: org.id,
        studentProfile: { create: { admissionNumber: "S-0001" } },
      },
    }),
  ]);

  // --- The two courses, per spec §5 ---
  await prisma.course.upsert({
    where: { slug: "additional-mathematics" },
    update: {},
    create: {
      name: "Additional Mathematics",
      slug: "additional-mathematics",
      description:
        "SHS 1–3 Additional Mathematics — NaCCA curriculum (Sept 2023).",
      status: "AVAILABLE",
    },
  });

  await prisma.course.upsert({
    where: { slug: "core-mathematics" },
    update: {},
    create: {
      name: "Core Mathematics",
      slug: "core-mathematics",
      description: "SHS 1–3 Core Mathematics.",
      status: "RESTRICTED",
      lockedMessage:
        "The Core Mathematics curriculum and learning materials are currently being prepared. Please check back later.",
    },
  });

  // --- Default grade boundaries (spec §38, configurable, no GPA) ---
  const gradeBoundaries = [
    { label: "A1", minPercentage: 80, maxPercentage: 100, remark: "Excellent" },
    { label: "B2", minPercentage: 75, maxPercentage: 79.99, remark: "Very Good" },
    { label: "B3", minPercentage: 70, maxPercentage: 74.99, remark: "Good" },
    { label: "C4", minPercentage: 60, maxPercentage: 69.99, remark: "Credit" },
    { label: "C5", minPercentage: 55, maxPercentage: 59.99, remark: "Credit" },
    { label: "C6", minPercentage: 50, maxPercentage: 54.99, remark: "Credit" },
    { label: "D7", minPercentage: 45, maxPercentage: 49.99, remark: "Pass" },
    { label: "E8", minPercentage: 40, maxPercentage: 44.99, remark: "Pass" },
    { label: "F9", minPercentage: 0, maxPercentage: 39.99, remark: "Fail" },
  ];
  for (const g of gradeBoundaries) {
    const existing = await prisma.grade.findFirst({ where: { label: g.label } });
    if (!existing) {
      await prisma.grade.create({ data: g });
    }
  }

  console.log("Seed complete.");
  console.log("----------------------------------------------------");
  console.log("Sign in with any of these (password: Password123!):");
  console.log(` Super Admin: ${superAdmin.email}`);
  console.log(` Admin:       ${admin.email}`);
  console.log(` Teacher:     ${teacher.email}`);
  console.log(` Student:     ${student.email}`);
  console.log("----------------------------------------------------");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
