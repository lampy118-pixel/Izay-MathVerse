/**
 * Curriculum seed — Phase 2.
 *
 * IMPORTANT — what is and isn't in here:
 *
 *  (a) STRUCTURAL DATA (every Strand and Sub-Strand name/code for SHS 1, 2,
 *      and 3) is complete and verified directly against the curriculum
 *      document's own "Scope and Sequence" summary table (page 22) —
 *      cross-checked strand-by-strand against the document's table of
 *      contents and in-document section headers. This part covers the full
 *      three-year structure.
 *
 *  (b) DEEP CONTENT (actual Content Standard / Learning Outcome / Learning
 *      Indicator / Activity / Assessment text) is seeded in full, verified
 *      detail for ONE topic — Year 1, Strand 1 "Modelling with Algebra",
 *      Sub-Strand 1 "Number and Algebraic Patterns", Topic "Binary
 *      Operations, Sets and Binomial Theorem" (Content Standard 1.1.1.CS.1) —
 *      transcribed and cross-checked directly against curriculum document
 *      pages 24–38.
 *
 * The curriculum document runs 500+ pages with dense, multi-column tables
 * (including recurring 21st-Century-Skills/GESI/SEL narrative blocks that
 * repeat, nearly verbatim, under every single Learning Outcome). Extracting
 * the remaining ~60 Learning Outcomes and ~175 Learning Indicators at the
 * same verified accuracy is a large, ongoing transcription task — continuing
 * it page-by-page (rather than bulk-parsing, which risks silently
 * corrupting mathematical notation and misattributing scrambled table text)
 * is the intended next step, using the Import tool built in this phase
 * (/curriculum/import) so each additional batch goes through the same
 * review screen before it lands in the live curriculum tree.
 *
 * Run with: npm run db:seed:curriculum (after npm run db:seed)
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// ---------------------------------------------------------------------------
// Structural hierarchy — verified against the Scope and Sequence table
// (curriculum document, page 22) and per-year section headers.
// ---------------------------------------------------------------------------

interface SubStrandDef {
  code: string;
  name: string;
}
interface StrandDef {
  code: string;
  name: string;
  subStrands: SubStrandDef[];
}
interface LevelDef {
  code: string;
  name: string;
  strands: StrandDef[];
}

const LEVELS: LevelDef[] = [
  {
    code: "1",
    name: "SHS 1",
    strands: [
      {
        code: "1",
        name: "Modelling with Algebra",
        subStrands: [
          { code: "1", name: "Number and Algebraic Patterns" },
          { code: "2", name: "Applications of Algebra" },
        ],
      },
      {
        code: "2",
        name: "Geometric Reasoning and Measurement",
        subStrands: [
          { code: "1", name: "Spatial Sense" },
          { code: "2", name: "Measurement of Triangles" },
        ],
      },
      {
        code: "3",
        name: "Calculus",
        subStrands: [
          { code: "1", name: "Principles of Calculus" },
          { code: "2", name: "Applications of Calculus" },
        ],
      },
      {
        code: "4",
        name: "Handling Data",
        subStrands: [
          { code: "1", name: "Organising, Representing and Interpreting Data" },
          { code: "2", name: "Making Predictions with Data" },
        ],
      },
    ],
  },
  {
    code: "2",
    name: "SHS 2",
    strands: [
      {
        code: "1",
        name: "Modelling with Algebra",
        subStrands: [{ code: "1", name: "Application of Algebra" }],
      },
      {
        code: "2",
        name: "Geometric Reasoning and Measurement",
        subStrands: [
          { code: "1", name: "Spatial Sense" },
          { code: "2", name: "Measurement of Triangles" },
        ],
      },
      {
        code: "3",
        name: "Calculus",
        subStrands: [
          { code: "1", name: "Principles of Calculus" },
          { code: "2", name: "Applications of Calculus" },
        ],
      },
      {
        code: "4",
        name: "Handling Data",
        subStrands: [
          { code: "1", name: "Organising, Representing and Interpreting Data" },
          { code: "2", name: "Making Predictions with Data" },
        ],
      },
    ],
  },
  {
    code: "3",
    name: "SHS 3",
    strands: [
      {
        // Year 3 genuinely has no Sub-Strand 1 here — confirmed by the
        // document's own Scope and Sequence table ("–" for Number and
        // Algebraic Patterns in Year 3) and by the in-document code
        // "3.1.2.LO.1" on the first Year 3 Learning Outcome under this
        // strand. This is not an extraction gap.
        code: "1",
        name: "Modelling with Algebra",
        subStrands: [{ code: "2", name: "Applications of Algebra" }],
      },
      {
        code: "2",
        name: "Geometric Reasoning and Measurement",
        subStrands: [
          { code: "1", name: "Spatial Reasoning" },
          { code: "2", name: "Measuring Triangles" },
        ],
      },
      {
        code: "3",
        name: "Calculus",
        subStrands: [
          { code: "1", name: "Principle of Calculus" },
          { code: "2", name: "Application of Calculus" },
        ],
      },
      {
        code: "4",
        name: "Handling Data",
        subStrands: [
          { code: "1", name: "Organising and Representing and Interpreting Data" },
          { code: "2", name: "Making Predictions with Data" },
        ],
      },
    ],
  },
];

async function main() {
  console.log("Seeding curriculum structure for Additional Mathematics...");

  const course = await prisma.course.findUnique({
    where: { slug: "additional-mathematics" },
  });
  if (!course) {
    throw new Error(
      "Additional Mathematics course not found — run `npm run db:seed` first."
    );
  }

  const version = await prisma.curriculumVersion.upsert({
    where: { id: "seed-curriculum-v1" },
    update: {},
    create: {
      id: "seed-curriculum-v1",
      courseId: course.id,
      versionLabel: "Version 1",
      isActive: true,
      sourceDocument: "Additional-Mathematics-Curriculum.pdf (NaCCA, Sept 2023)",
    },
  });

  for (const levelDef of LEVELS) {
    const level = await prisma.academicLevel.upsert({
      where: { courseId_code: { courseId: course.id, code: levelDef.code } },
      update: { name: levelDef.name, curriculumVersionId: version.id },
      create: {
        courseId: course.id,
        curriculumVersionId: version.id,
        name: levelDef.name,
        code: levelDef.code,
        sortOrder: Number(levelDef.code),
      },
    });

    for (const [sIdx, strandDef] of levelDef.strands.entries()) {
      let strand = await prisma.strand.findFirst({
        where: { academicLevelId: level.id, code: strandDef.code },
      });
      if (!strand) {
        strand = await prisma.strand.create({
          data: {
            academicLevelId: level.id,
            name: strandDef.name,
            code: strandDef.code,
            sortOrder: sIdx,
          },
        });
      }

      for (const [ssIdx, subStrandDef] of strandDef.subStrands.entries()) {
        const existingSub = await prisma.subStrand.findFirst({
          where: { strandId: strand.id, code: subStrandDef.code },
        });
        if (!existingSub) {
          await prisma.subStrand.create({
            data: {
              strandId: strand.id,
              name: subStrandDef.name,
              code: subStrandDef.code,
              sortOrder: ssIdx,
            },
          });
        }
      }
    }
    console.log(`  ${levelDef.name}: ${levelDef.strands.length} strands seeded.`);
  }

  // ---------------------------------------------------------------------
  // Deep, verified content sample: Year 1 > Strand 1 > Sub-Strand 1 >
  // "Binary Operations, Sets and Binomial Theorem" (Content Standard 1)
  // Transcribed from curriculum document pages 24–38.
  // ---------------------------------------------------------------------

  const y1 = await prisma.academicLevel.findFirstOrThrow({
    where: { courseId: course.id, code: "1" },
  });
  const strand1 = await prisma.strand.findFirstOrThrow({
    where: { academicLevelId: y1.id, code: "1" },
  });
  const subStrand1 = await prisma.subStrand.findFirstOrThrow({
    where: { strandId: strand1.id, code: "1" },
  });

  const topic = await prisma.topic.upsert({
    where: { id: "seed-topic-1-1-1-cs1" },
    update: {},
    create: {
      id: "seed-topic-1-1-1-cs1",
      subStrandId: subStrand1.id,
      name: "Binary Operations, Sets and Binomial Theorem",
      sortOrder: 0,
    },
  });

  // Learning Outcomes (statements verified verbatim from source; the
  // extensive repeated 21st-Century-Skills/GESI/SEL narrative that
  // accompanies each one in the document is left for a later pass — see
  // module comment above).
  const learningOutcomes = [
    {
      code: "1.1.1.LO.1",
      statement: "Solve problems involving properties of binary operations.",
    },
    {
      code: "1.1.1.LO.2",
      statement: "Model and solve real life problems on sets.",
    },
    {
      code: "1.1.1.LO.3",
      statement:
        "Expand binomials with positive integral indices and simplify coefficients of the terms.",
    },
    {
      code: "1.1.1.LO.4",
      statement:
        "Perform basic operations on surds as well as solve simple indicial and logarithmic equations.",
    },
  ];

  for (const [i, lo] of learningOutcomes.entries()) {
    await prisma.learningOutcome.upsert({
      where: { id: `seed-${lo.code}` },
      update: {},
      create: {
        id: `seed-${lo.code}`,
        topicId: topic.id,
        code: lo.code,
        statement: lo.statement,
        sortOrder: i,
      },
    });
  }

  const cs1 = await prisma.contentStandard.upsert({
    where: { id: "seed-1.1.1.CS.1" },
    update: {},
    create: {
      id: "seed-1.1.1.CS.1",
      topicId: topic.id,
      code: "1.1.1.CS.1",
      statement:
        "Demonstrate knowledge and understanding of binary operations, sets and binomial theorem and solve related problems in real life situations.",
      sortOrder: 0,
    },
  });

  const li1 = await prisma.learningIndicator.upsert({
    where: { id: "seed-1.1.1.LI.1" },
    update: {},
    create: {
      id: "seed-1.1.1.LI.1",
      contentStandardId: cs1.id,
      code: "1.1.1.LI.1",
      statement:
        "Explain binary operations and apply that knowledge in solving related problems.",
      pedagogicalApproach:
        "Collaborative Learning: Learners will work in convenient groups (ability, mixed-ability, mixed gender, or pairs etc.) to identify and define binary operations over given sets and solve related problems. Talk for Learning Approaches: Learners will brainstorm by way of think-pair-share/square and debate on sets defined by binary operations and establish the rules for such binary operations. Experiential Learning: Learners will collaboratively engage in hands-on activity (learning by doing) to create binary operations, define them over sets and solve related problems.",
      sortOrder: 0,
    },
  });

  await prisma.activity.upsert({
    where: { id: "seed-1.1.1.LI.1.activity.1" },
    update: {},
    create: {
      id: "seed-1.1.1.LI.1.activity.1",
      learningIndicatorId: li1.id,
      title: "Activity 1: Define and interpret Binary Operations as a rule",
      description:
        "Use Talk for Learning Approaches (building on what others say, managing Talk for Learning, structuring Talk for Learning), collaborative learning approaches and experiential learning approaches to recall the four basic operations and use them to define a binary operation.\n\nSmall group discussions/Think-pair-share: Learners in small convenient groups (for instance, mixed gender, mixed-ability, etc.) examine binary operations and recognise that binary operations are rules that combine elements from a non-empty set R to produce another element.\n\nExample: Suppose the operation * is defined on the set of real numbers ℝ by a * b = a + b − 2ab.\n• Find 4 * 2\n• Find ½ * −2\n• If a * 4 = −2, find the value of a.\n\nInter-group competition: Learners from one group devise their own binary operations for another group to examine and interpret the rule. Groups switch roles.\n\nWork with a partner: Construct tables for a given binary operation.\nExample: A binary operation is defined on the set S = {2, 3, 4, 5} by p ⊕ q = p + q − pq where p and q ∈ S.\n• Construct the table for the operation on the set S.\n• Use your table to evaluate (2 ⊕ 3) ⊕ 3\n• Given that m ⊗ n = (m + n)/(mn), evaluate (2 ⊗ 3) + (3 ⊗ 2)",
      sortOrder: 0,
    },
  });

  await prisma.activity.upsert({
    where: { id: "seed-1.1.1.LI.1.activity.2" },
    update: {},
    create: {
      id: "seed-1.1.1.LI.1.activity.2",
      learningIndicatorId: li1.id,
      title: "Activity 2: Discuss the history and relevance of learning binary operations.",
      description:
        "Learners research and discuss, in groups, the historical origins of binary operations and why the concept is relevant to real-life problem solving.",
      sortOrder: 1,
    },
  });

  await prisma.assessmentNote.upsert({
    where: { id: "seed-1.1.1.AS.1" },
    update: {},
    create: {
      id: "seed-1.1.1.AS.1",
      learningIndicatorId: li1.id,
      code: "1.1.1.AS.1",
      dokLevel: 1,
      dokLabel: "Recall",
      sampleItem:
        "The operation * is defined on the set of real numbers ℝ by p * q = 2p + q − 2pq.\n(a) Find (i) 3 * −2  (ii) 3 * 5\n(b) If p * 4 = −2, find the value of p.",
    },
  });

  console.log(
    "  Verified deep-content sample seeded: Y1 > Strand 1 > Sub-Strand 1 > Binary Operations, Sets and Binomial Theorem (CS.1 / LI.1 / 2 activities / AS.1)."
  );
  console.log("Curriculum seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
