# Deployment Checklist

## Quick start — GitHub

1. Unzip the project, then from inside the `izay-mathverse` folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
   `.gitignore` already excludes `node_modules`, `.next`, and `.env` — you
   won't accidentally commit secrets or build output.

## Quick start — Netlify

Netlify doesn't run a database itself, so you need an external Postgres
first (see "Recommended hosting" below — Neon or Supabase both have free
tiers that work fine for this).

1. Push the repo to GitHub (above), then in Netlify: **Add new site →
   Import an existing project** and pick the repo.
2. Netlify should auto-detect `netlify.toml` (already included) and use
   the `@netlify/plugin-nextjs` build plugin — no manual build
   configuration needed.
3. In **Site settings → Environment variables**, add `DATABASE_URL`,
   `NEXTAUTH_SECRET`, and `NEXTAUTH_URL` (set this to your Netlify site's
   real `https://` URL once you know it — you may need to deploy once,
   then set this and redeploy).
4. Run `npm run db:deploy` and `npm run db:seed` against your production
   `DATABASE_URL` from your own machine (or a one-off script) before the
   first real use, since Netlify's build step doesn't run migrations for
   you automatically.

## Before you deploy anywhere

1. Run `npm install` and `npm run build` locally — this was never verified
   in the sandbox that generated this code (no network access there). Fix
   any TypeScript/build errors that surface; the code has been reviewed
   for internal consistency (schema fields, server-action exports, brace
   balance) but never compiled.
2. Read `docs/SECURITY.md` in full — several items there should be
   resolved before real students use this.
3. Change or remove the seeded demo accounts
   (`owner@izaymathverse.example` etc.) — see `prisma/seed.ts`.
4. Generate a real `NEXTAUTH_SECRET`: `openssl rand -base64 32`.

## Recommended hosting

Any Next.js-compatible platform works:
- **Vercel** — simplest path for a Next.js app; pair with **Neon** or
  **Supabase** for managed Postgres.
- **Render / Railway** — good if you want the app and database on one
  platform.
- **Self-hosted (VPS + PM2/Docker + your own Postgres)** — more control,
  more of the checklist in `docs/SECURITY.md` becomes your responsibility
  (backups, TLS termination, etc.).

## Environment variables (production)

| Variable | Notes |
|---|---|
| `DATABASE_URL` | Use `sslmode=require` for any remote Postgres |
| `NEXTAUTH_SECRET` | Freshly generated, never reused from `.env.example` |
| `NEXTAUTH_URL` | Must be your real `https://` domain — NextAuth uses this to set secure cookie flags correctly |
| `NEXT_PUBLIC_APP_NAME` | Cosmetic only |

## Deploy steps

```bash
npm ci
npx prisma generate
npm run db:deploy      # applies migrations without interactive prompts
npm run build
npm start               # or your platform's equivalent
```

Do **not** run `npm run db:seed` against a production database unless you
specifically want the demo organization/users/courses created there —
it's meant for local development and demos.

## Post-deploy verification

Run through `docs/PHASE_LOG.md`'s manual test checklists once against the
live deployment — they were written and validated against the local dev
flow, and mobile-viewport / real-network behavior can differ.

Specifically re-verify, in production:
- [ ] Login works and sets a secure, httpOnly cookie (check via browser
      devtools — `Secure` flag requires `NEXTAUTH_URL` to be `https://`)
- [ ] A restricted course's locked page renders correctly for a student
- [ ] File-URL-based materials (videos, lesson materials, WASSCE
      resources) actually load from their external URLs in production
      (no local-only URLs accidentally seeded)
- [ ] The quiz timer's server-side deadline check (`docs/SECURITY.md`)
      behaves correctly under real network latency, not just localhost

## Known gaps to close before scaling beyond a pilot

See `docs/PHASE_LOG.md`'s "Not started" sections across every phase for
the full list. The highest-priority ones for a production rollout:
1. File storage (materials/videos/images are currently URL-only)
2. A dedicated Test UI (currently Quiz-only; Test schema exists unused)
3. Rate limiting beyond login (see `docs/SECURITY.md`)
4. Extending `zod` validation coverage beyond user creation
5. Notification triggers beyond announcements (lesson publish, deadlines, etc.)
