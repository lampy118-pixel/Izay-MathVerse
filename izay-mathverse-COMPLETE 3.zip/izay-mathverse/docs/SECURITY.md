# Security

This document is the honest state of Izay MathVerse's security posture:
what's implemented and verified by reading, what's a real but partial
mitigation, and what's explicitly not done yet. None of this was verified
by running the app (no network access in the sandbox that built it — see
README) — treat this as a code-review-level assessment, not a pen-test
result, and get an independent security review before handling real
student data.

## What's implemented

- **Password storage:** bcrypt, 12 salt rounds (`src/lib/password.ts`).
  Never logged, never stored in plaintext, never included in audit log
  `before`/`after` snapshots.
- **Sessions:** JWT-based (NextAuth), 8-hour expiry. The JWT carries only
  `id`/`role`/`organizationId` — never the password hash.
- **Authorization is backend-enforced everywhere:** every server action
  and route handler calls `requireRole()` (`src/lib/rbac.ts`) before doing
  anything sensitive. Route-level `middleware.ts` is a UX convenience
  (redirects a wrong-role user before a page even renders) — it is
  explicitly documented in this codebase as *not* the security boundary,
  because middleware can be bypassed by calling a server action directly.
- **Per-record ownership checks:** `assertOwnRecord()` guards every place
  a student could otherwise view or act on another student's data
  (practice sessions, quiz attempts, attendance, results). Checked in
  Phases 5–7's manual test checklists.
- **Brute-force login protection (Phase 10):** after 5 failed attempts for
  an account within 15 minutes, further attempts are rejected with a clear
  message. Built on the existing `AuditLog` rather than a new table — see
  the code comment in `src/lib/auth.ts` for the scaling caveat (this
  isn't indexed for high-frequency lockout checks; a dedicated rate-limit
  store is recommended before high traffic).
- **Input validation:** `zod`-schema-validated for user creation
  (`src/lib/validation.ts`) as of Phase 10 — this is the first action
  validated this way and the intended pattern to extend to the rest (see
  "Not done" below).
- **Audit logging:** every login (success/failure), and every admin/staff
  mutation across Organizations, Courses, Users, Curriculum, Lessons,
  Questions, Quizzes, Assignments, Classes, Attendance, Announcements, and
  Achievements, is recorded in `AuditLog` with actor, action, entity,
  and before/after snapshots where relevant (spec §60).
- **Security headers:** `X-Frame-Options`, `X-Content-Type-Options`,
  `Referrer-Policy`, and a restrictive `Permissions-Policy` are set
  platform-wide in `next.config.js`.
- **Exam integrity — server-side timer enforcement (Phase 10):**
  `submitQuizAttempt` now checks the real deadline
  (`attempt.startedAt + quiz.durationMinutes`, plus a 30-second grace
  window for latency) server-side and auto-submits a zero score if a
  submission arrives after it — closing the Phase 6 gap where only a
  client-side timer existed.
- **No secrets in the repo:** `.env` is git-ignored; `.env.example` has
  placeholders only.

## Partial / needs work before production

- **Rate limiting beyond login:** no general API rate limiting exists for
  other endpoints (e.g. repeated quiz-attempt starts, search queries).
  Recommend adding a proper rate-limit layer (Vercel's built-in options,
  or a Redis-backed limiter) at the reverse-proxy or middleware level.
- **Input validation coverage:** most server actions still use ad-hoc
  `String(formData.get(...))` + manual `if (!x) throw` checks rather than
  a `zod` schema. Functionally these do validate presence/type, but they
  don't validate format (email shape, URL shape, date sanity) as
  consistently as the new `createUser` pattern does. Extending
  `src/lib/validation.ts` schemas to the rest of `src/lib/actions/*.ts` is
  the recommended next pass.
- **File uploads:** never implemented (by design, per spec §64 — "don't
  pretend an upload system exists unless configured"). Every
  material/video/image field is a URL a teacher pastes. Before real file
  uploads are added, they need: file-type allowlisting, size limits,
  antivirus/malware scanning if user-uploaded files are served to other
  users, and signed URLs rather than public buckets for anything
  non-public.
- **CSP (Content-Security-Policy):** deliberately not set (see the
  comment in `next.config.js`) — this app embeds third-party iframes
  (YouTube, GeoGebra, Desmos) whose exact origins depend on what a
  teacher adds, so a safe CSP needs to be authored against your real
  deployed content, not guessed at generically.
- **Account recovery:** no "forgot password" flow exists. An admin must
  manually create a new temporary password for a locked-out user (see
  the `/admin/users/new` note about this). Self-service reset (email-based)
  is a reasonable Phase-10-and-beyond addition once email sending is
  configured.

## Explicitly not done

- Independent penetration testing / security audit.
- Automated dependency vulnerability scanning (e.g. `npm audit` in CI,
  Dependabot/Snyk).
- Load testing / DoS resilience testing.
- A formal incident-response plan.
- Data-retention and deletion policy (e.g. what happens to a student's
  data when they leave a school — the schema supports soft-deactivation
  via `User.isActive`, but no hard-delete/export tooling exists for GDPR/
  local-equivalent compliance needs).

## Backup & recovery (documentation only — no infrastructure exists here)

This app has no backup infrastructure of its own; it depends entirely on
whatever PostgreSQL hosting you choose. Recommended approach:

1. Use a managed Postgres provider with automated daily backups and
   point-in-time recovery (Neon, Supabase, RDS, etc. all offer this).
2. If self-hosting Postgres, set up `pg_dump` on a cron schedule, store
   dumps off-server (e.g. S3), and periodically test restoring from one —
   an untested backup is not a backup.
3. Back up `.env` secrets separately, in a secrets manager, never in the
   same location as database dumps.
4. Document your actual recovery time objective (RTO) and recovery point
   objective (RPO) once you pick a hosting provider — those numbers
   depend on the provider's specific guarantees.
