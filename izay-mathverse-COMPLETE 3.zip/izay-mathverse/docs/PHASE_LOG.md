# Phase Log

Tracks progress against the spec's 10-phase build plan (§66).

## ✅ Phase 1 — Foundation (this delivery)

| Item | Status |
|---|---|
| Project setup (Next.js 14 + TypeScript + Tailwind) | Done |
| Database schema (all 57 entities from §49) | Done |
| Authentication (NextAuth, bcrypt, JWT) | Done |
| Roles (Super Admin / Admin / Teacher / Student) | Done |
| Backend authorization (`requireRole`) | Done |
| Navigation shells per role | Done |
| Organization/school structure + admin CRUD | Done |
| Course access control (Available/Restricted toggle) | Done |
| Audit logging (login, org, course, user mutations) | Done |
| Seed data (1 org, 1 user per role, 2 courses, grade boundaries) | Done |

**Not yet verified:** `npm install` / `npm run build` in a real Node
environment — the sandbox used to generate this code has no network
access. Please run these locally/in CI and report any errors.

**Manual test checklist for you to run once installed:**
- [ ] `npm run db:migrate` creates all tables without error
- [ ] `npm run db:seed` completes and prints the 4 demo accounts
- [ ] Can sign in as each of the 4 roles and land on the correct dashboard
- [ ] Visiting `/admin` as a Student redirects to `/unauthorized` (and vice versa)
- [ ] Admin can create a new Organization and see it in the list
- [ ] Admin can create a new Teacher/Student user and it appears in `/admin/users`
- [ ] Admin can toggle Core Mathematics to Available, and the student-facing
      locked page disappears immediately (no restart needed)
- [ ] Mobile viewport (375px) renders the dashboard nav and tables usably

## ✅ Phase 2 — Course and Curriculum (this delivery)

| Item | Status |
|---|---|
| Curriculum hierarchy schema (Level→Strand→SubStrand→Topic→CS→LO→LI→Activity→AssessmentNote) | Done (Phase 1) |
| Curriculum browsing UI, shared by Admin & Teacher (`/curriculum/...`) | Done |
| Curriculum import — upload → **Import Preview** → Confirm/Reject (spec §46) | Done, JSON format |
| Curriculum versioning (`CurriculumVersion`, non-destructive re-imports) | Done |
| Full SHS 1–3 **structural** seed (all strand/sub-strand names & codes) | Done — verified against the curriculum document's Scope and Sequence table |
| Deep **content** seed (Content Standard, Learning Outcomes, Learning Indicator, 2 Activities, Assessment) | Done for 1 topic — see note below |
| Curriculum completeness dashboard (§48: topics without lessons/practice/assessment) | **Not yet** — deferred, needs Lesson/Question data from Phases 3–4 to be meaningful |

**Important scope note on curriculum content depth:** The source document
is 500+ pages of dense, multi-column tables, and each of the ~61 Learning
Outcomes carries several paragraphs of near-duplicate 21st-Century-
Skills/GESI/SEL narrative. Bulk-parsing all of it in one pass risks silently
corrupting mathematical notation or misattributing scrambled table text —
which would violate the spec's "do not invent missing curriculum
information" rule as surely as inventing content would. So this phase
ships:
- **100% of the structural tree** (every Strand/Sub-Strand name+code for
  all three years), verified against the document's own summary table, and
- **One fully-verified deep-content example** (Y1 → Modelling with Algebra
  → Number and Algebraic Patterns → "Binary Operations, Sets and Binomial
  Theorem": the Content Standard, all 4 Learning Outcome statements, one
  Learning Indicator with 2 real Activities, and one real Assessment item),
  transcribed and checked against pages 24–38 of the source PDF.

The Import tool built this phase (`/curriculum/import`) is the intended
path for adding the remaining ~60 topics' worth of verified content
incrementally — each batch goes through the same preview/confirm review
screen, so nothing reaches the live curriculum unverified. A worked sample
payload is at `docs/sample-curriculum-import.json`.

**Manual test checklist:**
- [ ] `npm run db:seed:curriculum` runs after `npm run db:seed` without error
- [ ] `/curriculum` (as Admin or Teacher) shows Additional Mathematics with SHS 1/2/3
- [ ] Drilling SHS 1 → Modelling with Algebra → Number and Algebraic Patterns shows the "Binary Operations..." topic with LOs, the Content Standard, Learning Indicator, both Activities, and the Assessment item
- [ ] SHS 3 → Modelling with Algebra shows only Sub-Strand "Applications of Algebra" (no Sub-Strand 1 — this is correct, not a bug)
- [ ] `/curriculum/import` lets you paste `docs/sample-curriculum-import.json`, shows an accurate preview, and Confirm creates the records
- [ ] A Student account cannot reach `/curriculum` (redirects to `/unauthorized`)

## ✅ Phase 3 — Learning Content (this delivery)

| Item | Status |
|---|---|
| Lesson creation directly under a curriculum Topic (§15) | Done |
| Lesson editor — all §16 fields except practice questions/hints/solutions (need Question Bank, Phase 4) | Done |
| Lesson status workflow: Save Draft / Preview / Publish / Archive (§16, §19) | Done |
| Lesson reordering within a topic (§18) | Done — as real, DB-backed up/down controls rather than literal drag-and-drop; the underlying `sortOrder` swap is the same mechanism drag-and-drop would call, so a drag UI can sit on top of this later without a data-model change |
| Learning Materials attached to lessons (§20) | Done — URL-based (see file-storage note below) |
| Video system — YouTube (auto-embedded) + uploaded-file metadata (§21) | Done |
| GeoGebra activities — embedded when the URL is geogebra.org, else "Open in GeoGebra" (§22) | Done |
| Desmos activities — same embed/link pattern (§23) | Done |
| External Resources (§24) | Done |
| Math rendering via KaTeX (§52) | Done — lesson text fields support `$inline$` and `$$display$$` LaTeX |
| Student-facing curriculum browsing + lesson viewer | Done — enforces course availability and lesson publication status server-side |

**File storage note (spec §64 — no pretend features):** there is still no
file storage provider wired up, so Learning Materials, uploaded videos, and
lesson images are all URL fields — the teacher pastes a link to an
already-hosted file rather than uploading through the app. Real upload
(presumably to an S3-compatible bucket) is flagged in the README as a
setup step to add whenever that's prioritized; nothing in the UI claims
uploads work today.

**Access-control note:** lesson management routes moved from `/teacher/lessons/*`
to a role-shared `/lessons/*` and the curriculum browser lives at
`/curriculum/*` (open to Admin + Teacher) — both were previously nested
under `/teacher`, which would have incorrectly locked Admins out.

**Manual test checklist:**
- [ ] From `/curriculum/.../[subStrandId]`, "+ Add Lesson" creates a Draft lesson and lands on its editor
- [ ] Saving lesson content, then clicking Preview, shows the same content the student will eventually see, math formulae rendered (try `$$x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}$$` in the Formulae field)
- [ ] Publish flips status to PUBLISHED; a Student can now see it under `/student/courses/additional-mathematics` → SHS 1 → the relevant strand/sub-strand/topic
- [ ] A Draft lesson does NOT appear to a Student, even via a guessed direct URL (`/student/lessons/[id]` should 404)
- [ ] Reorder (↑/↓) actually persists — refresh the page and the new order sticks
- [ ] A YouTube URL added as a Video embeds and plays; a non-YouTube "uploaded" URL shows as a link instead
- [ ] An Admin (not just a Teacher) can reach `/curriculum` and `/lessons/new` without being redirected to `/unauthorized`

## ✅ Phase 4 — Question Bank (this delivery)

| Item | Status |
|---|---|
| Question CRUD: Create, Edit, Duplicate, Delete, Archive, Restore (§25) | Done |
| Search & Filter (text, course, type, difficulty, status) (§25) | Done |
| All 7 question types (§26) | Schema + editor done; type-specific input UI (options vs. free-answer) done |
| Multiple answer options with correct-answer flagging | Done |
| Multiple ordered Hints (§29) | Done |
| Solution with exam-time visibility toggle (§30) | Done |
| Attach bank questions to a Lesson's practice section | Done |
| Question preview (student-facing render, no answer leaked) | Done |
| Import | **Not yet** — the curriculum import pattern from Phase 2 (`CurriculumImportBatch`) is the template to reuse for a `QuestionImportBatch` when this is prioritized |
| Automatic grading (§31) | **Not yet** — this is Phase 5 (Practice Engine); the schema (`correctAnswer`, `acceptedAnswers`) is ready for it |

**Honest scope note on "mathematically equivalent answers" (§28):** the
editor lets a teacher list accepted equivalent answer strings (e.g. `2x+4`
and `2(x+2)`), but there's no symbolic math engine doing real equivalence
checking yet — that's exact-string matching against the list, not true
algebraic equivalence (e.g. it won't automatically recognize `4+2x` as the
same as `2x+4` unless both are listed). Real symbolic comparison is a
Phase 5 (Practice Engine / Automatic Grading) concern, called out there
rather than silently assumed working here.

**Manual test checklist:**
- [ ] Create a Multiple Choice question, add 4 options, mark one correct, Activate it
- [ ] It now appears in the "Practice Questions" attach dropdown on a Lesson's editor (only ACTIVE questions are offered)
- [ ] Attaching it makes it show up in the student lesson viewer's Practice Questions section
- [ ] Duplicate creates a second question titled "... (copy)" as a fresh Draft, with the same options copied over
- [ ] Search/filter on `/questions` narrows the list correctly by each filter independently and combined
- [ ] Question Preview does not reveal the correct answer or solution by default (solution is behind a `<details>` disclosure, matching spec §30's "teacher controls when solutions become available")

## ✅ Phase 5 — Practice Engine (this delivery)

| Item | Status |
|---|---|
| Practice by course/topic (§27) | Done |
| 4 practice modes: Learn & Practice, Quick Practice, Challenge Mode, Exam Mode (§27) | Done — mode currently controls hint visibility; timer/stricter pacing for Challenge Mode is a later refinement |
| Answer checking — MCQ, True/False, Numerical, Short Answer, Algebraic Expression (§28) | Done, see grading note below |
| Automatic grading (§31) | Done for the 5 auto-gradable types; Structured/Diagram-Image correctly marked "pending manual review" rather than faked |
| Student progress — real per-topic stats from actual attempts (§39) | Done |
| Weak topic detection — topics under 70% flagged "Needs Practice" with Review Lesson / Practice Questions actions, computed from real data only (§40) | Done |
| Practice session history / attempts list | Done (session summary screen) |

**Grading honesty note (ties back to Phase 4):** "mathematically equivalent
answers" for Short Answer / Algebraic Expression questions means
normalized-string matching against the teacher's listed accepted answers —
not a symbolic algebra engine. `2x+4` will only be accepted as equivalent
to `4+2x` if a teacher explicitly lists it. This is stated in the UI
(question editor) and here, not left implicit.

**Known limitation — `TopicProgress.lessonsCompleted`:** the schema has
this field, but there's no lesson-completion tracking UI in this phase (no
join table exists yet to prevent double-counting a student re-opening the
same lesson). Rather than approximate it inaccurately, it's left at 0 for
now — see "Not started" below.

**Manual test checklist:**
- [ ] From a topic with at least one ACTIVE question, start a Quick Practice session and answer a Multiple Choice question — the session advances to the next question or the summary screen
- [ ] After a session, `/student/progress` shows the topic with a real, non-zero performance percentage
- [ ] A topic scored below 70% appears under "Needs Practice" with working Review Lesson / Practice Questions links; 70%+ appears under "Going Well"
- [ ] Ending a session early (before the question pool is exhausted) still produces a valid summary
- [ ] A Numerical question accepts `3.0` as equivalent to `3` (tolerance-based match)
- [ ] A second student's practice attempts never appear in the first student's progress (per-student isolation via `assertOwnRecord`)

## ✅ Phase 6 — Quizzes and Tests (this delivery, Quizzes only — see scope note)

| Item | Status |
|---|---|
| Quiz settings (§32): questions/attempt, marks, duration, dates, attempts, randomization/shuffle toggles, hints/solutions toggles, result visibility | Done |
| Question pool management, attached from the Question Bank | Done |
| Random question selection from the pool (§33) | Done |
| Question and option shuffling per attempt (§34) | Done |
| Question-set snapshotting so edits/deletes never retroactively change a submitted attempt (§35) | Done |
| Timer, submit confirmation, limited attempts, automatic grading (§36) | Done — see timer caveat below |
| Result visibility rules (Immediate/After Submission/After Due Date/Manual Release) | Done — Manual Release currently always withholds (no release-tracking field exists yet; see note) |

**Scope note — Tests:** the master prompt doesn't dedicate a distinct build
section to "Tests" beyond what Quizzes already specify (§32–36 describe one
mechanism: pool → randomization → snapshot → timed attempt → auto-grade).
The `Test`/`TestQuestion`/`TestAttempt` models already exist in the Phase 1
schema for this, but a second, nearly-identical CRUD+attempt UI is
deferred rather than built as a shallow duplicate of the Quiz UI — when
prioritized, it's a copy of `src/lib/actions/quizzes.ts` and the
`/quizzes` and `/student/quizzes` routes, adapted to the `Test` model
(which has no `hintsEnabled`/`solutionsEnabled`/`resultVisibility` fields,
consistent with §36 exam mode implying solutions are withheld during
formal tests).

**Known gaps, stated rather than hidden:**
- The exam timer (`ExamTimer` component) is a client-side UX layer only —
  it auto-submits locally when time runs out, but the time window isn't
  separately re-validated on the server at submit time. A student who
  disables JavaScript or edits the client clock could in principle submit
  late. Server-side deadline enforcement is a straightforward follow-up
  (compare `Date.now()` against `attempt.startedAt + quiz.durationMinutes`
  inside `submitQuizAttempt`) — flagged here rather than silently assumed
  solid, and worth doing before this reaches real exam use.
- `resultVisibility: MANUAL_RELEASE` always withholds results for now —
  there's no `releasedAt` field on `QuizAttempt` yet to track a teacher's
  manual release action. Rather than guess at a release date, results stay
  hidden (safer default) until that field and the teacher-facing release
  action are added.

**Manual test checklist:**
- [ ] Create a quiz, add 3+ ACTIVE questions from the bank to its pool, publish it
- [ ] As a Student, start the quiz — confirm the timer counts down and matches the quiz's duration
- [ ] Submit before time expires — confirm the result page shows a real, correctly-computed score
- [ ] Start a second attempt if `attemptsAllowed` permits, confirm it's blocked once attempts are exhausted
- [ ] With `shuffleOptions` on, start two attempts (or check two students) and confirm option order differs
- [ ] Edit or archive a Question that's already part of a submitted attempt's snapshot — confirm the historical result and review still render correctly from the frozen snapshot, unaffected by the edit

## ✅ Phase 7 — Assignments and Results (this delivery)

| Item | Status |
|---|---|
| Assignment creation (title, instructions, course, total marks, due date) (§37) | Done |
| Attachments (URL-based — see file-storage note) | Done |
| Student submission (text and/or file link), auto-flagged Late if past due (§37) | Done |
| Teacher: view, mark, give feedback, return submissions (§37) | Done |
| Results — no GPA, configurable Grade boundaries, includes teacher remark (§38) | Done — now populated by both Quiz submissions (Phase 6) and Assignment marking |
| Grade boundary lookup shared between Quiz and Assignment marking | Done (`src/lib/grade-lookup.ts`) |

**Not built in this phase:** class/topic scoping on assignments (the
`Assignment.topicId` field exists in the schema but isn't wired into the
create form yet — every assignment is currently course-wide, not
topic-specific), and Term/Academic Year selection when marking (so
`Result.termId` is currently always null — the Results table shows "—" for
Term until that's wired up). Both are small, mechanical additions once
prioritized — the schema already supports them.

**Manual test checklist:**
- [ ] Create an assignment with a due date in the past — a student's submission is automatically marked LATE
- [ ] Create one with a future due date — submission comes through as SUBMITTED
- [ ] Marking a submission computes the right percentage and grade label, and creates a Result the student can see at `/student/results`
- [ ] Feedback is hidden from the student until the teacher clicks "Return to student"
- [ ] A student re-submitting before marking updates their existing submission rather than creating a duplicate

## ✅ Phase 8 — Analytics (this delivery)

| Item | Status |
|---|---|
| Teacher/Admin analytics dashboard: lesson/question status breakdowns, quiz activity, assignment submission stats | Done — `/analytics`, all figures computed live from the database |
| Class-wide topic performance (averaged across every student who's attempted that topic, worst first) | Done — reuses the same `TopicProgress` data as student-facing progress (Phase 5), never a separate/simulated dataset |
| Curriculum Completeness dashboard (§48) | Done — `/curriculum/completeness`, computed live from Learning Indicators × Lessons × Question Bank × Quiz pools |

**Why this was deferred until now:** §48's report (topics without lessons/
practice/assessment) is meaningless without real Lesson and Question data
to measure against — building it in Phase 2 would have meant either
showing all-zero placeholder numbers or, worse, synthetic ones. Now that
Phases 3, 4, and 6 have produced real lessons, questions, and quiz pools,
the report reflects the platform's actual state. It will currently show
mostly "no curriculum items" for topics beyond the one Phase 2 seeded with
real Learning Indicators (see Phase 2's scope note) — that's an accurate
reflection of the data, not a bug in the report.

**Known limitation — performance at scale:** the completeness report
issues one query per Topic to walk Learning Indicator → Lessons/Questions.
Fine for a course with dozens of topics; would need batching (a single
query with aggregation, or a materialized/cached summary) before this
scales to many courses with hundreds of topics each. Flagged here rather
than silently left as a future surprise.

**Manual test checklist:**
- [ ] `/analytics` shows non-zero lesson/question counts matching what you created in earlier phases
- [ ] After submitting a quiz attempt (Phase 6 checklist), the average score on `/analytics` updates
- [ ] `/curriculum/completeness` shows the one Phase-2-seeded topic ("Binary Operations, Sets and Binomial Theorem") with its real Learning Indicator/Lesson/Practice/Assessment coverage
- [ ] Adding a Lesson linked to that topic's Learning Indicator increases its "Lessons" coverage count on refresh

## ✅ Phase 9 — Additional Features (this delivery)

| Item | Status |
|---|---|
| **Class management** (foundational — was missing since Phase 1 despite the schema existing) | Done — `/admin/classes`: create class, assign teacher, enroll students |
| Attendance (§56) | Done — teacher marks Present/Absent/Late per class per date; students see only their own records |
| Timetable (§57) | Done — staff create entries per class; students get Today/Tomorrow/Week views scoped to their own enrolled classes |
| Announcements (§54) | Done — targeted to All Students / a School / a Class, with real audience computation (not guessed) |
| Notifications (§55) | Done for announcements only (fan-out on post, mark-as-read) — see scope note below |
| WASSCE Preparation (§41) | Done — course-level resource upload (Past Questions, Mock Tests, etc. via free-text title + typed file), shown to students on available courses only |
| Downloads (§58) | Done — consolidated view of course-level and lesson-level materials the student can actually access |
| Achievements (§59) | **Admin management only** — create/enable/disable and *manual* award. No automatic-unlock logic (streaks, question-count milestones) is wired up — see honesty note below |
| Search (§53) | Done — real database-backed search (lessons/questions/materials for staff; published lessons/materials for students) |

**Scope note — Notifications beyond announcements:** spec §55 lists several
notification triggers (new lessons, assignment deadlines, quiz/test
availability, results). Only the announcement trigger is wired up in this
phase; the `Notification` model and read/unread UI are fully built and
reusable, so adding a trigger elsewhere (e.g. `createNotification()` call
inside `setLessonStatus` when a lesson publishes) is a small addition per
event, not new infrastructure — deferred here to keep this phase's actual
scope honest rather than partially wiring five triggers thinly.

**Honesty note — Achievements:** the spec's examples ("100 Questions
Completed", "Practice Streak") imply automatic detection against real
usage data. That detection logic does not exist in this build — awarding
is a manual admin action only. Building fake "streak calculated"
messaging would violate spec §64 (no fake features), so instead the admin
UI says exactly what it does: create an achievement, then hand-award it.

**Manual test checklist:**
- [ ] Create a class, assign a teacher, enroll a student — the class's roster now drives Attendance and Timetable for that student
- [ ] Take attendance for a class/date, then check `/student/attendance` shows exactly that record and no other student's
- [ ] Post a Class-targeted announcement — only enrolled students see it, and each gets a Notification
- [ ] Add a WASSCE resource to an Available course — it shows on `/student/wassce`; add one to a Restricted course — confirm it does NOT show
- [ ] Search for a lesson title as a Teacher (finds Draft + Published) vs as a Student via `/student/search` (finds Published/Active only, in Available courses only)

## ✅ Phase 10 — Security and Production (this delivery — final phase)

Per the spec's own rule for this phase ("Security testing, Permission
testing... Deployment"), this phase hardens what exists rather than adding
features.

| Item | Status |
|---|---|
| Server-side exam-timer enforcement (closes the Phase 6 gap) | Done — `submitQuizAttempt` now checks the real deadline server-side with a 30s grace window, auto-submitting a zero score if missed |
| Login brute-force protection | Done — 5 failed attempts / 15 minutes locks an account out, built on the existing audit log (no schema change) |
| Security headers | Done — `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` set platform-wide |
| Structured input validation (zod) | Done for user creation as the first/reference implementation — see `docs/SECURITY.md` for what's still ad-hoc |
| Consolidated security documentation | Done — `docs/SECURITY.md`: what's implemented, what's partial, what's explicitly not done, backup/recovery guidance |
| Deployment guide | Done — `docs/DEPLOYMENT.md`: environment setup, deploy steps, post-deploy verification |
| Full codebase consistency pass | Done — every brace/paren balanced, every server action's exports verified against actual usage (zero dead code, zero missing imports) across all 64 pages and 15 action files |

**What this phase deliberately did NOT do:** run an actual security audit,
add file-upload infrastructure, build a CSP, add rate limiting beyond
login, or extend zod validation to every action. Each of those is named
explicitly in `docs/SECURITY.md` with why it's out of scope for a
code-review-level pass in this environment (no ability to run/test
security tooling here) rather than silently left undone.

## Project status: all 10 phases delivered

| Phase | Status |
|---|---|
| 1. Foundation | ✅ |
| 2. Course and Curriculum | ✅ (structural tree complete; deep content is 1 verified sample topic + the import pipeline to extend it) |
| 3. Learning Content | ✅ |
| 4. Question Bank | ✅ |
| 5. Practice Engine | ✅ |
| 6. Quizzes and Tests | ✅ Quizzes fully; Tests share the schema but not a built UI (see Phase 6 scope note) |
| 7. Assignments and Results | ✅ |
| 8. Analytics | ✅ |
| 9. Additional Features | ✅ |
| 10. Security and Production | ✅ (hardening + documentation; not an independent audit) |

**Every open item across all ten phases is catalogued in this file and in
`docs/SECURITY.md` / `docs/DEPLOYMENT.md`** — nothing was silently dropped.
The single highest-priority pre-launch item is **real file storage**
(materials/videos/images are URL-only throughout); the second is
**running an actual `npm install && npm run build`**, since this entire
codebase was written without the ability to execute or compile it in this
sandbox.
