# Master Build Prompt — Izay MathVerse

This file is a reference copy of the specification this project is being
built against, as supplied by the project owner. It governs every
architectural decision in this codebase (see README.md for what's been
implemented so far against it).

The full text is long (68 sections). Rather than duplicate it here
verbatim, refer to the original `Prompt.pdf` supplied for this project.
Key non-negotiable rules restated for quick reference during development:

1. **Content is data, not code** (§2) — courses, curriculum, lessons,
   questions, quizzes, etc. must be database records editable from the
   dashboard, never hard-coded.
2. **School-independent** (§4) — no school name, logo, or org-specific
   data hard-coded anywhere.
3. **Preserve curriculum terminology exactly** (§8, §13) — don't invent,
   omit, or substitute generic content for what the supplied Additional
   Mathematics curriculum document actually says.
4. **No fake features** (§64) — no dead buttons, no fake analytics, no
   pretending an unconfigured integration works.
5. **Backend-enforced security** (§50) — every sensitive operation must be
   authorized server-side; never rely on the frontend alone.
6. **Phase-by-phase build discipline** (§66–67) — build one phase, test it,
   fix errors, verify DB operations / permissions / mobile responsiveness,
   only then continue. Never build the whole app as one giant file.
