import Link from "next/link";

export default function UnauthorizedPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <p className="text-5xl mb-4">🚫</p>
      <h1 className="text-2xl font-bold text-slate-800">Access denied</h1>
      <p className="mt-2 text-slate-500 max-w-sm">
        You don&apos;t have permission to view this page with your current
        account role.
      </p>
      <Link
        href="/"
        className="mt-6 inline-block rounded-lg bg-brand-600 px-5 py-2.5 text-white font-medium hover:bg-brand-700 transition"
      >
        Go back
      </Link>
    </main>
  );
}
