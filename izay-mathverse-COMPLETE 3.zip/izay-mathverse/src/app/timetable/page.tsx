import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { createTimetableEntry, deleteTimetableEntry } from "@/lib/actions/timetable";

export default async function TimetablePage() {
  const user = await getSessionUser();
  if (!user || !["SUPER_ADMIN", "ADMIN", "TEACHER"].includes(user.role)) {
    redirect("/unauthorized");
  }

  const classes = await prisma.class.findMany({ orderBy: { name: "asc" } });
  const entries = await prisma.timetableEntry.findMany({
    orderBy: [{ date: "asc" }, { startTime: "asc" }],
    include: { class: true },
    where: { date: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } },
    take: 50,
  });

  const backHref = user.role === "TEACHER" ? "/teacher" : "/admin";

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3">
        <Link href={backHref} className="text-xs text-brand-700 hover:underline">← Back to dashboard</Link>
        <p className="font-semibold text-slate-800">Timetable</p>
      </header>
      <main className="max-w-lg mx-auto p-4 sm:p-6 space-y-6">
        <form action={createTimetableEntry} className="bg-white rounded-lg border border-slate-200 p-5 space-y-3">
          <p className="text-sm font-semibold text-slate-700">Add Timetable Entry</p>
          <select name="classId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="">— Select a class —</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input type="date" name="date" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <div className="grid grid-cols-2 gap-2">
            <input type="time" name="startTime" required className="rounded-md border border-slate-300 px-3 py-2 text-sm" />
            <input type="time" name="endTime" required className="rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <input name="topicLabel" placeholder="Topic (optional)" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <input name="venue" placeholder="Venue (optional)" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition">
            Add Entry
          </button>
        </form>

        <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
          {entries.map((e) => (
            <div key={e.id} className="p-3 flex items-center justify-between text-sm">
              <div>
                <p className="text-slate-800">
                  {e.date.toLocaleDateString()} · {e.startTime}–{e.endTime} · {e.class.name}
                </p>
                <p className="text-xs text-slate-400">
                  {e.topicLabel ?? "No topic set"}{e.venue ? ` · ${e.venue}` : ""}
                </p>
              </div>
              <form action={deleteTimetableEntry.bind(null, e.id)}>
                <button className="text-xs text-red-600 hover:underline">Remove</button>
              </form>
            </div>
          ))}
          {entries.length === 0 && (
            <p className="p-6 text-center text-sm text-slate-400">No upcoming entries.</p>
          )}
        </div>
      </main>
    </div>
  );
}
