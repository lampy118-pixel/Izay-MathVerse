import Link from "next/link";
import { getSessionUser } from "@/lib/rbac";
import { redirect } from "next/navigation";

export default async function HomePage() {
  const user = await getSessionUser();

  if (user) {
    if (user.role === "STUDENT") redirect("/student");
    if (user.role === "TEACHER") redirect("/teacher");
    redirect("/admin");
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center bg-gradient-to-b from-brand-700 to-brand-900 text-white">
      <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">
        Izay MathVerse
      </h1>
      <p className="mt-3 text-lg text-brand-100">
        Learn • Practice • Master Mathematics
      </p>
      <p className="mt-8 max-w-md text-brand-100/90">
        A database-driven Mathematics Learning Management System for
        teachers and students — reusable across any school.
      </p>
      <Link
        href="/login"
        className="mt-8 inline-block rounded-lg bg-white px-6 py-3 font-semibold text-brand-800 shadow hover:bg-brand-50 transition"
      >
        Sign in
      </Link>
    </main>
  );
}
