import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

export default async function StaffSearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const user = await getSessionUser();
  if (!user || !["SUPER_ADMIN", "ADMIN", "TEACHER"].includes(user.role)) {
    redirect("/unauthorized");
  }

  const q = searchParams.q?.trim() ?? "";
  const backHref = user.role === "TEACHER" ? "/teacher" : "/admin";

  const [lessons, questions, materials] = q
    ? await Promise.all([
        prisma.lesson.findMany({ where: { title: { contains: q, mode: "insensitive" } }, take: 15 }),
        prisma.question.findMany({ where: { questionText: { contains: q, mode: "insensitive" } }, take: 15 }),
        prisma.lessonMaterial.findMany({ where: { title: { contains: q, mode: "insensitive" } }, take: 15 }),
      ])
    : [[], [], []];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3">
        <Link href={backHref} className="text-xs text-brand-700 hover:underline">← Back to dashboard</Link>
        <p className="font-semibold text-slate-800">Search</p>
      </header>
      <main className="max-w-lg mx-auto p-4 sm:p-6 space-y-6">
        <form method="GET">
          <input
            name="q"
            defaultValue={q}
            placeholder="Search lessons, questions, materials..."
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            autoFocus
          />
        </form>

        {q && (
          <>
            <ResultGroup title="Lessons" items={lessons.map((l) => ({ id: l.id, label: l.title, href: `/lessons/${l.id}/edit` }))} />
            <ResultGroup title="Questions" items={questions.map((qn) => ({ id: qn.id, label: qn.questionText.slice(0, 80), href: `/questions/${qn.id}/edit` }))} />
            <ResultGroup title="Materials" items={materials.map((m) => ({ id: m.id, label: m.title, href: m.fileUrl }))} />
            {lessons.length === 0 && questions.length === 0 && materials.length === 0 && (
              <p className="text-sm text-slate-400">No results for &quot;{q}&quot;.</p>
            )}
          </>
        )}
      </main>
    </div>
  );
}

function ResultGroup({ title, items }: { title: string; items: { id: string; label: string; href: string }[] }) {
  if (items.length === 0) return null;
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">{title}</p>
      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {items.map((item) => (
          <Link key={item.id} href={item.href} className="block p-3 text-sm text-slate-700 hover:bg-slate-50 transition">
            {item.label}
          </Link>
        ))}
      </div>
    </div>
  );
}
