import { getSessionUser } from "@/lib/rbac";
import { RoadmapNote } from "@/components/roadmap-note";

export default async function TeacherDashboardPage() {
  const user = await getSessionUser();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">
          Welcome, {user?.name}
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Browse the imported curriculum under{" "}
          <a href="/curriculum" className="text-brand-700 hover:underline">
            Curriculum
          </a>
          . Lesson-building and other content-management tools ship in the
          next phases.
        </p>
      </div>

      <RoadmapNote
        items={[
          "Practice engine & auto-grading — Phase 5",
          "Quizzes, tests & assignments — Phases 6–7",
          "Student analytics & weak-topic detection — Phase 8",
          "Attendance, timetable, announcements — Phase 9",
        ]}
      />
    </div>
  );
}
