import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/rbac";
import { DashboardShell } from "@/components/dashboard-shell";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/teacher" },
  { label: "Curriculum", href: "/curriculum" },
  { label: "Questions", href: "/questions" },
  { label: "Quizzes", href: "/quizzes" },
  { label: "Assignments", href: "/assignments" },
  { label: "Analytics", href: "/analytics" },
  { label: "Attendance", href: "/attendance" },
  { label: "Timetable", href: "/timetable" },
  { label: "Announcements", href: "/announcements" },
  { label: "WASSCE Prep", href: "/wassce" },
  { label: "Search", href: "/search" },
];

export default async function TeacherLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if (!user || user.role !== "TEACHER") {
    redirect("/unauthorized");
  }

  return (
    <DashboardShell user={user} navItems={NAV_ITEMS}>
      {children}
    </DashboardShell>
  );
}
