import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { MathContent } from "@/components/math-content";

export default async function QuestionPreviewPage({
  params,
}: {
  params: { id: string };
}) {
  const question = await prisma.question.findUnique({
    where: { id: params.id },
    include: {
      options: { orderBy: { sortOrder: "asc" } },
      hints: { orderBy: { order: "asc" } },
      solutions: true,
    },
  });

  if (!question) notFound();

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <Link
        href={`/questions/${question.id}/edit`}
        className="text-xs text-brand-700 hover:underline"
      >
        ← Back to editor
      </Link>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-xs text-slate-400 mb-2">
          {question.marks} mark{question.marks === 1 ? "" : "s"} ·{" "}
          {question.difficulty}
        </p>
        <MathContent text={question.questionText} className="text-slate-800" />

        {question.imageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={question.imageUrl}
            alt="Question diagram"
            className="mt-3 rounded-md border border-slate-200 max-w-full"
          />
        )}

        {question.options.length > 0 && (
          <div className="mt-4 space-y-2">
            {question.options.map((opt, i) => (
              <label
                key={opt.id}
                className="flex items-center gap-2 text-sm bg-slate-50 rounded-md px-3 py-2 cursor-not-allowed"
              >
                <input type="radio" disabled />
                <span className="text-slate-700">
                  {String.fromCharCode(65 + i)}. {opt.text}
                </span>
              </label>
            ))}
          </div>
        )}

        {question.options.length === 0 && (
          <input
            disabled
            placeholder="Student answer input"
            className="mt-4 w-full rounded-md border border-slate-300 px-3 py-2 text-sm bg-slate-50 cursor-not-allowed"
          />
        )}

        {question.hints.length > 0 && (
          <details className="mt-4 text-sm">
            <summary className="cursor-pointer text-brand-700 font-medium">
              Show hints ({question.hints.length})
            </summary>
            <ol className="mt-2 space-y-1 list-decimal list-inside text-slate-600">
              {question.hints.map((h) => (
                <li key={h.id}>{h.text}</li>
              ))}
            </ol>
          </details>
        )}

        {question.solutions[0] && (
          <details className="mt-2 text-sm">
            <summary className="cursor-pointer text-brand-700 font-medium">
              Show solution
            </summary>
            <p className="mt-2 text-slate-600 whitespace-pre-line">
              {question.solutions[0].text}
            </p>
            {!question.solutions[0].isAvailableDuringExam && (
              <p className="mt-1 text-xs text-amber-600">
                Hidden automatically during formal exam-mode assessments.
              </p>
            )}
          </details>
        )}
      </div>
    </div>
  );
}
