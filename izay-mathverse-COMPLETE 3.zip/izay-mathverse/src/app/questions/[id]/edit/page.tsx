import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { MathContent } from "@/components/math-content";
import {
  updateQuestion,
  setQuestionStatus,
  duplicateQuestion,
  deleteQuestion,
  addQuestionOption,
  deleteQuestionOption,
  addHint,
  deleteHint,
  setSolution,
} from "@/lib/actions/questions";

export default async function QuestionEditPage({
  params,
}: {
  params: { id: string };
}) {
  const question = await prisma.question.findUnique({
    where: { id: params.id },
    include: {
      course: true,
      topic: true,
      options: { orderBy: { sortOrder: "asc" } },
      hints: { orderBy: { order: "asc" } },
      solutions: true,
    },
  });

  if (!question) notFound();

  const showOptions =
    question.type === "MULTIPLE_CHOICE" || question.type === "TRUE_FALSE";
  const solution = question.solutions[0];
  const updateAction = updateQuestion.bind(null, question.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-400">
            {question.course.name}
            {question.topic ? ` / ${question.topic.name}` : ""}
          </p>
          <div className="flex items-center gap-2 mt-1">
            <h1 className="text-lg font-bold text-slate-800">
              Edit Question
            </h1>
            <span className="text-xs font-medium bg-slate-100 text-slate-600 rounded-full px-2.5 py-0.5">
              {question.status}
            </span>
          </div>
        </div>
        <Link
          href="/questions"
          className="text-xs text-brand-700 hover:underline"
        >
          ← All questions
        </Link>
      </div>

      {/* Status / lifecycle controls — spec §25 */}
      <div className="flex flex-wrap gap-2">
        <form action={setQuestionStatus.bind(null, question.id, "ACTIVE")}>
          <button className="text-xs font-medium rounded-md border border-green-300 text-green-700 px-3 py-1.5 hover:bg-green-50 transition">
            Activate
          </button>
        </form>
        <form action={setQuestionStatus.bind(null, question.id, "ARCHIVED")}>
          <button className="text-xs font-medium rounded-md border border-red-300 text-red-700 px-3 py-1.5 hover:bg-red-50 transition">
            Archive
          </button>
        </form>
        {question.status === "ARCHIVED" && (
          <form action={setQuestionStatus.bind(null, question.id, "DRAFT")}>
            <button className="text-xs font-medium rounded-md border border-slate-300 text-slate-600 px-3 py-1.5 hover:bg-slate-50 transition">
              Restore to Draft
            </button>
          </form>
        )}
        <Link
          href={`/questions/${question.id}/preview`}
          className="text-xs font-medium rounded-md border border-slate-300 text-slate-600 px-3 py-1.5 hover:bg-slate-50 transition"
        >
          Preview
        </Link>
        <form action={duplicateQuestion.bind(null, question.id)}>
          <button className="text-xs font-medium rounded-md border border-slate-300 text-slate-600 px-3 py-1.5 hover:bg-slate-50 transition">
            Duplicate
          </button>
        </form>
        <form action={deleteQuestion.bind(null, question.id)}>
          <button className="text-xs font-medium rounded-md border border-red-300 text-red-700 px-3 py-1.5 hover:bg-red-50 transition">
            Delete
          </button>
        </form>
      </div>

      {/* Core fields */}
      <form action={updateAction} className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Question text
          </label>
          <textarea
            name="questionText"
            rows={3}
            defaultValue={question.questionText}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono"
          />
          <div className="mt-2 p-3 bg-slate-50 rounded-md">
            <p className="text-xs text-slate-400 mb-1">Rendered preview:</p>
            <MathContent text={question.questionText} className="text-sm text-slate-700" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Image / diagram URL
          </label>
          <input
            name="imageUrl"
            defaultValue={question.imageUrl ?? ""}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Difficulty
            </label>
            <select
              name="difficulty"
              defaultValue={question.difficulty}
              className="w-full rounded-md border border-slate-300 px-2 py-2 text-sm"
            >
              <option value="EASY">Easy</option>
              <option value="MEDIUM">Medium</option>
              <option value="HARD">Hard</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Marks
            </label>
            <input
              name="marks"
              type="number"
              min={1}
              defaultValue={question.marks}
              className="w-full rounded-md border border-slate-300 px-2 py-2 text-sm"
            />
          </div>
        </div>

        {!showOptions && (
          <>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Correct answer
              </label>
              <input
                name="correctAnswer"
                defaultValue={question.correctAnswer}
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Accepted equivalent answers (one per line)
              </label>
              <textarea
                name="acceptedAnswers"
                rows={2}
                defaultValue={question.acceptedAnswers ?? ""}
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono"
                placeholder={
                  question.type === "ALGEBRAIC_EXPRESSION"
                    ? "e.g. 2x+4\n2(x+2)"
                    : undefined
                }
              />
              <p className="text-xs text-slate-400 mt-1">
                Mathematically equivalent forms the auto-grader should also
                accept (spec §28) — exact string match plus this list; full
                symbolic equivalence checking is a later refinement.
              </p>
            </div>
          </>
        )}

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Explanation
          </label>
          <textarea
            name="explanation"
            rows={2}
            defaultValue={question.explanation ?? ""}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Save Question
        </button>
      </form>

      {/* Options — MCQ / True-False only */}
      {showOptions && (
        <div className="bg-white rounded-lg border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-3">
            Answer Options
          </p>
          <ul className="space-y-1.5 mb-3">
            {question.options.map((opt) => (
              <li
                key={opt.id}
                className="flex items-center justify-between text-sm bg-slate-50 rounded-md px-3 py-2"
              >
                <span className={opt.isCorrect ? "font-medium text-green-700" : "text-slate-700"}>
                  {opt.isCorrect && "✓ "}
                  {opt.text}
                </span>
                <form action={deleteQuestionOption.bind(null, question.id, opt.id)}>
                  <button className="text-xs text-red-600 hover:underline">
                    Remove
                  </button>
                </form>
              </li>
            ))}
            {question.options.length === 0 && (
              <li className="text-xs text-slate-400">No options yet.</li>
            )}
          </ul>
          <form
            action={addQuestionOption.bind(null, question.id)}
            className="flex flex-wrap gap-2 items-center"
          >
            <input
              name="text"
              placeholder="Option text"
              className="rounded-md border border-slate-300 px-2 py-1.5 text-sm flex-1 min-w-[160px]"
            />
            <label className="flex items-center gap-1.5 text-xs text-slate-600">
              <input type="checkbox" name="isCorrect" />
              Correct answer
            </label>
            <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">
              + Add Option
            </button>
          </form>
        </div>
      )}

      {/* Hints — spec §29 */}
      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">Hints</p>
        <ol className="space-y-1.5 mb-3 list-decimal list-inside">
          {question.hints.map((hint) => (
            <li key={hint.id} className="text-sm text-slate-700 flex items-center justify-between">
              <span>{hint.text}</span>
              <form action={deleteHint.bind(null, question.id, hint.id)}>
                <button className="text-xs text-red-600 hover:underline ml-2">
                  Remove
                </button>
              </form>
            </li>
          ))}
          {question.hints.length === 0 && (
            <li className="text-xs text-slate-400 list-none">No hints yet.</li>
          )}
        </ol>
        <form action={addHint.bind(null, question.id)} className="flex gap-2">
          <input
            name="text"
            placeholder={`Hint ${question.hints.length + 1}`}
            className="flex-1 rounded-md border border-slate-300 px-2 py-1.5 text-sm"
          />
          <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">
            + Add Hint
          </button>
        </form>
      </div>

      {/* Solution — spec §30 */}
      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">Solution</p>
        <form action={setSolution.bind(null, question.id)} className="space-y-3">
          <textarea
            name="text"
            rows={3}
            defaultValue={solution?.text ?? ""}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            placeholder="Step-by-step solution"
          />
          <label className="flex items-center gap-2 text-xs text-slate-600">
            <input
              type="checkbox"
              name="isAvailableDuringExam"
              defaultChecked={solution?.isAvailableDuringExam ?? false}
            />
            Show this solution during formal examinations (off by default —
            spec §30)
          </label>
          <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">
            Save Solution
          </button>
        </form>
      </div>
    </div>
  );
}
