import { prisma } from "@/lib/prisma";
import { createQuestion } from "@/lib/actions/questions";

export default async function NewQuestionPage() {
  const courses = await prisma.course.findMany({ orderBy: { name: "asc" } });
  const topics = await prisma.topic.findMany({
    orderBy: { name: "asc" },
    include: {
      subStrand: {
        include: { strand: { include: { academicLevel: { include: { course: true } } } } },
      },
    },
    take: 300,
  });

  return (
    <div className="max-w-lg mx-auto space-y-4">
      <h1 className="text-xl font-bold text-slate-800">New Question</h1>

      <form
        action={createQuestion}
        className="bg-white rounded-lg border border-slate-200 p-5 space-y-4"
      >
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Course *
          </label>
          <select
            name="courseId"
            required
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Topic
          </label>
          <select
            name="topicId"
            defaultValue=""
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">— None —</option>
            {topics.map((t) => (
              <option key={t.id} value={t.id}>
                {t.subStrand.strand.academicLevel.name} /{" "}
                {t.subStrand.strand.name} / {t.subStrand.name} / {t.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Question text *
          </label>
          <textarea
            name="questionText"
            required
            rows={3}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono"
            placeholder="Supports $inline$ and $$display$$ LaTeX"
          />
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Type
            </label>
            <select
              name="type"
              defaultValue="MULTIPLE_CHOICE"
              className="w-full rounded-md border border-slate-300 px-2 py-2 text-sm"
            >
              <option value="MULTIPLE_CHOICE">Multiple Choice</option>
              <option value="NUMERICAL">Numerical</option>
              <option value="SHORT_ANSWER">Short Answer</option>
              <option value="ALGEBRAIC_EXPRESSION">Algebraic Expression</option>
              <option value="TRUE_FALSE">True/False</option>
              <option value="STRUCTURED">Structured</option>
              <option value="DIAGRAM_IMAGE">Diagram/Image</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Difficulty
            </label>
            <select
              name="difficulty"
              defaultValue="MEDIUM"
              className="w-full rounded-md border border-slate-300 px-2 py-2 text-sm"
            >
              <option value="EASY">Easy</option>
              <option value="MEDIUM">Medium</option>
              <option value="HARD">Hard</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Marks
            </label>
            <input
              name="marks"
              type="number"
              min={1}
              defaultValue={1}
              className="w-full rounded-md border border-slate-300 px-2 py-2 text-sm"
            />
          </div>
        </div>

        <p className="text-xs text-slate-400">
          You&apos;ll add options, the correct answer, hints, and a solution
          on the next screen.
        </p>

        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Create & Continue
        </button>
      </form>
    </div>
  );
}
