import Link from "next/link";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

const TYPE_LABEL: Record<string, string> = {
  MULTIPLE_CHOICE: "Multiple Choice",
  NUMERICAL: "Numerical",
  SHORT_ANSWER: "Short Answer",
  ALGEBRAIC_EXPRESSION: "Algebraic Expression",
  TRUE_FALSE: "True/False",
  STRUCTURED: "Structured",
  DIAGRAM_IMAGE: "Diagram/Image",
};

const STATUS_BADGE: Record<string, string> = {
  DRAFT: "bg-slate-100 text-slate-600",
  ACTIVE: "bg-green-100 text-green-700",
  ARCHIVED: "bg-red-100 text-red-700",
};

export default async function QuestionsPage({
  searchParams,
}: {
  searchParams: {
    q?: string;
    courseId?: string;
    difficulty?: string;
    type?: string;
    status?: string;
  };
}) {
  const courses = await prisma.course.findMany({ orderBy: { name: "asc" } });

  const where: Prisma.QuestionWhereInput = {};
  if (searchParams.q) {
    where.questionText = { contains: searchParams.q, mode: "insensitive" };
  }
  if (searchParams.courseId) where.courseId = searchParams.courseId;
  if (searchParams.difficulty) where.difficulty = searchParams.difficulty as never;
  if (searchParams.type) where.type = searchParams.type as never;
  if (searchParams.status) where.status = searchParams.status as never;

  const questions = await prisma.question.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { course: true, topic: true, options: true },
    take: 50,
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Question Bank</h1>
        <Link
          href="/questions/new"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          + New Question
        </Link>
      </div>

      <form className="bg-white rounded-lg border border-slate-200 p-4 flex flex-wrap gap-3">
        <input
          name="q"
          defaultValue={searchParams.q}
          placeholder="Search question text..."
          className="flex-1 min-w-[180px] rounded-md border border-slate-300 px-3 py-1.5 text-sm"
        />
        <select
          name="courseId"
          defaultValue={searchParams.courseId ?? ""}
          className="rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        >
          <option value="">All courses</option>
          {courses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          name="type"
          defaultValue={searchParams.type ?? ""}
          className="rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        >
          <option value="">All types</option>
          {Object.entries(TYPE_LABEL).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
        <select
          name="difficulty"
          defaultValue={searchParams.difficulty ?? ""}
          className="rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        >
          <option value="">All difficulties</option>
          <option value="EASY">Easy</option>
          <option value="MEDIUM">Medium</option>
          <option value="HARD">Hard</option>
        </select>
        <select
          name="status"
          defaultValue={searchParams.status ?? ""}
          className="rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        >
          <option value="">All statuses</option>
          <option value="DRAFT">Draft</option>
          <option value="ACTIVE">Active</option>
          <option value="ARCHIVED">Archived</option>
        </select>
        <button className="text-sm font-medium rounded-md border border-slate-300 px-3 py-1.5 hover:bg-slate-50 transition">
          Filter
        </button>
      </form>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {questions.map((q) => (
          <Link
            key={q.id}
            href={`/questions/${q.id}/edit`}
            className="block p-4 hover:bg-slate-50 transition"
          >
            <div className="flex items-start justify-between gap-3">
              <p className="text-sm text-slate-700 line-clamp-2">
                {q.questionText}
              </p>
              <span
                className={`shrink-0 text-[10px] font-medium rounded-full px-2 py-0.5 ${STATUS_BADGE[q.status]}`}
              >
                {q.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1.5">
              {q.course.name} · {q.topic?.name ?? "No topic"} ·{" "}
              {TYPE_LABEL[q.type]} · {q.difficulty} · {q.marks} mark
              {q.marks === 1 ? "" : "s"}
              {q.type === "MULTIPLE_CHOICE" && ` · ${q.options.length} options`}
            </p>
          </Link>
        ))}
        {questions.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">
            No questions match these filters.
          </p>
        )}
      </div>
    </div>
  );
}
