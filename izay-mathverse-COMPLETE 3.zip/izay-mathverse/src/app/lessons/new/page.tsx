import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { createLesson } from "@/lib/actions/lessons";

export default async function NewLessonPage({
  searchParams,
}: {
  searchParams: { topicId?: string };
}) {
  const topicId = searchParams.topicId;
  if (!topicId) notFound();

  const topic = await prisma.topic.findUnique({
    where: { id: topicId },
    include: {
      subStrand: {
        include: {
          strand: { include: { academicLevel: { include: { course: true } } } },
        },
      },
    },
  });

  if (!topic) notFound();

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <div>
        <p className="text-xs text-slate-400">
          {topic.subStrand.strand.academicLevel.course.name} /{" "}
          {topic.subStrand.strand.academicLevel.name} /{" "}
          {topic.subStrand.strand.name} / {topic.subStrand.name}
        </p>
        <h1 className="text-xl font-bold text-slate-800 mt-1">
          New Lesson — {topic.name}
        </h1>
      </div>

      <form
        action={createLesson}
        className="bg-white rounded-lg border border-slate-200 p-5 space-y-4"
      >
        <input type="hidden" name="topicId" value={topic.id} />
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Lesson title *
          </label>
          <input
            name="title"
            required
            autoFocus
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            placeholder="e.g. Introduction to Binary Operations"
          />
        </div>
        <p className="text-xs text-slate-400">
          You&apos;ll add the full content — objectives, explanation,
          examples, media — on the next screen. This starts the lesson as a
          Draft.
        </p>
        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Create & Continue
        </button>
      </form>
    </div>
  );
}
