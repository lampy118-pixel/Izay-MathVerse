import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { LessonViewer } from "@/components/lesson-viewer";

export default async function LessonPreviewPage({
  params,
}: {
  params: { id: string };
}) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: params.id },
    include: {
      images: true,
      videos: true,
      materials: true,
      geogebraActivities: true,
      desmosActivities: true,
      externalResources: true,
      practiceQuestions: true,
    },
  });

  if (!lesson) notFound();

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <Link
          href={`/lessons/${lesson.id}/edit`}
          className="text-xs text-brand-700 hover:underline"
        >
          ← Back to editor
        </Link>
        <span className="text-xs font-medium bg-slate-100 text-slate-600 rounded-full px-2.5 py-0.5">
          Previewing as {lesson.status}
        </span>
      </div>
      <LessonViewer lesson={lesson} />
    </div>
  );
}
