import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import {
  updateLessonContent,
  setLessonStatus,
  addLessonImage,
  addLessonVideo,
  addLessonMaterial,
  addGeogebraActivity,
  addDesmosActivity,
  addExternalResource,
} from "@/lib/actions/lessons";
import {
  attachQuestionToLesson,
  detachQuestionFromLesson,
} from "@/lib/actions/questions";

const FIELD_ROWS: Array<{
  name: keyof typeof FIELD_LABELS;
  rows: number;
}> = [
  { name: "description", rows: 2 },
  { name: "learningObjective", rows: 2 },
  { name: "introduction", rows: 3 },
  { name: "definitions", rows: 3 },
  { name: "mainExplanation", rows: 6 },
  { name: "examples", rows: 5 },
  { name: "realLifeApplications", rows: 3 },
  { name: "formulae", rows: 3 },
  { name: "notes", rows: 3 },
];

const FIELD_LABELS = {
  description: "Description",
  learningObjective: "Learning Objective",
  introduction: "Introduction",
  definitions: "Definitions",
  mainExplanation: "Main Explanation",
  examples: "Worked Examples",
  realLifeApplications: "Real-Life Applications",
  formulae: "Formulae",
  notes: "Notes",
} as const;

export default async function LessonEditPage({
  params,
}: {
  params: { id: string };
}) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: params.id },
    include: {
      topic: {
        include: {
          subStrand: {
            include: {
              strand: { include: { academicLevel: { include: { course: true } } } },
            },
          },
          learningOutcomes: true,
          contentStandards: { include: { learningIndicators: true } },
        },
      },
      images: true,
      videos: true,
      materials: true,
      geogebraActivities: true,
      desmosActivities: true,
      externalResources: true,
      practiceQuestions: true,
    },
  });

  if (!lesson) notFound();

  const allIndicators = lesson.topic.contentStandards.flatMap(
    (cs) => cs.learningIndicators
  );

  const attachedQuestionIds = new Set(lesson.practiceQuestions.map((q) => q.id));
  const availableQuestions = await prisma.question.findMany({
    where: {
      status: "ACTIVE",
      id: { notIn: Array.from(attachedQuestionIds) },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  const updateAction = updateLessonContent.bind(null, lesson.id);

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
      <div>
        <p className="text-xs text-slate-400">
          {lesson.topic.subStrand.strand.academicLevel.course.name} /{" "}
          {lesson.topic.subStrand.strand.academicLevel.name} /{" "}
          {lesson.topic.subStrand.strand.name} /{" "}
          {lesson.topic.subStrand.name} / {lesson.topic.name}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <h1 className="text-xl font-bold text-slate-800">{lesson.title}</h1>
          <span className="text-xs font-medium bg-slate-100 text-slate-600 rounded-full px-2.5 py-0.5">
            {lesson.status}
          </span>
        </div>
      </div>

      {/* Status controls — spec §16 buttons, §19 statuses */}
      <div className="flex flex-wrap gap-2">
        <form action={setLessonStatus.bind(null, lesson.id, "DRAFT")}>
          <button className="text-xs font-medium rounded-md border border-slate-300 text-slate-600 px-3 py-1.5 hover:bg-slate-50 transition">
            Save Draft
          </button>
        </form>
        <Link
          href={`/lessons/${lesson.id}/preview`}
          className="text-xs font-medium rounded-md border border-slate-300 text-slate-600 px-3 py-1.5 hover:bg-slate-50 transition"
        >
          Preview
        </Link>
        <form action={setLessonStatus.bind(null, lesson.id, "PUBLISHED")}>
          <button className="text-xs font-medium rounded-md border border-green-300 text-green-700 px-3 py-1.5 hover:bg-green-50 transition">
            Publish
          </button>
        </form>
        <form action={setLessonStatus.bind(null, lesson.id, "ARCHIVED")}>
          <button className="text-xs font-medium rounded-md border border-red-300 text-red-700 px-3 py-1.5 hover:bg-red-50 transition">
            Archive
          </button>
        </form>
      </div>

      {/* Core content fields */}
      <form action={updateAction} className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Lesson title
          </label>
          <input
            name="title"
            defaultValue={lesson.title}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Curriculum Learning Indicator
          </label>
          <select
            name="learningIndicatorId"
            defaultValue={lesson.learningIndicatorId ?? ""}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">— None —</option>
            {allIndicators.map((li) => (
              <option key={li.id} value={li.id}>
                {li.code} — {li.statement.slice(0, 60)}
                {li.statement.length > 60 ? "…" : ""}
              </option>
            ))}
          </select>
        </div>

        {FIELD_ROWS.map((field) => (
          <div key={field.name}>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              {FIELD_LABELS[field.name]}
            </label>
            <textarea
              name={field.name}
              rows={field.rows}
              defaultValue={lesson[field.name] ?? ""}
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono"
              placeholder={
                field.name === "formulae" || field.name === "examples"
                  ? "Wrap math in $...$ (inline) or $$...$$ (display), e.g. $$x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}$$"
                  : undefined
              }
            />
          </div>
        ))}

        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Save Content
        </button>
      </form>

      {/* Images / Diagrams / Graphs */}
      <AttachedSection title="Images, Diagrams & Graphs">
        <ul className="space-y-1 mb-3">
          {lesson.images.map((img) => (
            <li key={img.id} className="text-sm text-slate-600">
              [{img.kind}] {img.caption ?? img.url}
            </li>
          ))}
        </ul>
        <form
          action={addLessonImage.bind(null, lesson.id)}
          className="flex flex-wrap gap-2 items-end"
        >
          <MiniField name="url" label="Image URL" />
          <select name="kind" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm">
            <option value="image">Image</option>
            <option value="diagram">Diagram</option>
            <option value="graph">Graph</option>
          </select>
          <MiniField name="caption" label="Caption (optional)" />
          <SmallSubmit />
        </form>
      </AttachedSection>

      {/* Videos */}
      <AttachedSection title="Videos">
        <ul className="space-y-1 mb-3">
          {lesson.videos.map((v) => (
            <li key={v.id} className="text-sm text-slate-600">
              [{v.source}] {v.title} — {v.url}
            </li>
          ))}
        </ul>
        <form
          action={addLessonVideo.bind(null, lesson.id)}
          className="flex flex-wrap gap-2 items-end"
        >
          <MiniField name="title" label="Title" />
          <MiniField name="url" label="URL" />
          <select name="source" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm">
            <option value="YOUTUBE">YouTube</option>
            <option value="UPLOADED">Uploaded file (needs storage — see README)</option>
          </select>
          <SmallSubmit />
        </form>
      </AttachedSection>

      {/* Learning Materials */}
      <AttachedSection title="Learning Materials">
        <ul className="space-y-1 mb-3">
          {lesson.materials.map((m) => (
            <li key={m.id} className="text-sm text-slate-600">
              [{m.fileType}] {m.title}
            </li>
          ))}
        </ul>
        <form
          action={addLessonMaterial.bind(null, lesson.id)}
          className="flex flex-wrap gap-2 items-end"
        >
          <MiniField name="title" label="Title" />
          <MiniField name="fileUrl" label="File URL" />
          <select name="fileType" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm">
            {["PDF", "PPT", "PPTX", "DOC", "DOCX", "IMAGE", "WORKSHEET", "WORKED_SOLUTION", "OTHER"].map(
              (t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              )
            )}
          </select>
          <SmallSubmit />
        </form>
        <p className="text-xs text-slate-400 mt-2">
          File hosting isn&apos;t configured in this build yet — paste a URL
          to an already-hosted file for now (spec §64: no pretend upload
          system).
        </p>
      </AttachedSection>

      {/* GeoGebra */}
      <AttachedSection title="GeoGebra Activities">
        <ul className="space-y-1 mb-3">
          {lesson.geogebraActivities.map((g) => (
            <li key={g.id} className="text-sm text-slate-600">
              {g.title} — {g.url}
            </li>
          ))}
        </ul>
        <form
          action={addGeogebraActivity.bind(null, lesson.id, lesson.topicId)}
          className="flex flex-wrap gap-2 items-end"
        >
          <MiniField name="title" label="Title" />
          <MiniField name="url" label="GeoGebra URL" />
          <MiniField name="description" label="Description (optional)" />
          <SmallSubmit />
        </form>
      </AttachedSection>

      {/* Desmos */}
      <AttachedSection title="Desmos Activities">
        <ul className="space-y-1 mb-3">
          {lesson.desmosActivities.map((d) => (
            <li key={d.id} className="text-sm text-slate-600">
              {d.title} — {d.url}
            </li>
          ))}
        </ul>
        <form
          action={addDesmosActivity.bind(null, lesson.id, lesson.topicId)}
          className="flex flex-wrap gap-2 items-end"
        >
          <MiniField name="title" label="Title" />
          <MiniField name="url" label="Desmos URL" />
          <MiniField name="description" label="Description (optional)" />
          <SmallSubmit />
        </form>
      </AttachedSection>

      {/* External Resources */}
      <AttachedSection title="External Resources">
        <ul className="space-y-1 mb-3">
          {lesson.externalResources.map((r) => (
            <li key={r.id} className="text-sm text-slate-600">
              [{r.provider}] {r.title} — {r.url}
            </li>
          ))}
        </ul>
        <form
          action={addExternalResource.bind(null, lesson.id)}
          className="flex flex-wrap gap-2 items-end"
        >
          <MiniField name="title" label="Title" />
          <MiniField name="url" label="URL" />
          <select name="provider" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm">
            {["YOUTUBE", "GEOGEBRA", "DESMOS", "GOOGLE_FORMS", "KAHOOT", "KHAN_ACADEMY", "OTHER"].map(
              (p) => (
                <option key={p} value={p}>
                  {p.replace("_", " ")}
                </option>
              )
            )}
          </select>
          <SmallSubmit />
        </form>
      </AttachedSection>

      {/* Practice Questions — spec §25, attach from the Question Bank */}
      <AttachedSection title="Practice Questions">
        <ul className="space-y-1 mb-3">
          {lesson.practiceQuestions.map((q) => (
            <li key={q.id} className="text-sm text-slate-600 flex items-center justify-between">
              <span className="truncate">
                [{q.status}] {q.questionText.slice(0, 70)}
                {q.questionText.length > 70 ? "…" : ""}
              </span>
              <form action={detachQuestionFromLesson.bind(null, lesson.id, q.id)}>
                <button className="text-xs text-red-600 hover:underline ml-2 shrink-0">
                  Remove
                </button>
              </form>
            </li>
          ))}
          {lesson.practiceQuestions.length === 0 && (
            <li className="text-xs text-slate-400">No practice questions attached yet.</li>
          )}
        </ul>
        <form
          action={attachQuestionToLesson.bind(null, lesson.id)}
          className="flex flex-wrap gap-2 items-center"
        >
          <select
            name="questionId"
            className="rounded-md border border-slate-300 px-2 py-1.5 text-sm flex-1 min-w-[220px]"
          >
            <option value="">— Select a question from the bank —</option>
            {availableQuestions.map((q) => (
              <option key={q.id} value={q.id}>
                {q.questionText.slice(0, 60)}
                {q.questionText.length > 60 ? "…" : ""}
              </option>
            ))}
          </select>
          <SmallSubmit />
        </form>
        <Link
          href="/questions/new"
          className="text-xs text-brand-700 hover:underline mt-2 inline-block"
        >
          + Create a new question in the bank
        </Link>
      </AttachedSection>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800">
        Quizzes, tests, and assignments built from these bank questions
        arrive in Phases 6–7.
      </div>
    </div>
  );
}

function AttachedSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-5">
      <p className="text-sm font-semibold text-slate-700 mb-3">{title}</p>
      {children}
    </div>
  );
}

function MiniField({ name, label }: { name: string; label: string }) {
  return (
    <div>
      <label className="block text-xs text-slate-500 mb-0.5">{label}</label>
      <input
        name={name}
        className="rounded-md border border-slate-300 px-2 py-1.5 text-sm"
      />
    </div>
  );
}

function SmallSubmit() {
  return (
    <button
      type="submit"
      className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition"
    >
      + Add
    </button>
  );
}
