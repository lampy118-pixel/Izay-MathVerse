import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function AttendancePage() {
  const classes = await prisma.class.findMany({
    orderBy: { name: "asc" },
    include: { students: true },
  });

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Take Attendance</h1>
      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {classes.map((c) => (
          <Link key={c.id} href={`/attendance/${c.id}`} className="block p-4 hover:bg-slate-50 transition">
            <p className="font-medium text-slate-800">{c.name}</p>
            <p className="text-xs text-slate-400">{c.students.length} students</p>
          </Link>
        ))}
        {classes.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">
            No classes yet — an admin can create one under Admin → Classes.
          </p>
        )}
      </div>
    </div>
  );
}
