import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { saveAttendance } from "@/lib/actions/attendance";

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export default async function ClassAttendancePage({
  params,
  searchParams,
}: {
  params: { classId: string };
  searchParams: { date?: string };
}) {
  const cls = await prisma.class.findUnique({
    where: { id: params.classId },
    include: { students: { include: { student: true }, orderBy: { student: { firstName: "asc" } } } },
  });
  if (!cls) notFound();

  const dateStr = searchParams.date ?? todayISO();
  const date = new Date(dateStr);

  const existing = await prisma.attendance.findMany({
    where: { classId: cls.id, date },
  });
  const existingMap = new Map(existing.map((a) => [a.studentId, a.status]));

  const saveAction = saveAttendance.bind(null, cls.id, dateStr);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-bold text-slate-800">{cls.name}</h1>
        <form method="GET" className="flex items-center gap-2 mt-2">
          <input
            type="date"
            name="date"
            defaultValue={dateStr}
            className="rounded-md border border-slate-300 px-2 py-1.5 text-sm"
          />
          <button className="text-xs font-medium rounded-md border border-slate-300 px-3 py-1.5 hover:bg-slate-50 transition">
            Go
          </button>
        </form>
      </div>

      <form action={saveAction} className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {cls.students.map((enrollment) => {
          const current = existingMap.get(enrollment.studentId) ?? "PRESENT";
          return (
            <div key={enrollment.id} className="p-3 flex items-center justify-between">
              <span className="text-sm text-slate-700">
                {enrollment.student.firstName} {enrollment.student.lastName}
              </span>
              <div className="flex gap-3">
                {(["PRESENT", "ABSENT", "LATE"] as const).map((status) => (
                  <label key={status} className="flex items-center gap-1 text-xs text-slate-600">
                    <input
                      type="radio"
                      name={`status_${enrollment.studentId}`}
                      value={status}
                      defaultChecked={current === status}
                    />
                    {status.charAt(0) + status.slice(1).toLowerCase()}
                  </label>
                ))}
              </div>
            </div>
          );
        })}
        {cls.students.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No students enrolled in this class.</p>
        )}
        {cls.students.length > 0 && (
          <div className="p-3">
            <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition">
              Save Attendance for {dateStr}
            </button>
          </div>
        )}
      </form>
    </div>
  );
}
