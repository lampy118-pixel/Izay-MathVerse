import { redirect } from "next/navigation";
import Link from "next/link";
import { getSessionUser } from "@/lib/rbac";

export default async function AnalyticsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if (!user || !["SUPER_ADMIN", "ADMIN", "TEACHER"].includes(user.role)) {
    redirect("/unauthorized");
  }

  const backHref = user.role === "TEACHER" ? "/teacher" : "/admin";

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div>
          <Link href={backHref} className="text-xs text-brand-700 hover:underline">
            ← Back to dashboard
          </Link>
          <p className="font-semibold text-slate-800">Analytics</p>
        </div>
        <p className="text-sm text-slate-500">{user.name}</p>
      </header>
      <main className="max-w-3xl mx-auto p-4 sm:p-6">{children}</main>
    </div>
  );
}
