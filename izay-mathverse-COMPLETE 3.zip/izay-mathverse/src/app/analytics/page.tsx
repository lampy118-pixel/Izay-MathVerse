import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function AnalyticsPage() {
  const [
    lessonCounts,
    questionCounts,
    quizAttempts,
    submissionCounts,
    topicProgress,
  ] = await Promise.all([
    prisma.lesson.groupBy({ by: ["status"], _count: true }),
    prisma.question.groupBy({ by: ["status"], _count: true }),
    prisma.quizAttempt.findMany({ where: { submittedAt: { not: null } } }),
    prisma.submission.groupBy({ by: ["status"], _count: true }),
    prisma.topicProgress.findMany({ where: { questionsAttempted: { gt: 0 } } }),
  ]);

  const avgQuizPercent =
    quizAttempts.length > 0
      ? quizAttempts.reduce(
          (sum, a) => sum + ((a.score ?? 0) / (a.maxScore || 1)) * 100,
          0
        ) / quizAttempts.length
      : null;

  // Class-wide topic performance — averaged across every student who has
  // attempted questions in that topic, worst first. Real attempt data
  // only, per spec §40's "do not invent performance statistics".
  const byTopic = new Map<string, { total: number; count: number }>();
  for (const p of topicProgress) {
    const entry = byTopic.get(p.topicId) ?? { total: 0, count: 0 };
    entry.total += p.performancePercent;
    entry.count += 1;
    byTopic.set(p.topicId, entry);
  }
  const topicIds = Array.from(byTopic.keys());
  const topics = await prisma.topic.findMany({ where: { id: { in: topicIds } } });
  const topicMap = new Map(topics.map((t) => [t.id, t]));

  const classWideTopicStats = topicIds
    .map((id) => ({
      topic: topicMap.get(id),
      avgPercent: byTopic.get(id)!.total / byTopic.get(id)!.count,
      studentCount: byTopic.get(id)!.count,
    }))
    .filter((t) => t.topic)
    .sort((a, b) => a.avgPercent - b.avgPercent);

  const countFor = (arr: { status: string; _count: number }[], status: string) =>
    arr.find((a) => a.status === status)?._count ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-800">Analytics</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Every number below comes directly from the database — nothing here is simulated.
          </p>
        </div>
        <Link href="/curriculum/completeness" className="text-sm text-brand-700 hover:underline">
          Curriculum Completeness →
        </Link>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <p className="text-sm font-semibold text-slate-700 mb-3">Lessons</p>
          <dl className="space-y-1 text-sm">
            <Row label="Draft" value={countFor(lessonCounts, "DRAFT")} />
            <Row label="Published" value={countFor(lessonCounts, "PUBLISHED")} />
            <Row label="Active" value={countFor(lessonCounts, "ACTIVE")} />
            <Row label="Archived" value={countFor(lessonCounts, "ARCHIVED")} />
          </dl>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <p className="text-sm font-semibold text-slate-700 mb-3">Question Bank</p>
          <dl className="space-y-1 text-sm">
            <Row label="Draft" value={countFor(questionCounts, "DRAFT")} />
            <Row label="Active" value={countFor(questionCounts, "ACTIVE")} />
            <Row label="Archived" value={countFor(questionCounts, "ARCHIVED")} />
          </dl>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <p className="text-sm font-semibold text-slate-700 mb-3">Quiz Activity</p>
          <dl className="space-y-1 text-sm">
            <Row label="Submitted attempts" value={quizAttempts.length} />
            <Row
              label="Average score"
              value={avgQuizPercent === null ? "—" : `${Math.round(avgQuizPercent)}%`}
            />
          </dl>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <p className="text-sm font-semibold text-slate-700 mb-3">Assignment Submissions</p>
          <dl className="space-y-1 text-sm">
            <Row label="Submitted" value={countFor(submissionCounts, "SUBMITTED")} />
            <Row label="Late" value={countFor(submissionCounts, "LATE")} />
            <Row label="Marked" value={countFor(submissionCounts, "MARKED")} />
            <Row label="Returned" value={countFor(submissionCounts, "RETURNED")} />
          </dl>
        </div>
      </div>

      <div>
        <p className="text-sm font-semibold text-slate-700 mb-3">
          Topic Performance (all students, worst first)
        </p>
        <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
          {classWideTopicStats.map((t) => (
            <div key={t.topic!.id} className="p-3 flex items-center justify-between text-sm">
              <div>
                <p className="text-slate-800">{t.topic!.name}</p>
                <p className="text-xs text-slate-400">
                  {t.studentCount} student{t.studentCount === 1 ? "" : "s"} attempted
                </p>
              </div>
              <span
                className={`font-semibold ${
                  t.avgPercent < 70 ? "text-amber-600" : "text-green-700"
                }`}
              >
                {Math.round(t.avgPercent)}%
              </span>
            </div>
          ))}
          {classWideTopicStats.length === 0 && (
            <p className="p-6 text-center text-sm text-slate-400">
              No practice attempts recorded yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-slate-500">{label}</dt>
      <dd className="font-medium text-slate-800">{value}</dd>
    </div>
  );
}
