import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";

export default async function StrandPage({
  params,
}: {
  params: { courseId: string; levelId: string; strandId: string };
}) {
  const strand = await prisma.strand.findUnique({
    where: { id: params.strandId },
    include: {
      academicLevel: { include: { course: true } },
      subStrands: { orderBy: { sortOrder: "asc" }, include: { topics: true } },
    },
  });

  if (!strand || strand.academicLevelId !== params.levelId) notFound();

  return (
    <div className="space-y-4">
      <nav className="text-xs text-slate-400">
        <Link href="/curriculum" className="hover:underline">
          {strand.academicLevel.course.name}
        </Link>{" "}
        /{" "}
        <Link
          href={`/curriculum/${params.courseId}/${params.levelId}`}
          className="hover:underline"
        >
          {strand.academicLevel.name}
        </Link>{" "}
        / {strand.name}
      </nav>
      <h1 className="text-xl font-bold text-slate-800">
        {strand.code}. {strand.name}
      </h1>

      <div className="space-y-3">
        {strand.subStrands.map((subStrand) => (
          <Link
            key={subStrand.id}
            href={`/curriculum/${params.courseId}/${params.levelId}/${params.strandId}/${subStrand.id}`}
            className="block bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition"
          >
            <p className="font-semibold text-slate-800">
              Sub-Strand {subStrand.code}. {subStrand.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {subStrand.topics.length} topic
              {subStrand.topics.length === 1 ? "" : "s"}
            </p>
          </Link>
        ))}
        {strand.subStrands.length === 0 && (
          <p className="text-sm text-slate-400">
            No sub-strands imported for this strand yet.
          </p>
        )}
      </div>
    </div>
  );
}
