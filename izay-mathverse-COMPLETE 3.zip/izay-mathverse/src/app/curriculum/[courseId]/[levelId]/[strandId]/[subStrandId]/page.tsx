import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { moveLesson } from "@/lib/actions/lessons";

const STATUS_BADGE: Record<string, string> = {
  DRAFT: "bg-slate-100 text-slate-600",
  PUBLISHED: "bg-green-100 text-green-700",
  ACTIVE: "bg-blue-100 text-blue-700",
  ARCHIVED: "bg-red-100 text-red-700",
};

export default async function SubStrandPage({
  params,
}: {
  params: {
    courseId: string;
    levelId: string;
    strandId: string;
    subStrandId: string;
  };
}) {
  const subStrand = await prisma.subStrand.findUnique({
    where: { id: params.subStrandId },
    include: {
      strand: { include: { academicLevel: { include: { course: true } } } },
      topics: {
        orderBy: { sortOrder: "asc" },
        include: {
          learningOutcomes: { orderBy: { sortOrder: "asc" } },
          contentStandards: {
            orderBy: { sortOrder: "asc" },
            include: {
              learningIndicators: {
                orderBy: { sortOrder: "asc" },
                include: {
                  activities: { orderBy: { sortOrder: "asc" } },
                  assessmentNotes: true,
                },
              },
            },
          },
          lessons: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
  });

  if (!subStrand || subStrand.strandId !== params.strandId) notFound();

  const user = await getSessionUser();
  const canManage =
    !!user && ["SUPER_ADMIN", "ADMIN", "TEACHER"].includes(user.role);

  const { strand } = subStrand;

  return (
    <div className="space-y-6">
      <nav className="text-xs text-slate-400">
        <Link href="/curriculum" className="hover:underline">
          {strand.academicLevel.course.name}
        </Link>{" "}
        /{" "}
        <Link
          href={`/curriculum/${params.courseId}/${params.levelId}`}
          className="hover:underline"
        >
          {strand.academicLevel.name}
        </Link>{" "}
        /{" "}
        <Link
          href={`/curriculum/${params.courseId}/${params.levelId}/${params.strandId}`}
          className="hover:underline"
        >
          {strand.name}
        </Link>{" "}
        / {subStrand.name}
      </nav>
      <h1 className="text-xl font-bold text-slate-800">
        {subStrand.code}. {subStrand.name}
      </h1>

      {subStrand.topics.map((topic) => (
        <div
          key={topic.id}
          className="bg-white rounded-lg border border-slate-200 p-5 space-y-5"
        >
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-slate-800">{topic.name}</h2>
            {canManage && (
              <Link
                href={`/lessons/new?topicId=${topic.id}`}
                className="text-xs font-medium text-brand-700 hover:underline"
              >
                + Add Lesson
              </Link>
            )}
          </div>

          {topic.lessons.length > 0 && (
            <div className="space-y-1.5">
              {topic.lessons.map((lesson, idx) => (
                <div
                  key={lesson.id}
                  className="flex items-center justify-between text-sm bg-slate-50 rounded-md px-3 py-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-slate-400 text-xs shrink-0">
                      {idx + 1}.
                    </span>
                    <span className="truncate text-slate-700">
                      {lesson.title}
                    </span>
                    <span
                      className={`shrink-0 text-[10px] font-medium rounded-full px-2 py-0.5 ${
                        STATUS_BADGE[lesson.status]
                      }`}
                    >
                      {lesson.status}
                    </span>
                  </div>
                  {canManage && (
                    <div className="flex items-center gap-2 shrink-0">
                      <form action={moveLesson.bind(null, lesson.id, "up")}>
                        <button
                          disabled={idx === 0}
                          className="text-slate-400 hover:text-brand-700 disabled:opacity-30 text-xs"
                          title="Move up"
                        >
                          ↑
                        </button>
                      </form>
                      <form action={moveLesson.bind(null, lesson.id, "down")}>
                        <button
                          disabled={idx === topic.lessons.length - 1}
                          className="text-slate-400 hover:text-brand-700 disabled:opacity-30 text-xs"
                          title="Move down"
                        >
                          ↓
                        </button>
                      </form>
                      <Link
                        href={`/lessons/${lesson.id}/edit`}
                        className="text-xs text-brand-700 hover:underline"
                      >
                        Edit
                      </Link>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
          {topic.lessons.length === 0 && (
            <p className="text-xs text-slate-400">No lessons yet.</p>
          )}

          {topic.learningOutcomes.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">
                Learning Outcomes
              </p>
              <ul className="space-y-2">
                {topic.learningOutcomes.map((lo) => (
                  <li key={lo.id} className="text-sm">
                    <span className="font-mono text-xs text-brand-700 mr-2">
                      {lo.code}
                    </span>
                    <span className="text-slate-700">{lo.statement}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {topic.contentStandards.map((cs) => (
            <div key={cs.id} className="border-t border-slate-100 pt-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-1">
                Content Standard
              </p>
              <p className="text-sm mb-3">
                <span className="font-mono text-xs text-brand-700 mr-2">
                  {cs.code}
                </span>
                <span className="text-slate-700">{cs.statement}</span>
              </p>

              {cs.learningIndicators.map((li) => (
                <div
                  key={li.id}
                  className="ml-3 pl-3 border-l-2 border-slate-100 mb-4"
                >
                  <p className="text-sm">
                    <span className="font-mono text-xs text-brand-700 mr-2">
                      {li.code}
                    </span>
                    <span className="text-slate-700">{li.statement}</span>
                  </p>
                  {li.pedagogicalApproach && (
                    <p className="text-xs text-slate-500 mt-1 italic">
                      {li.pedagogicalApproach}
                    </p>
                  )}

                  {li.activities.length > 0 && (
                    <div className="mt-2 space-y-1.5">
                      {li.activities.map((activity) => (
                        <div
                          key={activity.id}
                          className="text-xs bg-slate-50 rounded-md p-2"
                        >
                          <p className="font-medium text-slate-700">
                            {activity.title}
                          </p>
                          <p className="text-slate-500 mt-0.5 whitespace-pre-line">
                            {activity.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  {li.assessmentNotes.length > 0 && (
                    <div className="mt-2 space-y-1.5">
                      {li.assessmentNotes.map((note) => (
                        <div
                          key={note.id}
                          className="text-xs bg-amber-50 rounded-md p-2"
                        >
                          <p className="font-medium text-amber-800">
                            {note.code} — DoK Level {note.dokLevel}:{" "}
                            {note.dokLabel}
                          </p>
                          <p className="text-amber-700 mt-0.5 whitespace-pre-line">
                            {note.sampleItem}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}

      {subStrand.topics.length === 0 && (
        <p className="text-sm text-slate-400">
          No topics imported for this sub-strand yet.
        </p>
      )}
    </div>
  );
}
