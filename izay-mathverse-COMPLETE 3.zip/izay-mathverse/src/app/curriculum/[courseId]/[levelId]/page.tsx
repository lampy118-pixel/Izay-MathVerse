import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";

export default async function LevelPage({
  params,
}: {
  params: { courseId: string; levelId: string };
}) {
  const level = await prisma.academicLevel.findUnique({
    where: { id: params.levelId },
    include: {
      course: true,
      strands: {
        orderBy: { sortOrder: "asc" },
        include: { subStrands: true },
      },
    },
  });

  if (!level || level.courseId !== params.courseId) notFound();

  return (
    <div className="space-y-4">
      <nav className="text-xs text-slate-400">
        <Link href="/curriculum" className="hover:underline">
          {level.course.name}
        </Link>{" "}
        / {level.name}
      </nav>
      <h1 className="text-xl font-bold text-slate-800">
        {level.course.name} — {level.name}
      </h1>

      <div className="grid sm:grid-cols-2 gap-3">
        {level.strands.map((strand) => (
          <Link
            key={strand.id}
            href={`/curriculum/${params.courseId}/${params.levelId}/${strand.id}`}
            className="bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition"
          >
            <p className="font-semibold text-slate-800">
              Strand {strand.code}. {strand.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {strand.subStrands.length} sub-strand
              {strand.subStrands.length === 1 ? "" : "s"}
            </p>
          </Link>
        ))}
        {level.strands.length === 0 && (
          <p className="text-sm text-slate-400">
            No strands imported for {level.name} yet.
          </p>
        )}
      </div>
    </div>
  );
}
