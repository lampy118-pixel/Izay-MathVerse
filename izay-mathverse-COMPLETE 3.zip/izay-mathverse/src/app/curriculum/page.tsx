import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function CurriculumCoursesPage() {
  const courses = await prisma.course.findMany({
    orderBy: { name: "asc" },
    include: { levels: { orderBy: { sortOrder: "asc" } } },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Curriculum</h1>
        <div className="flex gap-3">
          <Link
            href="/curriculum/completeness"
            className="text-sm font-medium text-brand-700 hover:underline"
          >
            Completeness →
          </Link>
          <Link
            href="/curriculum/import"
            className="text-sm font-medium text-brand-700 hover:underline"
          >
            Import curriculum →
          </Link>
        </div>
      </div>

      <div className="space-y-3">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-white rounded-lg border border-slate-200 p-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-slate-800">{course.name}</h2>
              <span
                className={
                  course.status === "AVAILABLE"
                    ? "text-xs font-medium bg-green-100 text-green-700 rounded-full px-2.5 py-0.5"
                    : "text-xs font-medium bg-red-100 text-red-700 rounded-full px-2.5 py-0.5"
                }
              >
                {course.status === "AVAILABLE" ? "Available" : "Restricted"}
              </span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {course.levels.map((level) => (
                <Link
                  key={level.id}
                  href={`/curriculum/${course.id}/${level.id}`}
                  className="text-sm rounded-md border border-slate-200 px-3 py-1.5 text-slate-700 hover:border-brand-400 hover:text-brand-700 transition"
                >
                  {level.name}
                </Link>
              ))}
              {course.levels.length === 0 && (
                <p className="text-sm text-slate-400">
                  No curriculum imported yet for this course.
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
