import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function CurriculumCompletenessPage() {
  const topics = await prisma.topic.findMany({
    include: {
      subStrand: {
        include: { strand: { include: { academicLevel: { include: { course: true } } } } },
      },
      contentStandards: {
        include: { learningIndicators: { include: { lessons: true, questions: { include: { quizQuestions: true } } } } },
      },
    },
    orderBy: { name: "asc" },
  });

  const rows = topics
    .map((topic) => {
      const indicators = topic.contentStandards.flatMap((cs) => cs.learningIndicators);
      const total = indicators.length;
      if (total === 0) return null; // nothing imported yet for this topic — not a gap to report on

      const withLesson = indicators.filter((li) =>
        li.lessons.some((l) => l.status !== "ARCHIVED")
      ).length;
      const withPractice = indicators.filter((li) =>
        li.questions.some((q) => q.status === "ACTIVE")
      ).length;
      const withAssessment = indicators.filter((li) =>
        li.questions.some((q) => q.status === "ACTIVE" && q.quizQuestions.length > 0)
      ).length;

      return {
        topic,
        total,
        withLesson,
        withPractice,
        withAssessment,
        gap: total - withLesson,
      };
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)
    .sort((a, b) => b.gap - a.gap);

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Curriculum Completeness</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Learning Indicators without lessons, practice, or quiz coverage —
          computed live from the curriculum tree, lessons, and question bank.
        </p>
      </div>

      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.topic.id} className="bg-white rounded-lg border border-slate-200 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-800">{r.topic.name}</p>
                <p className="text-xs text-slate-400">
                  {r.topic.subStrand.strand.academicLevel.course.name} /{" "}
                  {r.topic.subStrand.strand.academicLevel.name} /{" "}
                  {r.topic.subStrand.strand.name} / {r.topic.subStrand.name}
                </p>
              </div>
              <Link
                href={`/curriculum/${r.topic.subStrand.strand.academicLevel.courseId}/${r.topic.subStrand.strand.academicLevelId}/${r.topic.subStrand.strandId}/${r.topic.subStrandId}`}
                className="text-xs text-brand-700 hover:underline shrink-0"
              >
                View →
              </Link>
            </div>

            <dl className="grid grid-cols-3 gap-3 mt-3 text-sm">
              <div>
                <dt className="text-xs text-slate-400">Curriculum Items</dt>
                <dd className="font-medium text-slate-700">{r.total}</dd>
              </div>
              <div>
                <dt className="text-xs text-slate-400">Lessons</dt>
                <dd className="font-medium text-slate-700">{r.withLesson} / {r.total}</dd>
              </div>
              <div>
                <dt className="text-xs text-slate-400">Practice</dt>
                <dd className="font-medium text-slate-700">{r.withPractice} / {r.total}</dd>
              </div>
            </dl>
            <p className="text-xs text-slate-400 mt-1">
              Assessment (in a quiz pool): {r.withAssessment} / {r.total}
            </p>

            {r.gap > 0 && (
              <p className="text-xs text-amber-600 bg-amber-50 rounded-md px-2 py-1 mt-2 inline-block">
                ⚠ {r.gap} curriculum item{r.gap === 1 ? "" : "s"} need{r.gap === 1 ? "s" : ""} a lesson.
              </p>
            )}
          </div>
        ))}

        {rows.length === 0 && (
          <p className="text-sm text-slate-400">
            No topics have curriculum content (Learning Indicators) imported
            yet — this report has nothing to measure until Phase 2's
            curriculum import is extended beyond the single verified sample
            topic. See docs/PHASE_LOG.md.
          </p>
        )}
      </div>
    </div>
  );
}
