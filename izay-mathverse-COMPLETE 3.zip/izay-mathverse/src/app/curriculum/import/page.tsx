import { prisma } from "@/lib/prisma";
import { stageCurriculumImport } from "@/lib/actions/curriculum";
import Link from "next/link";

export default async function CurriculumImportPage() {
  const courses = await prisma.course.findMany({ orderBy: { name: "asc" } });
  const pendingBatches = await prisma.curriculumImportBatch.findMany({
    where: { status: "PENDING" },
    orderBy: { createdAt: "desc" },
    include: { course: true, submittedBy: true },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Import Curriculum</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Imports never touch the live curriculum directly — every submission
          goes through a preview screen for review before anything is saved
          (spec §46).
        </p>
      </div>

      {pendingBatches.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-sm font-semibold text-amber-800 mb-2">
            Pending review
          </p>
          <ul className="space-y-1">
            {pendingBatches.map((b) => (
              <li key={b.id} className="text-sm">
                <Link
                  href={`/curriculum/import/${b.id}`}
                  className="text-brand-700 hover:underline"
                >
                  {b.course.name} — submitted by {b.submittedBy.firstName}{" "}
                  {b.submittedBy.lastName}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      <form
        action={stageCurriculumImport}
        className="bg-white rounded-lg border border-slate-200 p-5 space-y-4"
      >
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Course
          </label>
          <select
            name="courseId"
            required
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Curriculum structure (JSON)
          </label>
          <textarea
            name="payload"
            required
            rows={12}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono"
            placeholder='{"level": {"name": "SHS 1", "code": "1"}, "strands": [...]}'
          />
          <p className="text-xs text-slate-400 mt-1">
            One Academic Level per import. CSV/Excel upload and direct
            document-extraction import are planned additions to this same
            review flow — this JSON path is the first, fully working format.
          </p>
        </div>

        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Submit for Review
        </button>
      </form>
    </div>
  );
}
