import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import {
  confirmCurriculumImport,
  rejectCurriculumImport,
} from "@/lib/actions/curriculum";

interface PreviewPayload {
  level: { name: string; code: string };
  strands: Array<{
    name: string;
    code: string;
    subStrands: Array<{
      name: string;
      code: string;
      topics: Array<{
        name: string;
        learningOutcomes?: unknown[];
        contentStandards?: Array<{
          code: string;
          statement: string;
          learningIndicators?: unknown[];
        }>;
      }>;
    }>;
  }>;
}

export default async function ImportPreviewPage({
  params,
}: {
  params: { batchId: string };
}) {
  const batch = await prisma.curriculumImportBatch.findUnique({
    where: { id: params.batchId },
    include: { course: true, submittedBy: true },
  });

  if (!batch) notFound();

  let data: PreviewPayload | null = null;
  let parseError: string | null = null;
  try {
    data = JSON.parse(batch.rawPayload);
  } catch {
    parseError = "This payload could not be parsed as JSON.";
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Import Preview</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Course: <span className="font-medium">{batch.course.name}</span> ·
          Submitted by {batch.submittedBy.firstName}{" "}
          {batch.submittedBy.lastName} · Status:{" "}
          <span className="font-medium">{batch.status}</span>
        </p>
      </div>

      {parseError && (
        <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-3">
          {parseError}
        </p>
      )}

      {data && (
        <div className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
          <p className="font-semibold text-slate-800">
            Academic Level: {data.level.name} (code {data.level.code})
          </p>

          {data.strands.map((strand, i) => (
            <div key={i} className="border-t border-slate-100 pt-3">
              <p className="font-medium text-slate-700">
                Strand {strand.code}. {strand.name}
              </p>
              <div className="ml-4 mt-2 space-y-2">
                {strand.subStrands.map((ss, j) => (
                  <div key={j}>
                    <p className="text-sm text-slate-600">
                      Sub-Strand {ss.code}. {ss.name}
                    </p>
                    <ul className="ml-4 mt-1 list-disc list-inside text-sm text-slate-500">
                      {ss.topics.map((topic, k) => (
                        <li key={k}>
                          {topic.name}
                          {" — "}
                          {topic.contentStandards?.length ?? 0} content
                          standard(s),{" "}
                          {topic.learningOutcomes?.length ?? 0} learning
                          outcome(s)
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {batch.status === "PENDING" && (
        <div className="flex gap-3">
          <form action={confirmCurriculumImport.bind(null, batch.id)}>
            <button
              disabled={!data}
              className="rounded-md bg-green-600 text-white text-sm font-medium px-4 py-2 hover:bg-green-700 disabled:opacity-40 transition"
            >
              Confirm Import
            </button>
          </form>
          <form action={rejectCurriculumImport.bind(null, batch.id)}>
            <button className="rounded-md border border-slate-300 text-slate-600 text-sm font-medium px-4 py-2 hover:bg-slate-50 transition">
              Reject
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
