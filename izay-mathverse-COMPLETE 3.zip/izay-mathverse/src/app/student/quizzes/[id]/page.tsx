import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { startQuizAttempt } from "@/lib/actions/quizzes";

export default async function StudentQuizDetailPage({ params }: { params: { id: string } }) {
  const user = await getSessionUser();
  if (!user) return null;

  const quiz = await prisma.quiz.findUnique({
    where: { id: params.id },
    include: { course: true, attempts: { where: { studentId: user.id }, orderBy: { startedAt: "desc" } } },
  });
  if (!quiz || (quiz.status !== "PUBLISHED" && quiz.status !== "ACTIVE")) notFound();

  const inProgress = quiz.attempts.find((a) => !a.submittedAt);
  const attemptsUsed = quiz.attempts.filter((a) => a.submittedAt).length;
  const remaining = quiz.attemptsAllowed - attemptsUsed;
  const now = new Date();
  const notYetOpen = quiz.startDate && now < quiz.startDate;
  const closed = quiz.endDate && now > quiz.endDate;

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <Link href="/student/quizzes" className="text-xs text-brand-700 hover:underline">← All quizzes</Link>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <h1 className="text-xl font-bold text-slate-800">{quiz.title}</h1>
        {quiz.description && <p className="text-sm text-slate-500 mt-1">{quiz.description}</p>}

        <dl className="grid grid-cols-2 gap-3 mt-4 text-sm">
          <div><dt className="text-slate-400">Course</dt><dd className="text-slate-700">{quiz.course.name}</dd></div>
          <div><dt className="text-slate-400">Questions</dt><dd className="text-slate-700">{quiz.numberOfQuestions}</dd></div>
          <div><dt className="text-slate-400">Duration</dt><dd className="text-slate-700">{quiz.durationMinutes} minutes</dd></div>
          <div><dt className="text-slate-400">Total marks</dt><dd className="text-slate-700">{quiz.totalMarks}</dd></div>
          <div><dt className="text-slate-400">Attempts</dt><dd className="text-slate-700">{remaining} of {quiz.attemptsAllowed} remaining</dd></div>
        </dl>

        <div className="mt-5">
          {inProgress ? (
            <Link
              href={`/student/quizzes/attempt/${inProgress.id}`}
              className="block text-center rounded-md bg-brand-600 text-white text-sm font-medium py-2.5 hover:bg-brand-700 transition"
            >
              Continue Attempt
            </Link>
          ) : notYetOpen ? (
            <p className="text-sm text-amber-600 text-center">This quiz opens {quiz.startDate?.toLocaleString()}.</p>
          ) : closed ? (
            <p className="text-sm text-red-600 text-center">This quiz closed on {quiz.endDate?.toLocaleString()}.</p>
          ) : remaining <= 0 ? (
            <p className="text-sm text-slate-500 text-center">You have used all your attempts.</p>
          ) : (
            <form action={startQuizAttempt.bind(null, quiz.id)}>
              <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2.5 hover:bg-brand-700 transition">
                Start Quiz
              </button>
            </form>
          )}
        </div>
      </div>

      {attemptsUsed > 0 && (
        <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
          {quiz.attempts.filter((a) => a.submittedAt).map((a) => (
            <Link
              key={a.id}
              href={`/student/quizzes/attempt/${a.id}/result`}
              className="block p-3 text-sm hover:bg-slate-50 transition flex items-center justify-between"
            >
              <span className="text-slate-600">
                {a.submittedAt?.toLocaleDateString()}
              </span>
              <span className="font-medium text-slate-800">
                {a.score}/{a.maxScore}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
