import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

export default async function StudentQuizzesPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const quizzes = await prisma.quiz.findMany({
    where: {
      status: { in: ["PUBLISHED", "ACTIVE"] },
      course: { status: "AVAILABLE" },
    },
    orderBy: { createdAt: "desc" },
    include: {
      course: true,
      attempts: { where: { studentId: user.id } },
    },
  });

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Quizzes</h1>

      <div className="space-y-3">
        {quizzes.map((q) => {
          const attemptsUsed = q.attempts.length;
          const remaining = q.attemptsAllowed - attemptsUsed;
          return (
            <Link
              key={q.id}
              href={`/student/quizzes/${q.id}`}
              className="block bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition"
            >
              <p className="font-semibold text-slate-800">{q.title}</p>
              <p className="text-xs text-slate-500 mt-1">
                {q.course.name} · {q.numberOfQuestions} questions ·{" "}
                {q.durationMinutes} min · {remaining > 0 ? `${remaining} attempt${remaining === 1 ? "" : "s"} left` : "No attempts left"}
              </p>
            </Link>
          );
        })}
        {quizzes.length === 0 && (
          <p className="text-sm text-slate-400">No quizzes available right now.</p>
        )}
      </div>
    </div>
  );
}
