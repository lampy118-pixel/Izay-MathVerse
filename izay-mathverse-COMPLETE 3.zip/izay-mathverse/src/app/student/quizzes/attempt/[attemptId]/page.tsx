import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getSessionUser, assertOwnRecord } from "@/lib/rbac";
import { submitQuizAttempt } from "@/lib/actions/quizzes";
import { MathContent } from "@/components/math-content";
import { ExamTimer } from "@/components/exam-timer";
import { redirect } from "next/navigation";

interface SnapshotQuestion {
  questionId: string;
  questionText: string;
  imageUrl: string | null;
  type: string;
  marks: number;
  options: Array<{ id: string; text: string }>;
}

export default async function QuizAttemptPage({ params }: { params: { attemptId: string } }) {
  const user = await getSessionUser();
  if (!user || user.role !== "STUDENT") notFound();

  const attempt = await prisma.quizAttempt.findUnique({
    where: { id: params.attemptId },
    include: { quiz: true },
  });
  if (!attempt) notFound();
  assertOwnRecord(user.id, attempt.studentId);

  if (attempt.submittedAt) {
    redirect(`/student/quizzes/attempt/${attempt.id}/result`);
  }

  const snapshot: SnapshotQuestion[] = JSON.parse(attempt.questionSetSnapshot);
  const submitAction = submitQuizAttempt.bind(null, attempt.id);
  const formId = `quiz-attempt-${attempt.id}`;

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-4">
      <div className="flex items-center justify-between sticky top-0 bg-slate-50 py-2 z-10">
        <div>
          <h1 className="text-lg font-bold text-slate-800">{attempt.quiz.title}</h1>
          <p className="text-xs text-slate-500">{snapshot.length} questions</p>
        </div>
        <ExamTimer
          startedAt={attempt.startedAt.toISOString()}
          durationMinutes={attempt.quiz.durationMinutes}
          formId={formId}
        />
      </div>

      <form id={formId} action={submitAction} className="space-y-4">
        {snapshot.map((item, idx) => (
          <div key={item.questionId} className="bg-white rounded-lg border border-slate-200 p-4">
            <p className="text-xs text-slate-400 mb-2">
              Question {idx + 1} of {snapshot.length} · {item.marks} mark{item.marks === 1 ? "" : "s"}
            </p>
            <MathContent text={item.questionText} className="text-slate-800" />

            {item.imageUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={item.imageUrl} alt="" className="mt-3 rounded-md border border-slate-200 max-w-full" />
            )}

            <div className="mt-3">
              {item.options.length > 0 ? (
                <div className="space-y-2">
                  {item.options.map((opt) => (
                    <label key={opt.id} className="flex items-center gap-2 text-sm bg-slate-50 rounded-md px-3 py-2 cursor-pointer hover:bg-slate-100 transition">
                      <input type="radio" name={`answer_${item.questionId}`} value={opt.id} />
                      <span className="text-slate-700">{opt.text}</span>
                    </label>
                  ))}
                </div>
              ) : (
                <input
                  name={`answer_${item.questionId}`}
                  placeholder="Your answer"
                  className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                />
              )}
            </div>
          </div>
        ))}

        <button
          type="submit"
          className="w-full rounded-md bg-brand-600 text-white text-sm font-semibold py-3 hover:bg-brand-700 transition"
        >
          Submit Quiz
        </button>
        <p className="text-xs text-slate-400 text-center">
          Submitting is final — you won&apos;t be able to change your answers afterward.
        </p>
      </form>
    </div>
  );
}
