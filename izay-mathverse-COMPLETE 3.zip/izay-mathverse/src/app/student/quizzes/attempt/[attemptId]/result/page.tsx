import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser, assertOwnRecord } from "@/lib/rbac";

export default async function QuizResultPage({ params }: { params: { attemptId: string } }) {
  const user = await getSessionUser();
  if (!user || user.role !== "STUDENT") notFound();

  const attempt = await prisma.quizAttempt.findUnique({
    where: { id: params.attemptId },
    include: { quiz: true },
  });
  if (!attempt) notFound();
  assertOwnRecord(user.id, attempt.studentId);

  if (!attempt.submittedAt) notFound();

  const now = new Date();
  let visible = true;
  let reason = "";

  switch (attempt.quiz.resultVisibility) {
    case "IMMEDIATE":
    case "AFTER_SUBMISSION":
      visible = true;
      break;
    case "AFTER_DUE_DATE":
      visible = !attempt.quiz.endDate || now > attempt.quiz.endDate;
      reason = "Results are released after the quiz's due date.";
      break;
    case "MANUAL_RELEASE":
      // No release-tracking field exists yet for manual release — see
      // docs/PHASE_LOG.md. Defaults to withheld rather than guessing.
      visible = false;
      reason = "Your teacher will release results for this quiz manually.";
      break;
  }

  const percentage = attempt.maxScore ? ((attempt.score ?? 0) / attempt.maxScore) * 100 : 0;

  return (
    <div className="max-w-md mx-auto p-4 sm:p-6 space-y-4">
      <Link href={`/student/quizzes/${attempt.quizId}`} className="text-xs text-brand-700 hover:underline">
        ← Back to quiz
      </Link>

      <div className="bg-white rounded-lg border border-slate-200 p-6 text-center">
        <h1 className="text-lg font-bold text-slate-800">{attempt.quiz.title}</h1>
        {visible ? (
          <>
            <p className="text-4xl font-bold text-brand-700 mt-4">
              {attempt.score} / {attempt.maxScore}
            </p>
            <p className="text-sm text-slate-500 mt-1">{Math.round(percentage)}%</p>
          </>
        ) : (
          <p className="text-sm text-slate-500 mt-4">{reason}</p>
        )}
        <p className="text-xs text-slate-400 mt-4">
          Submitted {attempt.submittedAt?.toLocaleString()}
        </p>
      </div>
    </div>
  );
}
