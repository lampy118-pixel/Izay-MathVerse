import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { LessonViewer } from "@/components/lesson-viewer";
import { LockedCourseNotice } from "@/components/locked-course-notice";

export default async function StudentLessonPage({
  params,
}: {
  params: { id: string };
}) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: params.id },
    include: {
      images: true,
      videos: true,
      materials: true,
      geogebraActivities: true,
      desmosActivities: true,
      externalResources: true,
      practiceQuestions: { where: { status: "ACTIVE" } },
      topic: {
        include: {
          subStrand: {
            include: { strand: { include: { academicLevel: { include: { course: true } } } } },
          },
        },
      },
    },
  });

  if (!lesson) notFound();

  const course = lesson.topic.subStrand.strand.academicLevel.course;

  // Backend-enforced gate (spec §50) — even if a student guesses a lesson
  // URL directly, a restricted course or an unpublished lesson never
  // renders its content.
  if (course.status === "RESTRICTED") {
    return <LockedCourseNotice course={course} />;
  }
  if (lesson.status !== "PUBLISHED" && lesson.status !== "ACTIVE") {
    notFound();
  }

  const subStrand = lesson.topic.subStrand;

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-4">
      <Link
        href={`/student/curriculum/${subStrand.strand.academicLevelId}/${subStrand.strandId}/${subStrand.id}`}
        className="text-xs text-brand-700 hover:underline"
      >
        ← Back to {subStrand.name}
      </Link>
      <LessonViewer lesson={lesson} />
    </div>
  );
}
