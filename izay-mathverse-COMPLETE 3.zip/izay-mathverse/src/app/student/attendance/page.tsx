import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

const STATUS_STYLE: Record<string, string> = {
  PRESENT: "bg-green-100 text-green-700",
  ABSENT: "bg-red-100 text-red-700",
  LATE: "bg-amber-100 text-amber-700",
};

export default async function StudentAttendancePage() {
  const user = await getSessionUser();
  if (!user) return null;

  const records = await prisma.attendance.findMany({
    where: { studentId: user.id },
    orderBy: { date: "desc" },
    include: { class: true },
    take: 60,
  });

  const total = records.length;
  const present = records.filter((r) => r.status === "PRESENT").length;

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-800">My Attendance</h1>
        {total > 0 && (
          <p className="text-sm text-slate-500 mt-0.5">
            {present} / {total} days present ({Math.round((present / total) * 100)}%)
          </p>
        )}
      </div>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {records.map((r) => (
          <div key={r.id} className="p-3 flex items-center justify-between text-sm">
            <div>
              <p className="text-slate-700">{r.date.toLocaleDateString()}</p>
              <p className="text-xs text-slate-400">{r.class.name}</p>
            </div>
            <span className={`text-xs font-medium rounded-full px-2 py-0.5 ${STATUS_STYLE[r.status]}`}>
              {r.status}
            </span>
          </div>
        ))}
        {records.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No attendance records yet.</p>
        )}
      </div>
    </div>
  );
}
