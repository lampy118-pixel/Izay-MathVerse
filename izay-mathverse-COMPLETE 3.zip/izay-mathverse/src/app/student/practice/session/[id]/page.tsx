import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser, assertOwnRecord } from "@/lib/rbac";
import { getNextQuestion, submitPracticeAnswer, endPracticeSession } from "@/lib/actions/practice";
import { MathContent } from "@/components/math-content";

export default async function PracticeSessionPage({
  params,
}: {
  params: { id: string };
}) {
  const user = await getSessionUser();
  if (!user || user.role !== "STUDENT") notFound();

  const session = await prisma.practiceSession.findUnique({
    where: { id: params.id },
    include: {
      attempts: {
        include: { question: { include: { options: true } } },
        orderBy: { answeredAt: "asc" },
      },
      course: true,
      topic: true,
    },
  });

  if (!session) notFound();
  assertOwnRecord(user.id, session.studentId);

  const nextQuestion = session.endedAt ? null : await getNextQuestion(session.id);

  // Session complete (pool exhausted or explicitly ended) — show summary.
  if (!nextQuestion) {
    if (!session.endedAt) {
      await endPracticeSession(session.id);
    }

    const graded = session.attempts.filter((a) => a.isCorrect !== null);
    const correct = graded.filter((a) => a.isCorrect).length;
    const pendingReview = session.attempts.length - graded.length;

    return (
      <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
        <div className="bg-white rounded-lg border border-slate-200 p-6 text-center">
          <p className="text-4xl mb-2">
            {session.attempts.length === 0 ? "🤔" : correct / Math.max(graded.length, 1) >= 0.7 ? "🎉" : "💪"}
          </p>
          <h1 className="text-xl font-bold text-slate-800">Session Complete</h1>
          <p className="text-slate-500 mt-1">
            {session.course.name}
            {session.topic ? ` · ${session.topic.name}` : ""}
          </p>

          {session.attempts.length === 0 ? (
            <p className="mt-4 text-sm text-slate-500">
              No active questions were available for this selection.
            </p>
          ) : (
            <>
              <p className="text-3xl font-bold text-brand-700 mt-4">
                {correct} / {graded.length}
              </p>
              <p className="text-sm text-slate-500">correct (auto-graded)</p>
              {pendingReview > 0 && (
                <p className="text-xs text-amber-600 mt-2">
                  {pendingReview} structured question{pendingReview === 1 ? "" : "s"} pending manual review.
                </p>
              )}
            </>
          )}

          <div className="mt-6 flex gap-2 justify-center">
            <Link
              href="/student/practice"
              className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
            >
              Practice Again
            </Link>
            <Link
              href="/student/progress"
              className="rounded-md border border-slate-300 text-slate-600 text-sm font-medium px-4 py-2 hover:bg-slate-50 transition"
            >
              View Progress
            </Link>
          </div>
        </div>

        {session.attempts.length > 0 && (
          <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
            {session.attempts.map((a) => (
              <div key={a.id} className="p-3 text-sm flex items-start gap-2">
                <span>
                  {a.isCorrect === true ? "✅" : a.isCorrect === false ? "❌" : "⏳"}
                </span>
                <span className="text-slate-600 line-clamp-2">
                  {a.question.questionText}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  const alreadyAnsweredCount = session.attempts.length;
  const submitAction = submitPracticeAnswer.bind(null, session.id, nextQuestion.id);
  const isExamMode = session.mode === "EXAM_MODE";
  const showHints = session.mode === "LEARN_AND_PRACTICE";

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>
          Question {alreadyAnsweredCount + 1} · {session.course.name}
          {session.topic ? ` · ${session.topic.name}` : ""}
        </span>
        <form action={endPracticeSession.bind(null, session.id)}>
          <button className="text-slate-400 hover:text-red-600 underline">
            End session
          </button>
        </form>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-xs text-slate-400 mb-2">
          {nextQuestion.marks} mark{nextQuestion.marks === 1 ? "" : "s"} ·{" "}
          {nextQuestion.difficulty}
        </p>
        <MathContent text={nextQuestion.questionText} className="text-slate-800" />

        {nextQuestion.imageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={nextQuestion.imageUrl}
            alt="Question diagram"
            className="mt-3 rounded-md border border-slate-200 max-w-full"
          />
        )}

        <form action={submitAction} className="mt-4 space-y-3">
          {nextQuestion.options.length > 0 ? (
            <div className="space-y-2">
              {nextQuestion.options.map((opt) => (
                <label
                  key={opt.id}
                  className="flex items-center gap-2 text-sm bg-slate-50 rounded-md px-3 py-2 cursor-pointer hover:bg-slate-100 transition"
                >
                  <input type="radio" name="answer" value={opt.id} required />
                  <span className="text-slate-700">{opt.text}</span>
                </label>
              ))}
            </div>
          ) : (
            <input
              name="answer"
              required
              placeholder="Your answer"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
          )}

          <button
            type="submit"
            className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition"
          >
            Submit Answer
          </button>
        </form>

        {showHints && nextQuestion.hints.length > 0 && !isExamMode && (
          <details className="mt-4 text-sm">
            <summary className="cursor-pointer text-brand-700 font-medium">
              Show hints ({nextQuestion.hints.length})
            </summary>
            <ol className="mt-2 space-y-1 list-decimal list-inside text-slate-600">
              {nextQuestion.hints.map((h) => (
                <li key={h.id}>{h.text}</li>
              ))}
            </ol>
          </details>
        )}
      </div>
    </div>
  );
}
