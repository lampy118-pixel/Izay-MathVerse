import { prisma } from "@/lib/prisma";
import { startPracticeSession } from "@/lib/actions/practice";

const MODE_INFO: Record<string, string> = {
  LEARN_AND_PRACTICE: "Hints and explanations available as you go.",
  QUICK_PRACTICE: "A short set of questions, no time pressure.",
  CHALLENGE_MODE: "Harder pacing, minimal hints.",
  EXAM_MODE: "Solutions hidden unless a question allows them — simulates a real assessment.",
};

export default async function PracticeStartPage({
  searchParams,
}: {
  searchParams: { topicId?: string };
}) {
  const courses = await prisma.course.findMany({
    where: { status: "AVAILABLE" },
    orderBy: { name: "asc" },
  });

  const topics = await prisma.topic.findMany({
    orderBy: { name: "asc" },
    include: {
      subStrand: {
        include: { strand: { include: { academicLevel: { include: { course: true } } } } },
      },
      questions: { where: { status: "ACTIVE" }, select: { id: true } },
    },
    take: 300,
  });

  const topicsWithQuestions = topics.filter((t) => t.questions.length > 0);
  const preselectedTopic = searchParams.topicId
    ? topics.find((t) => t.id === searchParams.topicId)
    : undefined;
  const preselectedCourseId =
    preselectedTopic?.subStrand.strand.academicLevel.course.id;

  return (
    <div className="max-w-lg mx-auto space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Practice</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Choose a course, optionally a topic, and a mode to begin.
        </p>
      </div>

      <form
        action={startPracticeSession}
        className="bg-white rounded-lg border border-slate-200 p-5 space-y-4"
      >
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Course
          </label>
          <select
            name="courseId"
            required
            defaultValue={preselectedCourseId ?? ""}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Topic (optional — leave blank to mix all topics)
          </label>
          <select
            name="topicId"
            defaultValue={searchParams.topicId ?? ""}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">— Any topic —</option>
            {topicsWithQuestions.map((t) => (
              <option key={t.id} value={t.id}>
                {t.subStrand.strand.academicLevel.name} / {t.subStrand.strand.name} /{" "}
                {t.name} ({t.questions.length} question{t.questions.length === 1 ? "" : "s"})
              </option>
            ))}
          </select>
          {topicsWithQuestions.length === 0 && (
            <p className="text-xs text-amber-600 mt-1">
              No topics have active questions yet — a teacher needs to
              activate some questions in the Question Bank first.
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Mode
          </label>
          <div className="space-y-1.5">
            {Object.entries(MODE_INFO).map(([mode, desc]) => (
              <label
                key={mode}
                className="flex items-start gap-2 text-sm bg-slate-50 rounded-md p-2 cursor-pointer"
              >
                <input
                  type="radio"
                  name="mode"
                  value={mode}
                  defaultChecked={mode === "QUICK_PRACTICE"}
                  className="mt-0.5"
                />
                <span>
                  <span className="font-medium text-slate-700">
                    {mode.replace(/_/g, " ")}
                  </span>
                  <br />
                  <span className="text-xs text-slate-500">{desc}</span>
                </span>
              </label>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2.5 hover:bg-brand-700 transition"
        >
          Start Practice
        </button>
      </form>
    </div>
  );
}
