import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function StudentSearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = searchParams.q?.trim() ?? "";

  const [lessons, materials] = q
    ? await Promise.all([
        prisma.lesson.findMany({
          where: {
            title: { contains: q, mode: "insensitive" },
            status: { in: ["PUBLISHED", "ACTIVE"] },
            topic: { subStrand: { strand: { academicLevel: { course: { status: "AVAILABLE" } } } } },
          },
          take: 15,
        }),
        prisma.lessonMaterial.findMany({
          where: { title: { contains: q, mode: "insensitive" } },
          take: 15,
        }),
      ])
    : [[], []];

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Search</h1>
      <form>
        <input
          name="q"
          defaultValue={q}
          placeholder="Search lessons, notes..."
          className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          autoFocus
        />
      </form>

      {q && (
        <>
          {lessons.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Lessons</p>
              <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
                {lessons.map((l) => (
                  <Link key={l.id} href={`/student/lessons/${l.id}`} className="block p-3 text-sm text-slate-700 hover:bg-slate-50 transition">
                    {l.title}
                  </Link>
                ))}
              </div>
            </div>
          )}
          {materials.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Materials</p>
              <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
                {materials.map((m) => (
                  <a key={m.id} href={m.fileUrl} target="_blank" rel="noreferrer" className="block p-3 text-sm text-slate-700 hover:bg-slate-50 transition">
                    📎 {m.title}
                  </a>
                ))}
              </div>
            </div>
          )}
          {lessons.length === 0 && materials.length === 0 && (
            <p className="text-sm text-slate-400">No results for &quot;{q}&quot;.</p>
          )}
        </>
      )}
    </div>
  );
}
