import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { LockedCourseNotice } from "@/components/locked-course-notice";

export default async function StudentCurriculumLevelPage({
  params,
}: {
  params: { levelId: string };
}) {
  const level = await prisma.academicLevel.findUnique({
    where: { id: params.levelId },
    include: {
      course: true,
      strands: { orderBy: { sortOrder: "asc" }, include: { subStrands: true } },
    },
  });

  if (!level) notFound();

  if (level.course.status === "RESTRICTED") {
    return <LockedCourseNotice course={level.course} />;
  }

  return (
    <div className="space-y-4">
      <nav className="text-xs text-slate-400">
        <Link href={`/student/courses/${level.course.slug}`} className="hover:underline">
          {level.course.name}
        </Link>{" "}
        / {level.name}
      </nav>
      <h1 className="text-xl font-bold text-slate-800">
        {level.course.name} — {level.name}
      </h1>

      <div className="grid sm:grid-cols-2 gap-3">
        {level.strands.map((strand) => (
          <Link
            key={strand.id}
            href={`/student/curriculum/${level.id}/${strand.id}`}
            className="bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition"
          >
            <p className="font-semibold text-slate-800">
              Strand {strand.code}. {strand.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {strand.subStrands.length} sub-strand
              {strand.subStrands.length === 1 ? "" : "s"}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
