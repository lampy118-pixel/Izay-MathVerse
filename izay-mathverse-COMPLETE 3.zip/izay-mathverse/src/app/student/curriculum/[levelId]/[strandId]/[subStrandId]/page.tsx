import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { LockedCourseNotice } from "@/components/locked-course-notice";

export default async function StudentSubStrandPage({
  params,
}: {
  params: { levelId: string; strandId: string; subStrandId: string };
}) {
  const subStrand = await prisma.subStrand.findUnique({
    where: { id: params.subStrandId },
    include: {
      strand: { include: { academicLevel: { include: { course: true } } } },
      topics: {
        orderBy: { sortOrder: "asc" },
        include: {
          lessons: {
            where: { status: { in: ["PUBLISHED", "ACTIVE"] } },
            orderBy: { sortOrder: "asc" },
          },
        },
      },
    },
  });

  if (!subStrand || subStrand.strandId !== params.strandId) notFound();

  const { strand } = subStrand;
  if (strand.academicLevel.course.status === "RESTRICTED") {
    return <LockedCourseNotice course={strand.academicLevel.course} />;
  }

  return (
    <div className="space-y-4">
      <nav className="text-xs text-slate-400">
        <Link href={`/student/courses/${strand.academicLevel.course.slug}`} className="hover:underline">
          {strand.academicLevel.course.name}
        </Link>{" "}
        /{" "}
        <Link href={`/student/curriculum/${params.levelId}`} className="hover:underline">
          {strand.academicLevel.name}
        </Link>{" "}
        /{" "}
        <Link href={`/student/curriculum/${params.levelId}/${params.strandId}`} className="hover:underline">
          {strand.name}
        </Link>{" "}
        / {subStrand.name}
      </nav>
      <h1 className="text-xl font-bold text-slate-800">
        {subStrand.code}. {subStrand.name}
      </h1>

      <div className="space-y-3">
        {subStrand.topics.map((topic) => (
          <div key={topic.id} className="bg-white rounded-lg border border-slate-200 p-4">
            <p className="font-semibold text-slate-800 mb-2">{topic.name}</p>
            {topic.lessons.length > 0 ? (
              <ul className="space-y-1">
                {topic.lessons.map((lesson) => (
                  <li key={lesson.id}>
                    <Link
                      href={`/student/lessons/${lesson.id}`}
                      className="text-sm text-brand-700 hover:underline"
                    >
                      → {lesson.title}
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-slate-400">
                No lessons published for this topic yet.
              </p>
            )}
          </div>
        ))}
        {subStrand.topics.length === 0 && (
          <p className="text-sm text-slate-400">
            No topics imported for this sub-strand yet.
          </p>
        )}
      </div>
    </div>
  );
}
