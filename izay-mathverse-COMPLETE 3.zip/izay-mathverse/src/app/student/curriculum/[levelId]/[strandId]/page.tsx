import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { LockedCourseNotice } from "@/components/locked-course-notice";

export default async function StudentStrandPage({
  params,
}: {
  params: { levelId: string; strandId: string };
}) {
  const strand = await prisma.strand.findUnique({
    where: { id: params.strandId },
    include: {
      academicLevel: { include: { course: true } },
      subStrands: { orderBy: { sortOrder: "asc" }, include: { topics: true } },
    },
  });

  if (!strand || strand.academicLevelId !== params.levelId) notFound();

  if (strand.academicLevel.course.status === "RESTRICTED") {
    return <LockedCourseNotice course={strand.academicLevel.course} />;
  }

  return (
    <div className="space-y-4">
      <nav className="text-xs text-slate-400">
        <Link href={`/student/courses/${strand.academicLevel.course.slug}`} className="hover:underline">
          {strand.academicLevel.course.name}
        </Link>{" "}
        /{" "}
        <Link href={`/student/curriculum/${params.levelId}`} className="hover:underline">
          {strand.academicLevel.name}
        </Link>{" "}
        / {strand.name}
      </nav>
      <h1 className="text-xl font-bold text-slate-800">
        {strand.code}. {strand.name}
      </h1>

      <div className="space-y-3">
        {strand.subStrands.map((subStrand) => (
          <Link
            key={subStrand.id}
            href={`/student/curriculum/${params.levelId}/${params.strandId}/${subStrand.id}`}
            className="block bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition"
          >
            <p className="font-semibold text-slate-800">
              Sub-Strand {subStrand.code}. {subStrand.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {subStrand.topics.length} topic
              {subStrand.topics.length === 1 ? "" : "s"}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
