import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { markNotificationRead } from "@/lib/actions/announcements";

export default async function NotificationsPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const notifications = await prisma.notification.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Notifications</h1>
      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {notifications.map((n) => (
          <div key={n.id} className={`p-4 ${n.isRead ? "" : "bg-brand-50"}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-medium text-slate-800">{n.title}</p>
                {n.body && <p className="text-sm text-slate-600 mt-0.5">{n.body}</p>}
                <p className="text-xs text-slate-400 mt-1">{n.createdAt.toLocaleString()}</p>
              </div>
              {!n.isRead && (
                <form action={markNotificationRead.bind(null, n.id)}>
                  <button className="text-xs text-brand-700 hover:underline shrink-0">Mark read</button>
                </form>
              )}
            </div>
            {n.linkUrl && (
              <Link href={n.linkUrl} className="text-xs text-brand-700 hover:underline mt-1 inline-block">
                View →
              </Link>
            )}
          </div>
        ))}
        {notifications.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No notifications yet.</p>
        )}
      </div>
    </div>
  );
}
