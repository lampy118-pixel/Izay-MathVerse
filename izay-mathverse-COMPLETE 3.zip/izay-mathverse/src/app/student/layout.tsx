import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/rbac";
import { DashboardShell } from "@/components/dashboard-shell";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/student" },
  { label: "Practice", href: "/student/practice" },
  { label: "Quizzes", href: "/student/quizzes" },
  { label: "Assignments", href: "/student/assignments" },
  { label: "Progress", href: "/student/progress" },
  { label: "Results", href: "/student/results" },
  { label: "Attendance", href: "/student/attendance" },
  { label: "Timetable", href: "/student/timetable" },
  { label: "Announcements", href: "/student/announcements" },
  { label: "Notifications", href: "/student/notifications" },
  { label: "WASSCE Prep", href: "/student/wassce" },
  { label: "Downloads", href: "/student/downloads" },
  { label: "Search", href: "/student/search" },
];

export default async function StudentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if (!user || user.role !== "STUDENT") {
    redirect("/unauthorized");
  }

  return (
    <DashboardShell user={user} navItems={NAV_ITEMS}>
      {children}
    </DashboardShell>
  );
}
