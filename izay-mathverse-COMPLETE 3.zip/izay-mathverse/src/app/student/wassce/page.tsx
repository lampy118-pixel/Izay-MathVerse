import { prisma } from "@/lib/prisma";

export default async function StudentWassceePage() {
  const materials = await prisma.lessonMaterial.findMany({
    where: {
      courseId: { not: null },
      materialLessonId: null,
      slideLessonId: null,
      course: { status: "AVAILABLE" },
    },
    orderBy: { createdAt: "desc" },
    include: { course: true },
  });

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-800">WASSCE Preparation</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Past questions, mock tests, and revision resources.
        </p>
      </div>
      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {materials.map((m) => (
          <a
            key={m.id}
            href={m.fileUrl}
            target="_blank"
            rel="noreferrer"
            className="block p-4 hover:bg-slate-50 transition"
          >
            <p className="text-sm font-medium text-slate-800">📎 {m.title}</p>
            <p className="text-xs text-slate-400 mt-0.5">{m.course?.name} · {m.fileType}</p>
          </a>
        ))}
        {materials.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">
            No WASSCE resources have been added yet.
          </p>
        )}
      </div>
    </div>
  );
}
