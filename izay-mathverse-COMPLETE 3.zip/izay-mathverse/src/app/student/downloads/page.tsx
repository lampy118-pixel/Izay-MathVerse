import { prisma } from "@/lib/prisma";

export default async function StudentDownloadsPage() {
  const [courseMaterials, lessonMaterials] = await Promise.all([
    prisma.lessonMaterial.findMany({
      where: {
        courseId: { not: null },
        materialLessonId: null,
        slideLessonId: null,
        course: { status: "AVAILABLE" },
      },
      include: { course: true },
    }),
    prisma.lessonMaterial.findMany({
      where: {
        materialLesson: {
          status: { in: ["PUBLISHED", "ACTIVE"] },
          topic: { subStrand: { strand: { academicLevel: { course: { status: "AVAILABLE" } } } } },
        },
      },
      include: { materialLesson: true },
    }),
  ]);

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Downloads</h1>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {courseMaterials.map((m) => (
          <a key={m.id} href={m.fileUrl} target="_blank" rel="noreferrer" className="block p-4 hover:bg-slate-50 transition">
            <p className="text-sm font-medium text-slate-800">📎 {m.title}</p>
            <p className="text-xs text-slate-400 mt-0.5">{m.course?.name} · {m.fileType}</p>
          </a>
        ))}
        {lessonMaterials.map((m) => (
          <a key={m.id} href={m.fileUrl} target="_blank" rel="noreferrer" className="block p-4 hover:bg-slate-50 transition">
            <p className="text-sm font-medium text-slate-800">📎 {m.title}</p>
            <p className="text-xs text-slate-400 mt-0.5">{m.materialLesson?.title} · {m.fileType}</p>
          </a>
        ))}
        {courseMaterials.length === 0 && lessonMaterials.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No downloadable materials yet.</p>
        )}
      </div>
    </div>
  );
}
