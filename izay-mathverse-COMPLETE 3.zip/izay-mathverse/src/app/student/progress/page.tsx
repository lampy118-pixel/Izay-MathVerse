import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

const WEAK_THRESHOLD = 70; // percent — below this, a topic is flagged "Needs Practice"

export default async function StudentProgressPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const progressRecords = await prisma.topicProgress.findMany({
    where: { studentId: user.id, questionsAttempted: { gt: 0 } },
    orderBy: { performancePercent: "asc" },
  });

  const topicIds = progressRecords.map((p) => p.topicId);
  const topics = await prisma.topic.findMany({
    where: { id: { in: topicIds } },
    include: {
      subStrand: { include: { strand: true } },
      lessons: { where: { status: { in: ["PUBLISHED", "ACTIVE"] } }, take: 1 },
    },
  });
  const topicMap = new Map(topics.map((t) => [t.id, t]));

  const weakTopics = progressRecords.filter((p) => p.performancePercent < WEAK_THRESHOLD);
  const strongTopics = progressRecords.filter((p) => p.performancePercent >= WEAK_THRESHOLD);

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Your Progress</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Based on your actual practice attempts — updates as you practice.
        </p>
      </div>

      {progressRecords.length === 0 && (
        <div className="bg-white rounded-lg border border-dashed border-slate-300 p-6 text-center">
          <p className="text-sm text-slate-500">
            No practice attempts yet.
          </p>
          <Link
            href="/student/practice"
            className="mt-3 inline-block rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
          >
            Start Practicing
          </Link>
        </div>
      )}

      {weakTopics.length > 0 && (
        <div>
          <p className="text-sm font-semibold text-amber-700 mb-2">
            Needs Practice
          </p>
          <div className="space-y-2">
            {weakTopics.map((p) => {
              const topic = topicMap.get(p.topicId);
              return (
                <div
                  key={p.id}
                  className="bg-amber-50 border border-amber-200 rounded-lg p-4"
                >
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-slate-800">
                      {topic?.name ?? "Topic"}
                    </p>
                    <span className="text-sm font-bold text-amber-700">
                      {Math.round(p.performancePercent)}%
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {p.correctAnswers} / {p.questionsAttempted} correct
                  </p>
                  <div className="mt-2 flex gap-2">
                    {topic?.lessons[0] && (
                      <Link
                        href={`/student/lessons/${topic.lessons[0].id}`}
                        className="text-xs font-medium rounded-md border border-amber-300 text-amber-800 px-3 py-1.5 hover:bg-amber-100 transition"
                      >
                        Review Lesson
                      </Link>
                    )}
                    <Link
                      href={`/student/practice?topicId=${p.topicId}`}
                      className="text-xs font-medium rounded-md bg-amber-600 text-white px-3 py-1.5 hover:bg-amber-700 transition"
                    >
                      Practice Questions
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {strongTopics.length > 0 && (
        <div>
          <p className="text-sm font-semibold text-green-700 mb-2">
            Going Well
          </p>
          <div className="space-y-2">
            {strongTopics.map((p) => {
              const topic = topicMap.get(p.topicId);
              return (
                <div
                  key={p.id}
                  className="bg-white border border-slate-200 rounded-lg p-4 flex items-center justify-between"
                >
                  <div>
                    <p className="font-medium text-slate-800">
                      {topic?.name ?? "Topic"}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {p.correctAnswers} / {p.questionsAttempted} correct
                    </p>
                  </div>
                  <span className="text-sm font-bold text-green-700">
                    {Math.round(p.performancePercent)}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
