import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

const TYPE_LABEL: Record<string, string> = {
  QUIZ: "Quiz",
  TEST: "Test",
  ASSIGNMENT: "Assignment",
  PRACTICE: "Practice",
};

export default async function StudentResultsPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const results = await prisma.result.findMany({
    where: { studentId: user.id },
    orderBy: { recordedAt: "desc" },
    include: { grade: true, term: { include: { academicYear: true } } },
  });

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Results</h1>

      <div className="bg-white rounded-lg border border-slate-200 overflow-x-auto">
        <table className="w-full text-sm min-w-[560px]">
          <thead className="bg-slate-50 text-slate-500 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">Assessment</th>
              <th className="px-3 py-2 font-medium">Type</th>
              <th className="px-3 py-2 font-medium">Score</th>
              <th className="px-3 py-2 font-medium">%</th>
              <th className="px-3 py-2 font-medium">Grade</th>
              <th className="px-3 py-2 font-medium">Term</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {results.map((r) => (
              <tr key={r.id}>
                <td className="px-3 py-2.5 text-slate-800">{r.title}</td>
                <td className="px-3 py-2.5 text-slate-600">{TYPE_LABEL[r.assessmentType]}</td>
                <td className="px-3 py-2.5 text-slate-600">{r.score} / {r.maxScore}</td>
                <td className="px-3 py-2.5 text-slate-600">{Math.round(r.percentage)}%</td>
                <td className="px-3 py-2.5">
                  {r.grade ? (
                    <span className="text-xs font-medium bg-brand-50 text-brand-700 rounded-full px-2 py-0.5">
                      {r.grade.label}
                    </span>
                  ) : (
                    <span className="text-slate-400">—</span>
                  )}
                </td>
                <td className="px-3 py-2.5 text-slate-500">
                  {r.term ? `${r.term.name}, ${r.term.academicYear.name}` : "—"}
                </td>
              </tr>
            ))}
            {results.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3 py-8 text-center text-slate-400">
                  No results yet — quiz and assignment scores will appear here.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {results.some((r) => r.teacherRemark) && (
        <div className="bg-white rounded-lg border border-slate-200 p-4 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
            Teacher Remarks
          </p>
          {results
            .filter((r) => r.teacherRemark)
            .map((r) => (
              <p key={r.id} className="text-sm text-slate-600">
                <span className="font-medium text-slate-700">{r.title}:</span> {r.teacherRemark}
              </p>
            ))}
        </div>
      )}
    </div>
  );
}
