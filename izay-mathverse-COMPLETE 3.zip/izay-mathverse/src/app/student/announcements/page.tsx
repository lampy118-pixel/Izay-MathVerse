import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

export default async function StudentAnnouncementsPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const myClassIds = (
    await prisma.classStudent.findMany({ where: { studentId: user.id }, select: { classId: true } })
  ).map((c) => c.classId);

  const announcements = await prisma.announcement.findMany({
    where: {
      OR: [
        { audience: "ALL_STUDENTS" },
        { audience: "SCHOOL", organizationId: user.organizationId ?? undefined },
        { audience: "CLASS", classId: { in: myClassIds } },
      ],
    },
    orderBy: { createdAt: "desc" },
    include: { author: true },
    take: 30,
  });

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Announcements</h1>
      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {announcements.map((a) => (
          <div key={a.id} className="p-4">
            <p className="font-medium text-slate-800">{a.title}</p>
            <p className="text-sm text-slate-600 mt-1">{a.body}</p>
            <p className="text-xs text-slate-400 mt-2">
              {a.author.firstName} {a.author.lastName} · {a.createdAt.toLocaleDateString()}
            </p>
          </div>
        ))}
        {announcements.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No announcements yet.</p>
        )}
      </div>
    </div>
  );
}
