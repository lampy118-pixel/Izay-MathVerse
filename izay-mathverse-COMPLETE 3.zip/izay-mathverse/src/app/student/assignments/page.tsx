import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

export default async function StudentAssignmentsPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const assignments = await prisma.assignment.findMany({
    where: { course: { status: "AVAILABLE" } },
    orderBy: { dueDate: "asc" },
    include: {
      course: true,
      submissions: { where: { studentId: user.id } },
    },
  });

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Assignments</h1>
      <div className="space-y-3">
        {assignments.map((a) => {
          const mine = a.submissions[0];
          const overdue = !mine && new Date() > a.dueDate;
          return (
            <Link
              key={a.id}
              href={`/student/assignments/${a.id}`}
              className="block bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition"
            >
              <div className="flex items-center justify-between">
                <p className="font-semibold text-slate-800">{a.title}</p>
                {mine ? (
                  <span className="text-[10px] font-medium bg-green-100 text-green-700 rounded-full px-2 py-0.5">
                    {mine.status}
                  </span>
                ) : overdue ? (
                  <span className="text-[10px] font-medium bg-red-100 text-red-700 rounded-full px-2 py-0.5">
                    Overdue
                  </span>
                ) : (
                  <span className="text-[10px] font-medium bg-slate-100 text-slate-600 rounded-full px-2 py-0.5">
                    Not submitted
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {a.course.name} · Due {a.dueDate.toLocaleString()} · {a.totalMarks} marks
              </p>
            </Link>
          );
        })}
        {assignments.length === 0 && (
          <p className="text-sm text-slate-400">No assignments right now.</p>
        )}
      </div>
    </div>
  );
}
