import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { MathContent } from "@/components/math-content";
import { submitAssignment } from "@/lib/actions/assignments";

export default async function StudentAssignmentDetailPage({ params }: { params: { id: string } }) {
  const user = await getSessionUser();
  if (!user) return null;

  const assignment = await prisma.assignment.findUnique({
    where: { id: params.id },
    include: { course: true, attachments: true },
  });
  if (!assignment) notFound();

  const mySubmission = await prisma.submission.findFirst({
    where: { assignmentId: assignment.id, studentId: user.id },
  });

  const isPastDue = new Date() > assignment.dueDate;
  const canEdit = !mySubmission || mySubmission.status === "SUBMITTED" || mySubmission.status === "LATE";

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <Link href="/student/assignments" className="text-xs text-brand-700 hover:underline">← All assignments</Link>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <h1 className="text-xl font-bold text-slate-800">{assignment.title}</h1>
        <p className="text-xs text-slate-500 mt-1">
          {assignment.course.name} · Due {assignment.dueDate.toLocaleString()} · {assignment.totalMarks} marks
        </p>

        <div className="mt-4">
          <MathContent text={assignment.instructions} className="text-sm text-slate-700" />
        </div>

        {assignment.attachments.length > 0 && (
          <div className="mt-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-1">Attachments</p>
            <ul className="space-y-1">
              {assignment.attachments.map((a) => (
                <li key={a.id}>
                  <a href={a.fileUrl} target="_blank" rel="noreferrer" className="text-sm text-brand-700 hover:underline">
                    📎 {a.fileName}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {mySubmission?.status === "MARKED" || mySubmission?.status === "RETURNED" ? (
        <div className="bg-green-50 border border-green-200 rounded-lg p-5">
          <p className="text-sm font-semibold text-green-800">
            Marked: {mySubmission.marksAwarded} / {assignment.totalMarks}
          </p>
          {mySubmission.feedback && (
            <p className="text-sm text-green-700 mt-2">{mySubmission.feedback}</p>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-3">
            {mySubmission ? "Your Submission" : "Submit Your Work"}
          </p>
          {!canEdit ? (
            <p className="text-sm text-slate-500">Your submission is being marked.</p>
          ) : (
            <form action={submitAssignment.bind(null, assignment.id)} className="space-y-3">
              <textarea
                name="answerText"
                rows={5}
                defaultValue={mySubmission?.answerText ?? ""}
                placeholder="Type your answer here"
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  Or link to a file (upload not yet configured — see README)
                </label>
                <input
                  name="fileUrl"
                  defaultValue={mySubmission?.fileUrl ?? ""}
                  className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              {isPastDue && (
                <p className="text-xs text-amber-600">
                  This is past the due date — your submission will be marked Late.
                </p>
              )}
              <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2.5 hover:bg-brand-700 transition">
                {mySubmission ? "Update Submission" : "Submit"}
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
