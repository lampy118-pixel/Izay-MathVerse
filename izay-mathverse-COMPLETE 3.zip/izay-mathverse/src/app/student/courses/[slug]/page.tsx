import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { LockedCourseNotice } from "@/components/locked-course-notice";

export default async function StudentCoursePage({
  params,
}: {
  params: { slug: string };
}) {
  const course = await prisma.course.findUnique({
    where: { slug: params.slug },
    include: { levels: { orderBy: { sortOrder: "asc" } } },
  });

  if (!course) notFound();

  // Course status is read from the database on every request — an admin
  // flipping the toggle in /admin/courses takes effect immediately, with
  // no code change or redeploy (spec §7, §45).
  if (course.status === "RESTRICTED") {
    return <LockedCourseNotice course={course} />;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <h1 className="text-xl font-bold text-slate-800">{course.name}</h1>
      <p className="text-sm text-slate-500">{course.description}</p>

      <div className="grid sm:grid-cols-2 gap-3">
        {course.levels.map((level) => (
          <Link
            key={level.id}
            href={`/student/curriculum/${level.id}`}
            className="bg-white rounded-lg border border-slate-200 p-4 hover:border-brand-400 hover:shadow-sm transition font-semibold text-slate-800"
          >
            {level.name}
          </Link>
        ))}
        {course.levels.length === 0 && (
          <p className="text-sm text-slate-400">
            No curriculum has been imported for this course yet.
          </p>
        )}
      </div>

      <Link href="/student" className="text-sm text-brand-700 hover:underline block pt-2">
        ← Back to dashboard
      </Link>
    </div>
  );
}
