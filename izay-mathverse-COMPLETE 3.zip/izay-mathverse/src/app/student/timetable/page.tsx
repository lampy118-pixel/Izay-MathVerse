import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export default async function StudentTimetablePage({
  searchParams,
}: {
  searchParams: { view?: string };
}) {
  const user = await getSessionUser();
  if (!user) return null;

  const view = searchParams.view ?? "today";
  const today = startOfDay(new Date());
  let from = today;
  let to = new Date(today);

  if (view === "tomorrow") {
    from = new Date(today);
    from.setDate(from.getDate() + 1);
    to = new Date(from);
    to.setDate(to.getDate() + 1);
  } else if (view === "week") {
    to = new Date(today);
    to.setDate(to.getDate() + 7);
  } else {
    to.setDate(to.getDate() + 1);
  }

  const myClassIds = (
    await prisma.classStudent.findMany({ where: { studentId: user.id }, select: { classId: true } })
  ).map((c) => c.classId);

  const entries = await prisma.timetableEntry.findMany({
    where: { classId: { in: myClassIds }, date: { gte: from, lt: to } },
    orderBy: [{ date: "asc" }, { startTime: "asc" }],
    include: { class: true },
  });

  const tabs = [
    { key: "today", label: "Today" },
    { key: "tomorrow", label: "Tomorrow" },
    { key: "week", label: "This Week" },
  ];

  return (
    <div className="max-w-lg mx-auto p-4 sm:p-6 space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Timetable</h1>

      <div className="flex gap-2">
        {tabs.map((t) => (
          <Link
            key={t.key}
            href={`/student/timetable?view=${t.key}`}
            className={`text-sm font-medium rounded-md px-3 py-1.5 transition ${
              view === t.key ? "bg-brand-600 text-white" : "bg-white border border-slate-300 text-slate-600 hover:bg-slate-50"
            }`}
          >
            {t.label}
          </Link>
        ))}
      </div>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {entries.map((e) => (
          <div key={e.id} className="p-3 text-sm">
            <p className="text-slate-800 font-medium">
              {e.startTime}–{e.endTime} · {e.class.name}
            </p>
            <p className="text-xs text-slate-400">
              {e.date.toLocaleDateString()}
              {e.topicLabel ? ` · ${e.topicLabel}` : ""}
              {e.venue ? ` · ${e.venue}` : ""}
            </p>
          </div>
        ))}
        {entries.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">
            {myClassIds.length === 0
              ? "You're not enrolled in a class yet — an admin can add you under Admin → Classes."
              : "Nothing scheduled for this period."}
          </p>
        )}
      </div>
    </div>
  );
}
