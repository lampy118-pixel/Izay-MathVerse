import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { RoadmapNote } from "@/components/roadmap-note";

export default async function StudentDashboardPage() {
  const user = await getSessionUser();
  const courses = await prisma.course.findMany({ orderBy: { name: "asc" } });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">
          Welcome, {user?.name}
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Continue learning below.
        </p>
      </div>

      <div className="flex gap-2">
        <Link
          href="/student/practice"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Start Practicing
        </Link>
        <Link
          href="/student/progress"
          className="rounded-md border border-slate-300 text-slate-600 text-sm font-medium px-4 py-2 hover:bg-slate-50 transition"
        >
          View Progress
        </Link>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {courses.map((course) => (
          <Link
            key={course.id}
            href={`/student/courses/${course.slug}`}
            className="bg-white rounded-lg border border-slate-200 p-5 hover:border-brand-400 hover:shadow-sm transition"
          >
            <div className="flex items-start justify-between">
              <h2 className="font-semibold text-slate-800">{course.name}</h2>
              <span
                className={
                  course.status === "AVAILABLE"
                    ? "text-xs font-medium bg-green-100 text-green-700 rounded-full px-2.5 py-1 shrink-0"
                    : "text-xs font-medium bg-red-100 text-red-700 rounded-full px-2.5 py-1 shrink-0"
                }
              >
                {course.status === "AVAILABLE" ? "🟢 Available" : "🔒 Restricted"}
              </span>
            </div>
            {course.description && (
              <p className="text-sm text-slate-500 mt-2">
                {course.description}
              </p>
            )}
          </Link>
        ))}
        {courses.length === 0 && (
          <p className="text-sm text-slate-400">No courses available yet.</p>
        )}
      </div>

      <RoadmapNote
        items={[
          "Quizzes, tests, assignments — Phases 6–7",
          "WASSCE preparation, downloads, achievements — Phase 9",
        ]}
      />
    </div>
  );
}
