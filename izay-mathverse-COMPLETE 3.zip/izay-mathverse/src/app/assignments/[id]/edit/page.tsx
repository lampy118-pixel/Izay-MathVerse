import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { MathContent } from "@/components/math-content";
import { addAssignmentAttachment, markSubmission, returnSubmission } from "@/lib/actions/assignments";

const STATUS_BADGE: Record<string, string> = {
  SUBMITTED: "bg-blue-100 text-blue-700",
  LATE: "bg-amber-100 text-amber-700",
  MARKED: "bg-green-100 text-green-700",
  RETURNED: "bg-slate-100 text-slate-600",
};

export default async function AssignmentEditPage({ params }: { params: { id: string } }) {
  const assignment = await prisma.assignment.findUnique({
    where: { id: params.id },
    include: {
      course: true,
      attachments: true,
      submissions: { include: { student: true }, orderBy: { submittedAt: "desc" } },
    },
  });
  if (!assignment) notFound();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-slate-800">{assignment.title}</h1>
          <p className="text-xs text-slate-400">
            {assignment.course.name} · Due {assignment.dueDate.toLocaleString()} ·{" "}
            {assignment.totalMarks} marks
          </p>
        </div>
        <Link href="/assignments" className="text-xs text-brand-700 hover:underline">← All assignments</Link>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Instructions</p>
        <MathContent text={assignment.instructions} className="text-sm text-slate-700" />
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">Attachments</p>
        <ul className="space-y-1 mb-3">
          {assignment.attachments.map((a) => (
            <li key={a.id} className="text-sm text-slate-600">📎 {a.fileName}</li>
          ))}
          {assignment.attachments.length === 0 && (
            <li className="text-xs text-slate-400">No attachments yet.</li>
          )}
        </ul>
        <form action={addAssignmentAttachment.bind(null, assignment.id)} className="flex flex-wrap gap-2 items-end">
          <div>
            <label className="block text-xs text-slate-500 mb-0.5">File name</label>
            <input name="fileName" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-0.5">File URL</label>
            <input name="fileUrl" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm" />
          </div>
          <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">
            + Add
          </button>
        </form>
      </div>

      <div>
        <p className="text-sm font-semibold text-slate-700 mb-3">
          Submissions ({assignment.submissions.length})
        </p>
        <div className="space-y-3">
          {assignment.submissions.map((s) => (
            <div key={s.id} className="bg-white rounded-lg border border-slate-200 p-4">
              <div className="flex items-center justify-between">
                <p className="font-medium text-slate-800 text-sm">
                  {s.student.firstName} {s.student.lastName}
                </p>
                <span className={`text-[10px] font-medium rounded-full px-2 py-0.5 ${STATUS_BADGE[s.status]}`}>
                  {s.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Submitted {s.submittedAt.toLocaleString()}
              </p>
              {s.answerText && (
                <p className="text-sm text-slate-600 mt-2 whitespace-pre-line">{s.answerText}</p>
              )}
              {s.fileUrl && (
                <a href={s.fileUrl} target="_blank" rel="noreferrer" className="text-sm text-brand-700 hover:underline mt-1 inline-block">
                  View submitted file ↗
                </a>
              )}

              {s.status === "MARKED" || s.status === "RETURNED" ? (
                <div className="mt-3 bg-green-50 rounded-md p-3 text-sm">
                  <p className="font-medium text-green-800">
                    {s.marksAwarded} / {assignment.totalMarks}
                  </p>
                  {s.feedback && <p className="text-green-700 mt-1">{s.feedback}</p>}
                  {s.status === "MARKED" && (
                    <form action={returnSubmission.bind(null, s.id)} className="mt-2">
                      <button className="text-xs font-medium text-brand-700 hover:underline">
                        Return to student
                      </button>
                    </form>
                  )}
                </div>
              ) : (
                <form action={markSubmission.bind(null, s.id)} className="mt-3 flex flex-wrap gap-2 items-end">
                  <div>
                    <label className="block text-xs text-slate-500 mb-0.5">Marks (/{assignment.totalMarks})</label>
                    <input name="marksAwarded" type="number" min={0} max={assignment.totalMarks} className="w-20 rounded-md border border-slate-300 px-2 py-1.5 text-sm" />
                  </div>
                  <div className="flex-1 min-w-[160px]">
                    <label className="block text-xs text-slate-500 mb-0.5">Feedback</label>
                    <input name="feedback" className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm" />
                  </div>
                  <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">
                    Save Mark
                  </button>
                </form>
              )}
            </div>
          ))}
          {assignment.submissions.length === 0 && (
            <p className="text-sm text-slate-400">No submissions yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
