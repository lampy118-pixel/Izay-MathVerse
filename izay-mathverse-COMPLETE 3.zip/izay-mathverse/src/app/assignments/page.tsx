import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function AssignmentsPage() {
  const assignments = await prisma.assignment.findMany({
    orderBy: { dueDate: "desc" },
    include: { course: true, submissions: true },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Assignments</h1>
        <Link
          href="/assignments/new"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          + New Assignment
        </Link>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {assignments.map((a) => {
          const marked = a.submissions.filter((s) => s.status === "MARKED" || s.status === "RETURNED").length;
          return (
            <Link
              key={a.id}
              href={`/assignments/${a.id}/edit`}
              className="block p-4 hover:bg-slate-50 transition"
            >
              <p className="font-medium text-slate-800">{a.title}</p>
              <p className="text-xs text-slate-400 mt-1">
                {a.course.name} · Due {a.dueDate.toLocaleDateString()} ·{" "}
                {a.submissions.length} submission{a.submissions.length === 1 ? "" : "s"}
                {" "}({marked} marked)
              </p>
            </Link>
          );
        })}
        {assignments.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No assignments yet.</p>
        )}
      </div>
    </div>
  );
}
