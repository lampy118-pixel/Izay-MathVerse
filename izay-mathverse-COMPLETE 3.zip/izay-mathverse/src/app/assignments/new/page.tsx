import { prisma } from "@/lib/prisma";
import { createAssignment } from "@/lib/actions/assignments";

export default async function NewAssignmentPage() {
  const courses = await prisma.course.findMany({ orderBy: { name: "asc" } });

  return (
    <div className="max-w-lg mx-auto space-y-4">
      <h1 className="text-xl font-bold text-slate-800">New Assignment</h1>
      <form action={createAssignment} className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Course *</label>
          <select name="courseId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {courses.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Title *</label>
          <input name="title" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Instructions *</label>
          <textarea name="instructions" required rows={4} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" placeholder="Supports $inline$ and $$display$$ LaTeX" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Total marks</label>
            <input name="totalMarks" type="number" min={1} defaultValue={10} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Due date *</label>
            <input name="dueDate" type="datetime-local" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
        </div>
        <button type="submit" className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition">
          Create & Continue
        </button>
      </form>
    </div>
  );
}
