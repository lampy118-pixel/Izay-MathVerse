import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { createAnnouncement } from "@/lib/actions/announcements";

export default async function AnnouncementsPage() {
  const user = await getSessionUser();
  if (!user || !["SUPER_ADMIN", "ADMIN", "TEACHER"].includes(user.role)) {
    redirect("/unauthorized");
  }

  const [organizations, classes, announcements] = await Promise.all([
    prisma.organization.findMany({ orderBy: { name: "asc" } }),
    prisma.class.findMany({ orderBy: { name: "asc" } }),
    prisma.announcement.findMany({ orderBy: { createdAt: "desc" }, include: { author: true }, take: 30 }),
  ]);

  const backHref = user.role === "TEACHER" ? "/teacher" : "/admin";

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3">
        <Link href={backHref} className="text-xs text-brand-700 hover:underline">← Back to dashboard</Link>
        <p className="font-semibold text-slate-800">Announcements</p>
      </header>
      <main className="max-w-lg mx-auto p-4 sm:p-6 space-y-6">
        <form action={createAnnouncement} className="bg-white rounded-lg border border-slate-200 p-5 space-y-3">
          <p className="text-sm font-semibold text-slate-700">New Announcement</p>
          <input name="title" required placeholder="Title" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <textarea name="body" required rows={3} placeholder="Message" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <select name="audience" defaultValue="ALL_STUDENTS" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="ALL_STUDENTS">All Students</option>
            <option value="SCHOOL">Specific School</option>
            <option value="CLASS">Specific Class</option>
          </select>
          <select name="organizationId" defaultValue="" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="">— School (if targeting School) —</option>
            {organizations.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
          <select name="classId" defaultValue="" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="">— Class (if targeting Class) —</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition">
            Post Announcement
          </button>
        </form>

        <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
          {announcements.map((a) => (
            <div key={a.id} className="p-4">
              <p className="font-medium text-slate-800">{a.title}</p>
              <p className="text-sm text-slate-600 mt-1">{a.body}</p>
              <p className="text-xs text-slate-400 mt-2">
                {a.author.firstName} {a.author.lastName} · {a.audience.replace("_", " ")} · {a.createdAt.toLocaleDateString()}
              </p>
            </div>
          ))}
          {announcements.length === 0 && <p className="p-6 text-center text-sm text-slate-400">No announcements yet.</p>}
        </div>
      </main>
    </div>
  );
}
