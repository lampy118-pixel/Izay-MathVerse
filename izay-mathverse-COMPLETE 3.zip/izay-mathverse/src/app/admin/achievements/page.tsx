import { prisma } from "@/lib/prisma";
import { createAchievement, toggleAchievement, awardAchievement } from "@/lib/actions/achievements";

export default async function AchievementsPage() {
  const [achievements, students] = await Promise.all([
    prisma.achievement.findMany({ orderBy: { name: "asc" }, include: { userAchievements: true } }),
    prisma.user.findMany({ where: { role: "STUDENT" }, orderBy: { firstName: "asc" } }),
  ]);

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Achievements</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Optional motivational system (spec §59). Awarding here is manual
          only — there&apos;s no automatic detection (e.g. streaks, question
          counts) wired up yet, so nothing claims to unlock itself.
        </p>
      </div>

      <form action={createAchievement} className="bg-white rounded-lg border border-slate-200 p-5 space-y-3">
        <p className="text-sm font-semibold text-slate-700">New Achievement</p>
        <input name="name" required placeholder='e.g. "Algebra Master"' className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        <input name="description" placeholder="Description (optional)" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition">
          Create Achievement
        </button>
      </form>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {achievements.map((a) => (
          <div key={a.id} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-slate-800">{a.name}</p>
                {a.description && <p className="text-xs text-slate-500">{a.description}</p>}
                <p className="text-xs text-slate-400 mt-0.5">{a.userAchievements.length} student(s) earned</p>
              </div>
              <form action={toggleAchievement.bind(null, a.id)}>
                <button className={`text-xs font-medium rounded-full px-2.5 py-0.5 ${a.isEnabled ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-500"}`}>
                  {a.isEnabled ? "Enabled" : "Disabled"}
                </button>
              </form>
            </div>
          </div>
        ))}
        {achievements.length === 0 && <p className="p-6 text-center text-sm text-slate-400">No achievements defined yet.</p>}
      </div>

      {achievements.length > 0 && students.length > 0 && (
        <form action={awardAchievement} className="bg-white rounded-lg border border-slate-200 p-5 space-y-3">
          <p className="text-sm font-semibold text-slate-700">Manually Award</p>
          <select name="studentId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {students.map((s) => <option key={s.id} value={s.id}>{s.firstName} {s.lastName}</option>)}
          </select>
          <select name="achievementId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {achievements.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
          <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition">
            Award
          </button>
        </form>
      )}
    </div>
  );
}
