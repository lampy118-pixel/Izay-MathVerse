import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/rbac";
import { DashboardShell } from "@/components/dashboard-shell";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/admin" },
  { label: "Organizations", href: "/admin/organizations" },
  { label: "Classes", href: "/admin/classes" },
  { label: "Courses", href: "/admin/courses" },
  { label: "Curriculum", href: "/curriculum" },
  { label: "Questions", href: "/questions" },
  { label: "Quizzes", href: "/quizzes" },
  { label: "Assignments", href: "/assignments" },
  { label: "Analytics", href: "/analytics" },
  { label: "Attendance", href: "/attendance" },
  { label: "Timetable", href: "/timetable" },
  { label: "Announcements", href: "/announcements" },
  { label: "WASSCE Prep", href: "/wassce" },
  { label: "Achievements", href: "/admin/achievements" },
  { label: "Search", href: "/search" },
  { label: "Users", href: "/admin/users" },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if (!user || (user.role !== "ADMIN" && user.role !== "SUPER_ADMIN")) {
    redirect("/unauthorized");
  }

  return (
    <DashboardShell user={user} navItems={NAV_ITEMS}>
      {children}
    </DashboardShell>
  );
}
