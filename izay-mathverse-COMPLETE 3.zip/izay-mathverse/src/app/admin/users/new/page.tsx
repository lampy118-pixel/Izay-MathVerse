import { prisma } from "@/lib/prisma";
import { createUser } from "@/lib/actions/users";

export default async function NewUserPage() {
  const organizations = await prisma.organization.findMany({
    orderBy: { name: "asc" },
  });

  return (
    <div className="max-w-lg space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Add User</h1>

      <form
        action={createUser}
        className="bg-white rounded-lg border border-slate-200 p-5 space-y-4"
      >
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              First name *
            </label>
            <input
              name="firstName"
              required
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Last name *
            </label>
            <input
              name="lastName"
              required
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Email *
          </label>
          <input
            name="email"
            type="email"
            required
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Temporary password *
          </label>
          <input
            name="password"
            type="text"
            required
            minLength={8}
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            placeholder="At least 8 characters"
          />
          <p className="text-xs text-slate-400 mt-1">
            Share this with the user directly — it is hashed on save and
            never stored or shown again. Self-service password reset arrives
            in a later phase.
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Role
          </label>
          <select
            name="role"
            defaultValue="STUDENT"
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="STUDENT">Student</option>
            <option value="TEACHER">Teacher</option>
            <option value="ADMIN">Administrator</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Organization / School
          </label>
          <select
            name="organizationId"
            defaultValue=""
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">— Independent / none —</option>
            {organizations.map((org) => (
              <option key={org.id} value={org.id}>
                {org.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Create User
        </button>
      </form>
    </div>
  );
}
