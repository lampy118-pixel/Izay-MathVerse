import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { toggleUserActive } from "@/lib/actions/users";

const ROLE_BADGE: Record<string, string> = {
  SUPER_ADMIN: "bg-purple-100 text-purple-700",
  ADMIN: "bg-blue-100 text-blue-700",
  TEACHER: "bg-amber-100 text-amber-700",
  STUDENT: "bg-slate-100 text-slate-700",
};

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    include: { organization: true },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-800">Users</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Students, teachers and administrators across the platform.
          </p>
        </div>
        <Link
          href="/admin/users/new"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          + Add User
        </Link>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 overflow-x-auto">
        <table className="w-full text-sm min-w-[640px]">
          <thead className="bg-slate-50 text-slate-500 text-left">
            <tr>
              <th className="px-4 py-2 font-medium">Name</th>
              <th className="px-4 py-2 font-medium">Email</th>
              <th className="px-4 py-2 font-medium">Role</th>
              <th className="px-4 py-2 font-medium">Organization</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((u) => (
              <tr key={u.id}>
                <td className="px-4 py-3 font-medium text-slate-800">
                  {u.firstName} {u.lastName}
                </td>
                <td className="px-4 py-3 text-slate-600">{u.email}</td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs font-medium rounded-full px-2 py-0.5 ${
                      ROLE_BADGE[u.role] ?? "bg-slate-100 text-slate-700"
                    }`}
                  >
                    {u.role.replace("_", " ")}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-600">
                  {u.organization?.name ?? "—"}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={
                      u.isActive
                        ? "text-green-700 bg-green-100 rounded-full px-2 py-0.5 text-xs font-medium"
                        : "text-slate-500 bg-slate-100 rounded-full px-2 py-0.5 text-xs font-medium"
                    }
                  >
                    {u.isActive ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <form action={toggleUserActive.bind(null, u.id)}>
                    <button className="text-xs font-medium text-brand-700 hover:underline">
                      {u.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                  No users yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
