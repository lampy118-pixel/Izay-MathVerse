import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function ClassesPage() {
  const classes = await prisma.class.findMany({
    orderBy: { name: "asc" },
    include: { organization: true, academicYear: true, students: true, teachers: true },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Classes</h1>
        <Link href="/admin/classes/new" className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition">
          + New Class
        </Link>
      </div>
      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {classes.map((c) => (
          <Link key={c.id} href={`/admin/classes/${c.id}`} className="block p-4 hover:bg-slate-50 transition">
            <p className="font-medium text-slate-800">{c.name}</p>
            <p className="text-xs text-slate-400 mt-1">
              {c.organization.name} · {c.academicYear.name} · {c.teachers.length} teacher{c.teachers.length === 1 ? "" : "s"} ·{" "}
              {c.students.length} student{c.students.length === 1 ? "" : "s"}
            </p>
          </Link>
        ))}
        {classes.length === 0 && <p className="p-6 text-center text-sm text-slate-400">No classes yet.</p>}
      </div>
    </div>
  );
}
