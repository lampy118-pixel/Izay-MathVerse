import { prisma } from "@/lib/prisma";
import { createClass } from "@/lib/actions/classes";

export default async function NewClassPage() {
  const [organizations, academicYears, courses, levels] = await Promise.all([
    prisma.organization.findMany({ orderBy: { name: "asc" } }),
    prisma.academicYear.findMany({ orderBy: { name: "desc" }, include: { organization: true } }),
    prisma.course.findMany({ orderBy: { name: "asc" } }),
    prisma.academicLevel.findMany({ orderBy: { name: "asc" }, include: { course: true } }),
  ]);

  return (
    <div className="max-w-lg mx-auto space-y-4">
      <h1 className="text-xl font-bold text-slate-800">New Class</h1>
      <form action={createClass} className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Organization *</label>
          <select name="organizationId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {organizations.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Academic Year *</label>
          <select name="academicYearId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {academicYears.map((y) => <option key={y.id} value={y.id}>{y.organization.name} — {y.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Class name *</label>
          <input name="name" required placeholder="e.g. SHS 2 Gold" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Course (optional)</label>
          <select name="courseId" defaultValue="" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="">— None —</option>
            {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Level (optional)</label>
          <select name="academicLevelId" defaultValue="" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="">— None —</option>
            {levels.map((l) => <option key={l.id} value={l.id}>{l.course.name} — {l.name}</option>)}
          </select>
        </div>
        <button type="submit" className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition">
          Create & Continue
        </button>
      </form>
    </div>
  );
}
