import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { assignTeacherToClass, enrollStudentInClass, removeStudentFromClass } from "@/lib/actions/classes";

export default async function ClassDetailPage({ params }: { params: { id: string } }) {
  const cls = await prisma.class.findUnique({
    where: { id: params.id },
    include: {
      organization: true,
      teachers: { include: { teacher: true } },
      students: { include: { student: true } },
    },
  });
  if (!cls) notFound();

  const enrolledIds = new Set(cls.students.map((s) => s.studentId));
  const assignedTeacherIds = new Set(cls.teachers.map((t) => t.teacherId));

  const [availableStudents, availableTeachers] = await Promise.all([
    prisma.user.findMany({
      where: { role: "STUDENT", organizationId: cls.organizationId, id: { notIn: Array.from(enrolledIds) } },
      orderBy: { firstName: "asc" },
    }),
    prisma.user.findMany({
      where: { role: "TEACHER", organizationId: cls.organizationId, id: { notIn: Array.from(assignedTeacherIds) } },
      orderBy: { firstName: "asc" },
    }),
  ]);

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">{cls.name}</h1>
        <p className="text-sm text-slate-500">{cls.organization.name}</p>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">Teachers</p>
        <ul className="space-y-1 mb-3">
          {cls.teachers.map((t) => (
            <li key={t.id} className="text-sm text-slate-600">{t.teacher.firstName} {t.teacher.lastName}</li>
          ))}
          {cls.teachers.length === 0 && <li className="text-xs text-slate-400">No teacher assigned yet.</li>}
        </ul>
        <form action={assignTeacherToClass.bind(null, cls.id)} className="flex gap-2">
          <select name="teacherId" className="flex-1 rounded-md border border-slate-300 px-2 py-1.5 text-sm">
            <option value="">— Select a teacher —</option>
            {availableTeachers.map((t) => <option key={t.id} value={t.id}>{t.firstName} {t.lastName}</option>)}
          </select>
          <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">Assign</button>
        </form>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">Students ({cls.students.length})</p>
        <ul className="space-y-1 mb-3">
          {cls.students.map((s) => (
            <li key={s.id} className="flex items-center justify-between text-sm">
              <span className="text-slate-600">{s.student.firstName} {s.student.lastName}</span>
              <form action={removeStudentFromClass.bind(null, cls.id, s.id)}>
                <button className="text-xs text-red-600 hover:underline">Remove</button>
              </form>
            </li>
          ))}
          {cls.students.length === 0 && <li className="text-xs text-slate-400">No students enrolled yet.</li>}
        </ul>
        <form action={enrollStudentInClass.bind(null, cls.id)} className="flex gap-2">
          <select name="studentId" className="flex-1 rounded-md border border-slate-300 px-2 py-1.5 text-sm">
            <option value="">— Select a student —</option>
            {availableStudents.map((s) => <option key={s.id} value={s.id}>{s.firstName} {s.lastName}</option>)}
          </select>
          <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">Enroll</button>
        </form>
      </div>
    </div>
  );
}
