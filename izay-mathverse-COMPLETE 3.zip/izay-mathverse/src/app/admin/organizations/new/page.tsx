import { createOrganization } from "@/lib/actions/organizations";

export default function NewOrganizationPage() {
  return (
    <div className="max-w-lg space-y-4">
      <h1 className="text-xl font-bold text-slate-800">Add School / Organization</h1>

      <form action={createOrganization} className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Name *
          </label>
          <input
            name="name"
            required
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            placeholder="e.g. Accra High School"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Type
          </label>
          <select
            name="type"
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            defaultValue="SCHOOL"
          >
            <option value="SCHOOL">School</option>
            <option value="INDEPENDENT">Independent / Private Learning</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Address
          </label>
          <input
            name="address"
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Contact email
            </label>
            <input
              name="contactEmail"
              type="email"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Contact phone
            </label>
            <input
              name="contactPhone"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Brand color (hex)
          </label>
          <input
            name="brandColor"
            placeholder="#2563eb"
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <p className="text-xs text-slate-400">
          Logo upload requires file storage configuration (see README) and
          will be enabled once that&apos;s connected — not part of this
          phase.
        </p>

        <button
          type="submit"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          Create School
        </button>
      </form>
    </div>
  );
}
