import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { toggleOrganizationActive } from "@/lib/actions/organizations";

export default async function OrganizationsPage() {
  const organizations = await prisma.organization.findMany({
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { users: true, classes: true } } },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-800">
            Organizations & Schools
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Izay MathVerse is school-independent — schools are data, not
            code.
          </p>
        </div>
        <Link
          href="/admin/organizations/new"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          + Add School
        </Link>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-left">
            <tr>
              <th className="px-4 py-2 font-medium">Name</th>
              <th className="px-4 py-2 font-medium">Type</th>
              <th className="px-4 py-2 font-medium">Users</th>
              <th className="px-4 py-2 font-medium">Classes</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {organizations.map((org) => (
              <tr key={org.id}>
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-800">{org.name}</p>
                  <p className="text-xs text-slate-400">{org.slug}</p>
                </td>
                <td className="px-4 py-3 text-slate-600">
                  {org.type === "SCHOOL" ? "School" : "Independent"}
                </td>
                <td className="px-4 py-3 text-slate-600">
                  {org._count.users}
                </td>
                <td className="px-4 py-3 text-slate-600">
                  {org._count.classes}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={
                      org.isActive
                        ? "text-green-700 bg-green-100 rounded-full px-2 py-0.5 text-xs font-medium"
                        : "text-slate-500 bg-slate-100 rounded-full px-2 py-0.5 text-xs font-medium"
                    }
                  >
                    {org.isActive ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <form
                    action={toggleOrganizationActive.bind(null, org.id)}
                  >
                    <button className="text-xs font-medium text-brand-700 hover:underline">
                      {org.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {organizations.length === 0 && (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-8 text-center text-slate-400"
                >
                  No organizations yet. Add the first school above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
