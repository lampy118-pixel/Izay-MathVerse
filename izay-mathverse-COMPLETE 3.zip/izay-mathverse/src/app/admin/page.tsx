import { prisma } from "@/lib/prisma";
import { RoadmapNote } from "@/components/roadmap-note";

export default async function AdminDashboardPage() {
  const [orgCount, userCount, teacherCount, studentCount, courses] =
    await Promise.all([
      prisma.organization.count(),
      prisma.user.count(),
      prisma.user.count({ where: { role: "TEACHER" } }),
      prisma.user.count({ where: { role: "STUDENT" } }),
      prisma.course.findMany({ orderBy: { name: "asc" } }),
    ]);

  const stats = [
    { label: "Organizations", value: orgCount },
    { label: "Total Users", value: userCount },
    { label: "Teachers", value: teacherCount },
    { label: "Students", value: studentCount },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">
          Administrator Dashboard
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Platform-wide overview across all organizations.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats.map((s) => (
          <div
            key={s.label}
            className="bg-white rounded-lg border border-slate-200 p-4"
          >
            <p className="text-2xl font-bold text-brand-700">{s.value}</p>
            <p className="text-xs text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-4">
        <p className="text-sm font-semibold text-slate-700 mb-3">
          Course status
        </p>
        <div className="space-y-2">
          {courses.map((c) => (
            <div
              key={c.id}
              className="flex items-center justify-between text-sm"
            >
              <span className="text-slate-700">{c.name}</span>
              <span
                className={
                  c.status === "AVAILABLE"
                    ? "inline-flex items-center gap-1.5 rounded-full bg-green-100 text-green-700 px-2.5 py-0.5 text-xs font-medium"
                    : "inline-flex items-center gap-1.5 rounded-full bg-red-100 text-red-700 px-2.5 py-0.5 text-xs font-medium"
                }
              >
                {c.status === "AVAILABLE" ? "🟢 Available" : "🔴 Restricted"}
              </span>
            </div>
          ))}
          {courses.length === 0 && (
            <p className="text-sm text-slate-400">No courses seeded yet.</p>
          )}
        </div>
      </div>

      <RoadmapNote
        items={[
          "Curriculum management (strands, sub-strands, topics, import) — Phase 2",
          "Lesson, material, GeoGebra & Desmos management — Phase 3",
          "Question bank — Phase 4",
          "Quizzes, tests, assignments & grading — Phases 5–7",
          "Analytics, attendance, timetable, announcements — Phases 8–9",
        ]}
      />
    </div>
  );
}
