import { prisma } from "@/lib/prisma";
import { setCourseStatus } from "@/lib/actions/courses";

export default async function AdminCoursesPage() {
  const courses = await prisma.course.findMany({
    orderBy: { name: "asc" },
    include: { levels: true },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Courses</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Toggling status here is a real database update — no code change or
          redeploy required, per spec §7.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-white rounded-lg border border-slate-200 p-5"
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-semibold text-slate-800">
                  {course.name}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {course.levels.length} level
                  {course.levels.length === 1 ? "" : "s"} configured
                </p>
              </div>
              <span
                className={
                  course.status === "AVAILABLE"
                    ? "text-xs font-medium bg-green-100 text-green-700 rounded-full px-2.5 py-1"
                    : "text-xs font-medium bg-red-100 text-red-700 rounded-full px-2.5 py-1"
                }
              >
                {course.status === "AVAILABLE"
                  ? "🟢 Available"
                  : "🔴 Restricted"}
              </span>
            </div>

            {course.description && (
              <p className="text-sm text-slate-600 mt-3">
                {course.description}
              </p>
            )}

            <div className="mt-4 flex gap-2">
              <form
                action={setCourseStatus.bind(null, course.id, "AVAILABLE")}
              >
                <button
                  disabled={course.status === "AVAILABLE"}
                  className="text-xs font-medium rounded-md border border-green-300 text-green-700 px-3 py-1.5 hover:bg-green-50 disabled:opacity-40 disabled:cursor-not-allowed transition"
                >
                  Set Available
                </button>
              </form>
              <form
                action={setCourseStatus.bind(null, course.id, "RESTRICTED")}
              >
                <button
                  disabled={course.status === "RESTRICTED"}
                  className="text-xs font-medium rounded-md border border-red-300 text-red-700 px-3 py-1.5 hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed transition"
                >
                  Set Restricted
                </button>
              </form>
            </div>
          </div>
        ))}

        {courses.length === 0 && (
          <p className="text-sm text-slate-400">
            No courses seeded yet. Run <code>npm run db:seed</code>.
          </p>
        )}
      </div>
    </div>
  );
}
