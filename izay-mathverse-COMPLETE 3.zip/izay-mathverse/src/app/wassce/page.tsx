import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/rbac";
import { addCourseMaterial } from "@/lib/actions/course-materials";

export default async function WassceStaffPage() {
  const user = await getSessionUser();
  if (!user || !["SUPER_ADMIN", "ADMIN", "TEACHER"].includes(user.role)) {
    redirect("/unauthorized");
  }

  const courses = await prisma.course.findMany({ orderBy: { name: "asc" } });
  const materials = await prisma.lessonMaterial.findMany({
    where: { courseId: { not: null }, materialLessonId: null, slideLessonId: null },
    orderBy: { createdAt: "desc" },
    include: { course: true },
  });

  const backHref = user.role === "TEACHER" ? "/teacher" : "/admin";

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3">
        <Link href={backHref} className="text-xs text-brand-700 hover:underline">← Back to dashboard</Link>
        <p className="font-semibold text-slate-800">WASSCE Preparation</p>
      </header>
      <main className="max-w-lg mx-auto p-4 sm:p-6 space-y-6">
        <p className="text-sm text-slate-500">
          Upload past questions, mock tests, revision notes, and worked
          solutions. Since file storage isn&apos;t configured yet, link to
          an already-hosted file (spec §64).
        </p>

        <form action={addCourseMaterial} className="bg-white rounded-lg border border-slate-200 p-5 space-y-3">
          <select name="courseId" required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input name="title" required placeholder='e.g. "2023 Past Questions — Paper 2"' className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <input name="fileUrl" required placeholder="File URL" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          <select name="fileType" defaultValue="PDF" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            {["PDF", "PPT", "PPTX", "DOC", "DOCX", "IMAGE", "WORKSHEET", "WORKED_SOLUTION", "OTHER"].map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <button className="w-full rounded-md bg-brand-600 text-white text-sm font-medium py-2 hover:bg-brand-700 transition">
            Add Resource
          </button>
        </form>

        <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
          {materials.map((m) => (
            <div key={m.id} className="p-3 text-sm">
              <p className="text-slate-800">{m.title}</p>
              <p className="text-xs text-slate-400">{m.course?.name} · {m.fileType}</p>
            </div>
          ))}
          {materials.length === 0 && <p className="p-6 text-center text-sm text-slate-400">No resources yet.</p>}
        </div>
      </main>
    </div>
  );
}
