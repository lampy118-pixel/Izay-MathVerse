import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import {
  updateQuizSettings,
  setQuizStatus,
  addQuizQuestion,
  removeQuizQuestion,
} from "@/lib/actions/quizzes";

export default async function QuizEditPage({ params }: { params: { id: string } }) {
  const quiz = await prisma.quiz.findUnique({
    where: { id: params.id },
    include: {
      quizQuestions: { orderBy: { sortOrder: "asc" }, include: { question: true } },
      attempts: true,
    },
  });
  if (!quiz) notFound();

  const attachedIds = new Set(quiz.quizQuestions.map((qq) => qq.questionId));
  const availableQuestions = await prisma.question.findMany({
    where: { status: "ACTIVE", courseId: quiz.courseId, id: { notIn: Array.from(attachedIds) } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-slate-800">{quiz.title}</h1>
          <span className="text-xs font-medium bg-slate-100 text-slate-600 rounded-full px-2.5 py-0.5">
            {quiz.status}
          </span>
        </div>
        <Link href="/quizzes" className="text-xs text-brand-700 hover:underline">← All quizzes</Link>
      </div>

      <div className="flex flex-wrap gap-2">
        <form action={setQuizStatus.bind(null, quiz.id, "PUBLISHED")}>
          <button className="text-xs font-medium rounded-md border border-green-300 text-green-700 px-3 py-1.5 hover:bg-green-50 transition">Publish</button>
        </form>
        <form action={setQuizStatus.bind(null, quiz.id, "DRAFT")}>
          <button className="text-xs font-medium rounded-md border border-slate-300 text-slate-600 px-3 py-1.5 hover:bg-slate-50 transition">Unpublish (Draft)</button>
        </form>
        <form action={setQuizStatus.bind(null, quiz.id, "ARCHIVED")}>
          <button className="text-xs font-medium rounded-md border border-red-300 text-red-700 px-3 py-1.5 hover:bg-red-50 transition">Archive</button>
        </form>
      </div>

      {quiz.status === "PUBLISHED" && quiz.quizQuestions.length < quiz.numberOfQuestions && (
        <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-md p-2">
          This quiz is published but its pool ({quiz.quizQuestions.length}) has fewer
          questions than it needs to serve per attempt ({quiz.numberOfQuestions}) — add
          more questions below.
        </p>
      )}

      <form action={updateQuizSettings.bind(null, quiz.id)} className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
          <input name="title" defaultValue={quiz.title} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
          <textarea name="description" rows={2} defaultValue={quiz.description ?? ""} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Number of questions per attempt</label>
            <input name="numberOfQuestions" type="number" min={1} defaultValue={quiz.numberOfQuestions} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Total marks</label>
            <input name="totalMarks" type="number" min={1} defaultValue={quiz.totalMarks} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Duration (minutes)</label>
            <input name="durationMinutes" type="number" min={1} defaultValue={quiz.durationMinutes} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Attempts allowed</label>
            <input name="attemptsAllowed" type="number" min={1} defaultValue={quiz.attemptsAllowed} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" name="randomSelection" defaultChecked={quiz.randomSelection} />
            Random question selection from the pool
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" name="shuffleQuestions" defaultChecked={quiz.shuffleQuestions} />
            Shuffle question order per student
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" name="shuffleOptions" defaultChecked={quiz.shuffleOptions} />
            Shuffle answer-option order per student
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" name="hintsEnabled" defaultChecked={quiz.hintsEnabled} />
            Allow hints during the quiz
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" name="solutionsEnabled" defaultChecked={quiz.solutionsEnabled} />
            Show solutions after submission
          </label>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Result visibility</label>
          <select name="resultVisibility" defaultValue={quiz.resultVisibility} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="IMMEDIATE">Immediate</option>
            <option value="AFTER_SUBMISSION">After submission</option>
            <option value="AFTER_DUE_DATE">After due date</option>
            <option value="MANUAL_RELEASE">Manual release</option>
          </select>
        </div>

        <button type="submit" className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition">
          Save Settings
        </button>
      </form>

      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">
          Question Pool ({quiz.quizQuestions.length})
        </p>
        <ul className="space-y-1.5 mb-3">
          {quiz.quizQuestions.map((qq) => (
            <li key={qq.id} className="flex items-center justify-between text-sm bg-slate-50 rounded-md px-3 py-2">
              <span className="truncate">{qq.question.questionText.slice(0, 70)}</span>
              <form action={removeQuizQuestion.bind(null, quiz.id, qq.id)}>
                <button className="text-xs text-red-600 hover:underline ml-2 shrink-0">Remove</button>
              </form>
            </li>
          ))}
          {quiz.quizQuestions.length === 0 && (
            <li className="text-xs text-slate-400">No questions in the pool yet.</li>
          )}
        </ul>
        <form action={addQuizQuestion.bind(null, quiz.id)} className="flex flex-wrap gap-2 items-center">
          <select name="questionId" className="rounded-md border border-slate-300 px-2 py-1.5 text-sm flex-1 min-w-[220px]">
            <option value="">— Select an active question from this course —</option>
            {availableQuestions.map((q) => (
              <option key={q.id} value={q.id}>{q.questionText.slice(0, 60)}</option>
            ))}
          </select>
          <button className="text-xs font-medium rounded-md bg-brand-600 text-white px-3 py-1.5 hover:bg-brand-700 transition">
            + Add
          </button>
        </form>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 p-4">
        <p className="text-sm font-semibold text-slate-700">
          {quiz.attempts.length} attempt{quiz.attempts.length === 1 ? "" : "s"} taken
        </p>
        <p className="text-xs text-slate-500 mt-1">
          {quiz.attempts.filter((a) => a.submittedAt).length} submitted ·{" "}
          {quiz.attempts.filter((a) => !a.submittedAt).length} in progress
        </p>
      </div>
    </div>
  );
}
