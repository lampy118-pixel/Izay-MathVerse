import Link from "next/link";
import { prisma } from "@/lib/prisma";

const STATUS_BADGE: Record<string, string> = {
  DRAFT: "bg-slate-100 text-slate-600",
  PUBLISHED: "bg-green-100 text-green-700",
  ACTIVE: "bg-blue-100 text-blue-700",
  ARCHIVED: "bg-red-100 text-red-700",
};

export default async function QuizzesPage() {
  const quizzes = await prisma.quiz.findMany({
    orderBy: { createdAt: "desc" },
    include: { course: true, quizQuestions: true, attempts: true },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-800">Quizzes</h1>
        <Link
          href="/quizzes/new"
          className="rounded-md bg-brand-600 text-white text-sm font-medium px-4 py-2 hover:bg-brand-700 transition"
        >
          + New Quiz
        </Link>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-100">
        {quizzes.map((q) => (
          <Link
            key={q.id}
            href={`/quizzes/${q.id}/edit`}
            className="block p-4 hover:bg-slate-50 transition"
          >
            <div className="flex items-center justify-between">
              <p className="font-medium text-slate-800">{q.title}</p>
              <span className={`text-[10px] font-medium rounded-full px-2 py-0.5 ${STATUS_BADGE[q.status]}`}>
                {q.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {q.course.name} · {q.quizQuestions.length} question
              {q.quizQuestions.length === 1 ? "" : "s"} in pool ·{" "}
              {q.attempts.length} attempt{q.attempts.length === 1 ? "" : "s"} taken
            </p>
          </Link>
        ))}
        {quizzes.length === 0 && (
          <p className="p-6 text-center text-sm text-slate-400">No quizzes yet.</p>
        )}
      </div>
    </div>
  );
}
