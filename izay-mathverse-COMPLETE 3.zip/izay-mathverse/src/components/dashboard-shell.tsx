import Link from "next/link";
import { SignOutButton } from "@/components/sign-out-button";
import type { SessionUser } from "@/lib/rbac";

interface NavItem {
  label: string;
  href: string;
}

const ROLE_LABEL: Record<string, string> = {
  SUPER_ADMIN: "Platform Owner",
  ADMIN: "Administrator",
  TEACHER: "Teacher",
  STUDENT: "Student",
};

export function DashboardShell({
  user,
  navItems,
  children,
}: {
  user: SessionUser;
  navItems: NavItem[];
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-slate-50 lg:flex">
      <aside className="lg:w-64 shrink-0 bg-brand-900 text-white flex lg:flex-col">
        <div className="p-5 border-b border-white/10 hidden lg:block">
          <p className="font-bold text-lg leading-tight">Izay MathVerse</p>
          <p className="text-xs text-brand-200 mt-0.5">
            {ROLE_LABEL[user.role] ?? user.role}
          </p>
        </div>
        <nav className="flex lg:flex-col gap-1 p-2 lg:p-3 overflow-x-auto lg:overflow-visible">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium text-brand-100 hover:bg-white/10 transition"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between">
          <div>
            <p className="font-medium text-slate-800">{user.name}</p>
            <p className="text-xs text-slate-500">{user.email}</p>
          </div>
          <SignOutButton />
        </header>
        <main className="p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
