import { MathContent } from "@/components/math-content";
import type {
  Lesson,
  LessonImage,
  Video,
  LessonMaterial,
  GeogebraActivity,
  DesmosActivity,
  ExternalResource,
  Question,
} from "@prisma/client";

type FullLesson = Lesson & {
  images: LessonImage[];
  videos: Video[];
  materials: LessonMaterial[];
  geogebraActivities: GeogebraActivity[];
  desmosActivities: DesmosActivity[];
  externalResources: ExternalResource[];
  practiceQuestions?: Question[];
};

function youtubeEmbedUrl(url: string): string | null {
  const match = url.match(
    /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/))([\w-]{11})/
  );
  return match ? `https://www.youtube.com/embed/${match[1]}` : null;
}

/**
 * Renders a lesson's full content — spec §17: not just blocks of text, but
 * definitions, objectives, worked examples, diagrams, videos, and
 * interactive GeoGebra/Desmos activities laid out distinctly.
 */
export function LessonViewer({ lesson }: { lesson: FullLesson }) {
  return (
    <article className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">{lesson.title}</h1>
        {lesson.description && (
          <p className="text-slate-500 mt-1">{lesson.description}</p>
        )}
      </div>

      {lesson.learningObjective && (
        <Section title="Learning Objective" tone="brand">
          <MathContent text={lesson.learningObjective} />
        </Section>
      )}

      {lesson.introduction && (
        <Section title="Introduction">
          <MathContent text={lesson.introduction} />
        </Section>
      )}

      {lesson.definitions && (
        <Section title="Definitions">
          <MathContent text={lesson.definitions} />
        </Section>
      )}

      {lesson.mainExplanation && (
        <Section title="Explanation">
          <MathContent text={lesson.mainExplanation} />
        </Section>
      )}

      {lesson.formulae && (
        <Section title="Formulae" tone="amber">
          <MathContent text={lesson.formulae} />
        </Section>
      )}

      {lesson.images.length > 0 && (
        <Section title="Diagrams & Graphs">
          <div className="grid sm:grid-cols-2 gap-3">
            {lesson.images.map((img) => (
              // eslint-disable-next-line @next/next/no-img-element
              <figure key={img.id}>
                <img
                  src={img.url}
                  alt={img.caption ?? img.kind ?? "Lesson image"}
                  className="rounded-md border border-slate-200 w-full"
                />
                {img.caption && (
                  <figcaption className="text-xs text-slate-500 mt-1">
                    {img.caption}
                  </figcaption>
                )}
              </figure>
            ))}
          </div>
        </Section>
      )}

      {lesson.examples && (
        <Section title="Worked Examples">
          <MathContent text={lesson.examples} />
        </Section>
      )}

      {lesson.realLifeApplications && (
        <Section title="Real-Life Applications">
          <MathContent text={lesson.realLifeApplications} />
        </Section>
      )}

      {lesson.videos.length > 0 && (
        <Section title="Videos">
          <div className="space-y-4">
            {lesson.videos.map((v) => {
              const embed = v.source === "YOUTUBE" ? youtubeEmbedUrl(v.url) : null;
              return (
                <div key={v.id}>
                  <p className="text-sm font-medium text-slate-700 mb-1">
                    {v.title}
                  </p>
                  {embed ? (
                    <div className="aspect-video">
                      <iframe
                        src={embed}
                        className="w-full h-full rounded-md"
                        allowFullScreen
                        title={v.title}
                      />
                    </div>
                  ) : (
                    <a
                      href={v.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-brand-700 hover:underline"
                    >
                      Open video ↗
                    </a>
                  )}
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {lesson.geogebraActivities.length > 0 && (
        <Section title="GeoGebra">
          <div className="space-y-3">
            {lesson.geogebraActivities.map((g) => (
              <EmbedOrLink key={g.id} title={g.title} description={g.description} url={g.url} label="Open in GeoGebra" />
            ))}
          </div>
        </Section>
      )}

      {lesson.desmosActivities.length > 0 && (
        <Section title="Desmos">
          <div className="space-y-3">
            {lesson.desmosActivities.map((d) => (
              <EmbedOrLink key={d.id} title={d.title} description={d.description} url={d.url} label="Open in Desmos" />
            ))}
          </div>
        </Section>
      )}

      {lesson.materials.length > 0 && (
        <Section title="Downloads">
          <ul className="space-y-1.5">
            {lesson.materials.map((m) => (
              <li key={m.id}>
                <a
                  href={m.fileUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm text-brand-700 hover:underline"
                >
                  📎 {m.title} ({m.fileType})
                </a>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {lesson.externalResources.length > 0 && (
        <Section title="More Resources">
          <ul className="space-y-1.5">
            {lesson.externalResources.map((r) => (
              <li key={r.id}>
                <a
                  href={r.url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm text-brand-700 hover:underline"
                >
                  {r.title} ({r.provider.replace("_", " ")})
                </a>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {lesson.practiceQuestions && lesson.practiceQuestions.length > 0 && (
        <Section title="Practice Questions">
          <p className="text-xs text-slate-500 mb-2">
            {lesson.practiceQuestions.length} question
            {lesson.practiceQuestions.length === 1 ? "" : "s"} for this
            lesson — interactive practice with grading arrives in Phase 5.
          </p>
          <ol className="space-y-2 list-decimal list-inside">
            {lesson.practiceQuestions.map((q) => (
              <li key={q.id} className="text-sm text-slate-700">
                <MathContent text={q.questionText} />
              </li>
            ))}
          </ol>
        </Section>
      )}

      {lesson.notes && (
        <Section title="Notes">
          <MathContent text={lesson.notes} />
        </Section>
      )}
    </article>
  );
}

function Section({
  title,
  tone = "default",
  children,
}: {
  title: string;
  tone?: "default" | "brand" | "amber";
  children: React.ReactNode;
}) {
  const toneClass =
    tone === "brand"
      ? "border-brand-200 bg-brand-50"
      : tone === "amber"
      ? "border-amber-200 bg-amber-50"
      : "border-slate-200 bg-white";
  return (
    <section className={`rounded-lg border p-4 ${toneClass}`}>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">
        {title}
      </p>
      <div className="text-sm text-slate-700">{children}</div>
    </section>
  );
}

function EmbedOrLink({
  title,
  description,
  url,
  label,
}: {
  title: string;
  description: string | null;
  url: string;
  label: string;
}) {
  const looksEmbeddable = url.includes("geogebra.org") || url.includes("desmos.com");
  return (
    <div>
      <p className="text-sm font-medium text-slate-700">{title}</p>
      {description && <p className="text-xs text-slate-500 mb-2">{description}</p>}
      {looksEmbeddable ? (
        <iframe src={url} className="w-full h-96 rounded-md border border-slate-200" title={title} />
      ) : (
        <a
          href={url}
          target="_blank"
          rel="noreferrer"
          className="inline-block text-xs font-medium rounded-md border border-brand-300 text-brand-700 px-3 py-1.5 hover:bg-brand-50 transition"
        >
          {label} ↗
        </a>
      )}
    </div>
  );
}
