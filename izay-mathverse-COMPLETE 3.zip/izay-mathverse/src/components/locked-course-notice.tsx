import Link from "next/link";
import type { Course } from "@prisma/client";

export function LockedCourseNotice({ course }: { course: Course }) {
  return (
    <div className="max-w-md mx-auto text-center py-16">
      <p className="text-5xl mb-4">🔒</p>
      <h1 className="text-xl font-bold text-slate-800 uppercase tracking-wide">
        {course.name}
      </h1>
      <p className="mt-4 text-slate-600">
        This course is not available at the moment.
      </p>
      <p className="mt-2 text-slate-500 text-sm">
        {course.lockedMessage ??
          `The ${course.name} curriculum and learning materials are currently being prepared. Please check back later.`}
      </p>
      <Link
        href="/student"
        className="mt-8 inline-block rounded-lg bg-brand-600 px-5 py-2.5 text-white font-medium hover:bg-brand-700 transition"
      >
        Go back
      </Link>
    </div>
  );
}
