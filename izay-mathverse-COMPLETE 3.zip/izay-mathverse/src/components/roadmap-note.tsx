export function RoadmapNote({ items }: { items: string[] }) {
  return (
    <div className="rounded-lg border border-dashed border-slate-300 bg-white p-4">
      <p className="text-sm font-semibold text-slate-700">
        Coming in later build phases
      </p>
      <p className="text-xs text-slate-500 mt-0.5">
        These aren&apos;t built yet, so there&apos;s nothing to click on here
        yet — they&apos;ll appear as real, working features as each phase
        ships.
      </p>
      <ul className="mt-3 space-y-1 text-sm text-slate-600 list-disc list-inside">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}
