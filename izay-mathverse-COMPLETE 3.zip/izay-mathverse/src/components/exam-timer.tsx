"use client";

import { useEffect, useState } from "react";

/**
 * Countdown timer (spec §36). Auto-submits the given form when time
 * expires. Purely a client-side UX layer — the actual time window isn't
 * separately enforced server-side in this phase (a determined student
 * could in principle keep the tab open past expiry), which is a known gap
 * flagged in docs/PHASE_LOG.md rather than silently assumed solid.
 */
export function ExamTimer({
  startedAt,
  durationMinutes,
  formId,
}: {
  startedAt: string; // ISO string
  durationMinutes: number;
  formId: string;
}) {
  const deadline = new Date(startedAt).getTime() + durationMinutes * 60_000;
  const [remaining, setRemaining] = useState(() => Math.max(0, deadline - Date.now()));

  useEffect(() => {
    const interval = setInterval(() => {
      const left = Math.max(0, deadline - Date.now());
      setRemaining(left);
      if (left <= 0) {
        clearInterval(interval);
        const form = document.getElementById(formId) as HTMLFormElement | null;
        form?.requestSubmit();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [deadline, formId]);

  const minutes = Math.floor(remaining / 60_000);
  const seconds = Math.floor((remaining % 60_000) / 1000);
  const isLow = remaining < 60_000;

  return (
    <div
      className={`text-sm font-mono font-semibold px-3 py-1.5 rounded-md ${
        isLow ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-700"
      }`}
    >
      ⏱ {minutes}:{seconds.toString().padStart(2, "0")}
    </div>
  );
}
