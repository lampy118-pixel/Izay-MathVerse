"use client";

import { useEffect, useRef } from "react";
import katex from "katex";

/**
 * Renders text containing LaTeX math delimited by $...$ (inline) or
 * $$...$$ (display), plus KaTeX for everything else — spec §52.
 *
 * Usage in lesson content: teachers write formulae as e.g.
 *   "The quadratic formula is $$x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}$$"
 * and this component renders it properly instead of raw text.
 */
export function MathContent({
  text,
  className,
}: {
  text: string | null | undefined;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || !text) return;

    const container = ref.current;
    container.innerHTML = "";

    // Split on $$...$$ (display) and $...$ (inline) segments.
    const parts = text.split(/(\$\$[^$]+\$\$|\$[^$]+\$)/g);

    for (const part of parts) {
      if (!part) continue;

      if (part.startsWith("$$") && part.endsWith("$$")) {
        const span = document.createElement("div");
        try {
          katex.render(part.slice(2, -2), span, {
            throwOnError: false,
            displayMode: true,
          });
        } catch {
          span.textContent = part;
        }
        container.appendChild(span);
      } else if (part.startsWith("$") && part.endsWith("$")) {
        const span = document.createElement("span");
        try {
          katex.render(part.slice(1, -1), span, {
            throwOnError: false,
            displayMode: false,
          });
        } catch {
          span.textContent = part;
        }
        container.appendChild(span);
      } else {
        const span = document.createElement("span");
        span.style.whiteSpace = "pre-line";
        span.textContent = part;
        container.appendChild(span);
      }
    }
  }, [text]);

  if (!text) return null;

  return <div ref={ref} className={className} />;
}
