import { z } from "zod";

/**
 * Validation for user creation (spec §50: input validation). This is the
 * first schema-validated action in the codebase — a pattern to extend to
 * other user-supplied inputs (organization creation, class creation, etc.)
 * before production use. See docs/SECURITY.md for the current coverage
 * and what's still relying on ad-hoc `String(formData.get(...))` checks.
 */
export const createUserSchema = z.object({
  firstName: z.string().trim().min(1, "First name is required").max(100),
  lastName: z.string().trim().min(1, "Last name is required").max(100),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
  role: z.enum(["SUPER_ADMIN", "ADMIN", "TEACHER", "STUDENT"]),
  organizationId: z.string().nullable(),
});
