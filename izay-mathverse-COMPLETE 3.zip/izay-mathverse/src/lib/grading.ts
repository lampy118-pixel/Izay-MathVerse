import type { Question, QuestionOption } from "@prisma/client";

export interface GradeResult {
  isCorrect: boolean | null; // null = requires manual marking (spec §31)
  marksAwarded: number | null;
}

function normalize(s: string): string {
  return s.trim().toLowerCase().replace(/\s+/g, "");
}

function parseNumeric(s: string): number | null {
  const n = Number(s.trim().replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

/**
 * Grades a single answer against a Question (spec §28, §31).
 *
 * - Multiple Choice / True-False: compares the submitted option id.
 * - Numerical: numeric comparison with a small floating-point tolerance,
 *   against correctAnswer and any acceptedAnswers entries.
 * - Short Answer / Algebraic Expression: normalized string match against
 *   correctAnswer and any acceptedAnswers entries. This is list-based
 *   equivalence, not a symbolic algebra engine — see docs/PHASE_LOG.md for
 *   why that distinction matters and what "equivalent" really means here.
 * - Structured / Diagram-Image: not auto-gradable — returns isCorrect:
 *   null so the UI can show "pending manual review" rather than a fake
 *   right/wrong (spec §31: "Allow manual marking for complex structured
 *   questions").
 */
export function gradeAnswer(
  question: Question & { options?: QuestionOption[] },
  studentAnswer: string
): GradeResult {
  switch (question.type) {
    case "MULTIPLE_CHOICE":
    case "TRUE_FALSE": {
      const options = question.options ?? [];
      const chosen = options.find((o) => o.id === studentAnswer);
      const isCorrect = !!chosen?.isCorrect;
      return { isCorrect, marksAwarded: isCorrect ? question.marks : 0 };
    }

    case "NUMERICAL": {
      const given = parseNumeric(studentAnswer);
      if (given === null) return { isCorrect: false, marksAwarded: 0 };

      const candidates = [
        question.correctAnswer,
        ...(question.acceptedAnswers?.split("\n") ?? []),
      ]
        .map(parseNumeric)
        .filter((n): n is number => n !== null);

      const isCorrect = candidates.some((c) => Math.abs(c - given) < 1e-6);
      return { isCorrect, marksAwarded: isCorrect ? question.marks : 0 };
    }

    case "SHORT_ANSWER":
    case "ALGEBRAIC_EXPRESSION": {
      const given = normalize(studentAnswer);
      const candidates = [
        question.correctAnswer,
        ...(question.acceptedAnswers?.split("\n") ?? []),
      ]
        .filter(Boolean)
        .map(normalize);

      const isCorrect = candidates.includes(given);
      return { isCorrect, marksAwarded: isCorrect ? question.marks : 0 };
    }

    case "STRUCTURED":
    case "DIAGRAM_IMAGE":
    default:
      return { isCorrect: null, marksAwarded: null };
  }
}
