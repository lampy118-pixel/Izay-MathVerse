"use server";

import { prisma } from "@/lib/prisma";
import { requireRole, assertOwnRecord } from "@/lib/rbac";
import { gradeAnswer } from "@/lib/grading";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { PracticeMode } from "@prisma/client";

const SESSION_LENGTH = 10; // questions per session

/**
 * Starts a new practice session (spec §27) scoped to a course and,
 * optionally, a topic and difficulty. Students only ever act on their own
 * sessions — enforced below and in every other action here (spec §50).
 */
export async function startPracticeSession(formData: FormData) {
  const user = await requireRole(["STUDENT"]);

  const courseId = String(formData.get("courseId") ?? "");
  const topicId = String(formData.get("topicId") ?? "") || null;
  const mode = String(formData.get("mode") ?? "QUICK_PRACTICE") as PracticeMode;

  if (!courseId) throw new Error("Select a course to practice.");

  const session = await prisma.practiceSession.create({
    data: {
      studentId: user.id,
      mode,
      courseId,
      topicId,
    },
  });

  redirect(`/student/practice/session/${session.id}`);
}

/**
 * Submits an answer to the current question in a session: grades it
 * (spec §31), records the PracticeAttempt, and updates the student's
 * TopicProgress for that topic (spec §39) — all from real attempt data,
 * never synthesized (spec §40: "Do not invent performance statistics").
 */
export async function submitPracticeAnswer(
  sessionId: string,
  questionId: string,
  formData: FormData
) {
  const user = await requireRole(["STUDENT"]);

  const session = await prisma.practiceSession.findUniqueOrThrow({
    where: { id: sessionId },
  });
  assertOwnRecord(user.id, session.studentId);

  const question = await prisma.question.findUniqueOrThrow({
    where: { id: questionId },
    include: { options: true },
  });

  const studentAnswer = String(formData.get("answer") ?? "");
  const { isCorrect, marksAwarded } = gradeAnswer(question, studentAnswer);

  await prisma.practiceAttempt.create({
    data: {
      practiceSessionId: sessionId,
      questionId,
      studentAnswer,
      isCorrect,
      marksAwarded,
    },
  });

  // Update topic-level progress from this real attempt only.
  if (question.topicId) {
    const existing = await prisma.topicProgress.findUnique({
      where: { studentId_topicId: { studentId: user.id, topicId: question.topicId } },
    });

    const questionsAttempted = (existing?.questionsAttempted ?? 0) + 1;
    const correctAnswers =
      (existing?.correctAnswers ?? 0) + (isCorrect ? 1 : 0);
    const performancePercent =
      questionsAttempted > 0 ? (correctAnswers / questionsAttempted) * 100 : 0;

    await prisma.topicProgress.upsert({
      where: { studentId_topicId: { studentId: user.id, topicId: question.topicId } },
      update: { questionsAttempted, correctAnswers, performancePercent },
      create: {
        studentId: user.id,
        topicId: question.topicId,
        questionsAttempted,
        correctAnswers,
        performancePercent,
      },
    });
  }

  revalidatePath(`/student/practice/session/${sessionId}`);
  revalidatePath("/student/progress");
}

export async function endPracticeSession(sessionId: string) {
  const user = await requireRole(["STUDENT"]);

  const session = await prisma.practiceSession.findUniqueOrThrow({
    where: { id: sessionId },
  });
  assertOwnRecord(user.id, session.studentId);

  await prisma.practiceSession.update({
    where: { id: sessionId },
    data: { endedAt: new Date() },
  });

  revalidatePath(`/student/practice/session/${sessionId}`);
}

/** Picks the next unattempted question in a session's pool. */
export async function getNextQuestion(sessionId: string) {
  const session = await prisma.practiceSession.findUniqueOrThrow({
    where: { id: sessionId },
    include: { attempts: true },
  });

  if (!session.courseId) return null;

  const attemptedIds = session.attempts.map((a) => a.questionId);

  if (session.attempts.length >= SESSION_LENGTH) return null;

  return prisma.question.findFirst({
    where: {
      status: "ACTIVE",
      courseId: session.courseId,
      topicId: session.topicId ?? undefined,
      id: { notIn: attemptedIds },
    },
    include: { options: { orderBy: { sortOrder: "asc" } }, hints: { orderBy: { order: "asc" } } },
    orderBy: { id: "asc" },
  });
}
