"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { QuestionStatus, QuestionType, DifficultyLevel } from "@prisma/client";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

/**
 * Creates a new question (spec §25). Starts as DRAFT — a teacher fills in
 * options/hints/solution/correct answer on the editor screen next, since
 * those vary by question type.
 */
export async function createQuestion(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const courseId = String(formData.get("courseId") ?? "");
  const topicId = String(formData.get("topicId") ?? "") || null;
  const questionText = String(formData.get("questionText") ?? "").trim();
  const type = String(formData.get("type") ?? "MULTIPLE_CHOICE") as QuestionType;
  const difficulty = String(formData.get("difficulty") ?? "MEDIUM") as DifficultyLevel;
  const marks = Number(formData.get("marks") ?? 1);

  if (!courseId || !questionText) {
    throw new Error("A course and question text are required.");
  }

  const question = await prisma.question.create({
    data: {
      courseId,
      topicId,
      authorId: user.id,
      questionText,
      type,
      difficulty,
      marks: Number.isFinite(marks) && marks > 0 ? marks : 1,
      correctAnswer: "",
      status: "DRAFT",
    },
  });

  await recordAudit({
    userId: user.id,
    action: "CREATE",
    entityType: "Question",
    entityId: question.id,
  });

  redirect(`/questions/${question.id}/edit`);
}

export async function updateQuestion(questionId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const before = await prisma.question.findUniqueOrThrow({ where: { id: questionId } });

  const updated = await prisma.question.update({
    where: { id: questionId },
    data: {
      questionText: String(formData.get("questionText") ?? "").trim(),
      imageUrl: String(formData.get("imageUrl") ?? "") || null,
      difficulty: String(formData.get("difficulty") ?? "MEDIUM") as DifficultyLevel,
      marks: Number(formData.get("marks") ?? 1) || 1,
      correctAnswer: String(formData.get("correctAnswer") ?? "").trim(),
      acceptedAnswers: String(formData.get("acceptedAnswers") ?? "") || null,
      explanation: String(formData.get("explanation") ?? "") || null,
    },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Question",
    entityId: questionId,
    before: { questionText: before.questionText },
    after: { questionText: updated.questionText },
  });

  revalidatePath(`/questions/${questionId}/edit`);
}

/** Archive / Restore / (soft) status changes — spec §25. */
export async function setQuestionStatus(questionId: string, status: QuestionStatus) {
  const user = await requireRole([...STAFF_ROLES]);

  const before = await prisma.question.findUniqueOrThrow({ where: { id: questionId } });
  const updated = await prisma.question.update({
    where: { id: questionId },
    data: { status },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Question",
    entityId: questionId,
    before: { status: before.status },
    after: { status: updated.status },
  });

  revalidatePath(`/questions`);
  revalidatePath(`/questions/${questionId}/edit`);
}

/**
 * Duplicate (spec §25) — copies the question, its options, and its hints
 * into a fresh DRAFT question so a teacher can create a variant quickly.
 * Solutions are intentionally not duplicated automatically, to avoid two
 * "live" solutions drifting out of sync unnoticed — the teacher re-adds one.
 */
export async function duplicateQuestion(questionId: string) {
  const user = await requireRole([...STAFF_ROLES]);

  const original = await prisma.question.findUniqueOrThrow({
    where: { id: questionId },
    include: { options: true, hints: true },
  });

  const copy = await prisma.question.create({
    data: {
      courseId: original.courseId,
      topicId: original.topicId,
      learningIndicatorId: original.learningIndicatorId,
      authorId: user.id,
      questionText: `${original.questionText} (copy)`,
      imageUrl: original.imageUrl,
      type: original.type,
      difficulty: original.difficulty,
      marks: original.marks,
      correctAnswer: original.correctAnswer,
      acceptedAnswers: original.acceptedAnswers,
      explanation: original.explanation,
      status: "DRAFT",
      options: {
        create: original.options.map((o) => ({
          text: o.text,
          isCorrect: o.isCorrect,
          sortOrder: o.sortOrder,
        })),
      },
      hints: {
        create: original.hints.map((h) => ({ order: h.order, text: h.text })),
      },
    },
  });

  await recordAudit({
    userId: user.id,
    action: "CREATE",
    entityType: "Question",
    entityId: copy.id,
    before: { duplicatedFrom: questionId },
  });

  redirect(`/questions/${copy.id}/edit`);
}

export async function deleteQuestion(questionId: string) {
  const user = await requireRole([...STAFF_ROLES]);

  await prisma.question.delete({ where: { id: questionId } });

  await recordAudit({
    userId: user.id,
    action: "DELETE",
    entityType: "Question",
    entityId: questionId,
  });

  revalidatePath("/questions");
  redirect("/questions");
}

// --- Options (Multiple Choice / True-False) ---

export async function addQuestionOption(questionId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const text = String(formData.get("text") ?? "").trim();
  const isCorrect = formData.get("isCorrect") === "on";
  if (!text) throw new Error("Option text is required.");

  const count = await prisma.questionOption.count({ where: { questionId } });
  await prisma.questionOption.create({
    data: { questionId, text, isCorrect, sortOrder: count },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "QuestionOption" });
  revalidatePath(`/questions/${questionId}/edit`);
}

export async function deleteQuestionOption(questionId: string, optionId: string) {
  const user = await requireRole([...STAFF_ROLES]);
  await prisma.questionOption.delete({ where: { id: optionId } });
  await recordAudit({ userId: user.id, action: "DELETE", entityType: "QuestionOption" });
  revalidatePath(`/questions/${questionId}/edit`);
}

// --- Hints (spec §29 — multiple, ordered) ---

export async function addHint(questionId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const text = String(formData.get("text") ?? "").trim();
  if (!text) throw new Error("Hint text is required.");

  const count = await prisma.hint.count({ where: { questionId } });
  await prisma.hint.create({
    data: { questionId, order: count + 1, text },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Hint" });
  revalidatePath(`/questions/${questionId}/edit`);
}

export async function deleteHint(questionId: string, hintId: string) {
  const user = await requireRole([...STAFF_ROLES]);
  await prisma.hint.delete({ where: { id: hintId } });
  await recordAudit({ userId: user.id, action: "DELETE", entityType: "Hint" });
  revalidatePath(`/questions/${questionId}/edit`);
}

// --- Solutions (spec §30 — teacher controls exam-time availability) ---

export async function setSolution(questionId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const text = String(formData.get("text") ?? "").trim();
  const isAvailableDuringExam = formData.get("isAvailableDuringExam") === "on";
  if (!text) throw new Error("Solution text is required.");

  const existing = await prisma.solution.findFirst({ where: { questionId } });
  if (existing) {
    await prisma.solution.update({
      where: { id: existing.id },
      data: { text, isAvailableDuringExam },
    });
  } else {
    await prisma.solution.create({
      data: { questionId, text, isAvailableDuringExam },
    });
  }

  await recordAudit({ userId: user.id, action: "UPDATE", entityType: "Solution" });
  revalidatePath(`/questions/${questionId}/edit`);
}

// --- Attach an existing question to a lesson's practice section ---

export async function attachQuestionToLesson(lessonId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const questionId = String(formData.get("questionId") ?? "");
  if (!questionId) throw new Error("Select a question to attach.");

  await prisma.lesson.update({
    where: { id: lessonId },
    data: { practiceQuestions: { connect: { id: questionId } } },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Lesson",
    entityId: lessonId,
    after: { attachedQuestionId: questionId },
  });

  revalidatePath(`/lessons/${lessonId}/edit`);
}

export async function detachQuestionFromLesson(lessonId: string, questionId: string) {
  const user = await requireRole([...STAFF_ROLES]);

  await prisma.lesson.update({
    where: { id: lessonId },
    data: { practiceQuestions: { disconnect: { id: questionId } } },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Lesson",
    entityId: lessonId,
    before: { detachedQuestionId: questionId },
  });

  revalidatePath(`/lessons/${lessonId}/edit`);
}
