"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN"] as const;

export async function createClass(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const organizationId = String(formData.get("organizationId") ?? "");
  const academicYearId = String(formData.get("academicYearId") ?? "");
  const name = String(formData.get("name") ?? "").trim();
  const courseId = String(formData.get("courseId") ?? "") || null;
  const academicLevelId = String(formData.get("academicLevelId") ?? "") || null;

  if (!organizationId || !academicYearId || !name) {
    throw new Error("Organization, academic year, and class name are required.");
  }

  const cls = await prisma.class.create({
    data: { organizationId, academicYearId, name, courseId, academicLevelId },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Class", entityId: cls.id });
  redirect(`/admin/classes/${cls.id}`);
}

export async function assignTeacherToClass(classId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const teacherId = String(formData.get("teacherId") ?? "");
  if (!teacherId) throw new Error("Select a teacher.");

  await prisma.classTeacher.upsert({
    where: { classId_teacherId: { classId, teacherId } },
    update: {},
    create: { classId, teacherId },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "ClassTeacher" });
  revalidatePath(`/admin/classes/${classId}`);
}

export async function enrollStudentInClass(classId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const studentId = String(formData.get("studentId") ?? "");
  if (!studentId) throw new Error("Select a student.");

  await prisma.classStudent.upsert({
    where: { classId_studentId: { classId, studentId } },
    update: {},
    create: { classId, studentId },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "ClassStudent" });
  revalidatePath(`/admin/classes/${classId}`);
}

export async function removeStudentFromClass(classId: string, classStudentId: string) {
  const user = await requireRole([...STAFF_ROLES]);
  await prisma.classStudent.delete({ where: { id: classStudentId } });
  await recordAudit({ userId: user.id, action: "DELETE", entityType: "ClassStudent" });
  revalidatePath(`/admin/classes/${classId}`);
}
