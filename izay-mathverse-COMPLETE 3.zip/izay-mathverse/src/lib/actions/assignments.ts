"use server";

import { prisma } from "@/lib/prisma";
import { requireRole, assertOwnRecord } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { findGradeForPercentage } from "@/lib/grade-lookup";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

export async function createAssignment(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const courseId = String(formData.get("courseId") ?? "");
  const title = String(formData.get("title") ?? "").trim();
  const instructions = String(formData.get("instructions") ?? "").trim();
  const totalMarks = Number(formData.get("totalMarks") ?? 10) || 10;
  const dueDateRaw = String(formData.get("dueDate") ?? "");

  if (!courseId || !title || !instructions || !dueDateRaw) {
    throw new Error("Course, title, instructions, and due date are required.");
  }

  const assignment = await prisma.assignment.create({
    data: {
      courseId,
      title,
      instructions,
      totalMarks,
      dueDate: new Date(dueDateRaw),
      authorId: user.id,
    },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Assignment", entityId: assignment.id });
  redirect(`/assignments/${assignment.id}/edit`);
}

export async function addAssignmentAttachment(assignmentId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const fileUrl = String(formData.get("fileUrl") ?? "").trim();
  const fileName = String(formData.get("fileName") ?? "").trim();
  if (!fileUrl || !fileName) throw new Error("A file name and URL are required.");

  await prisma.assignmentAttachment.create({
    data: { assignmentId, fileUrl, fileName },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "AssignmentAttachment" });
  revalidatePath(`/assignments/${assignmentId}/edit`);
}

/**
 * Student submission (spec §37). Automatically flagged LATE if submitted
 * after the due date — computed from the real clock, never asserted by
 * the client.
 */
export async function submitAssignment(assignmentId: string, formData: FormData) {
  const user = await requireRole(["STUDENT"]);

  const assignment = await prisma.assignment.findUniqueOrThrow({ where: { id: assignmentId } });
  const answerText = String(formData.get("answerText") ?? "").trim() || null;
  const fileUrl = String(formData.get("fileUrl") ?? "").trim() || null;

  if (!answerText && !fileUrl) {
    throw new Error("Provide an answer or a file link before submitting.");
  }

  const isLate = new Date() > assignment.dueDate;

  const existing = await prisma.submission.findFirst({
    where: { assignmentId, studentId: user.id },
  });

  if (existing) {
    await prisma.submission.update({
      where: { id: existing.id },
      data: {
        answerText,
        fileUrl,
        submittedAt: new Date(),
        status: isLate ? "LATE" : "SUBMITTED",
      },
    });
  } else {
    await prisma.submission.create({
      data: {
        assignmentId,
        studentId: user.id,
        answerText,
        fileUrl,
        status: isLate ? "LATE" : "SUBMITTED",
      },
    });
  }

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Submission", entityId: assignmentId });
  revalidatePath(`/student/assignments/${assignmentId}`);
}

/**
 * Marks a submission (spec §37) and writes a Result record (spec §38),
 * including a looked-up Grade boundary. This is the manual-marking path
 * for Structured/Diagram-Image-style work that automatic grading (Phase 5)
 * can't handle.
 */
export async function markSubmission(submissionId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const submission = await prisma.submission.findUniqueOrThrow({
    where: { id: submissionId },
    include: { assignment: true },
  });

  const marksAwarded = Number(formData.get("marksAwarded") ?? 0);
  const feedback = String(formData.get("feedback") ?? "") || null;

  if (!Number.isFinite(marksAwarded) || marksAwarded < 0) {
    throw new Error("Enter a valid, non-negative mark.");
  }

  await prisma.submission.update({
    where: { id: submissionId },
    data: { marksAwarded, feedback, status: "MARKED" },
  });

  const percentage = (marksAwarded / submission.assignment.totalMarks) * 100;
  const grade = await findGradeForPercentage(percentage);

  await prisma.result.create({
    data: {
      studentId: submission.studentId,
      assessmentType: "ASSIGNMENT",
      assessmentRefId: submission.assignmentId,
      title: submission.assignment.title,
      score: marksAwarded,
      maxScore: submission.assignment.totalMarks,
      percentage,
      gradeId: grade?.id,
      teacherRemark: feedback,
    },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Submission",
    entityId: submissionId,
    after: { marksAwarded, status: "MARKED" },
  });

  revalidatePath(`/assignments/${submission.assignmentId}/edit`);
}

export async function returnSubmission(submissionId: string) {
  const user = await requireRole([...STAFF_ROLES]);

  const submission = await prisma.submission.findUniqueOrThrow({ where: { id: submissionId } });
  await prisma.submission.update({ where: { id: submissionId }, data: { status: "RETURNED" } });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Submission",
    entityId: submissionId,
    after: { status: "RETURNED" },
  });

  revalidatePath(`/assignments/${submission.assignmentId}/edit`);
}
