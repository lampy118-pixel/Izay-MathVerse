"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN"] as const;

export async function createAchievement(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const name = String(formData.get("name") ?? "").trim();
  const description = String(formData.get("description") ?? "") || null;
  if (!name) throw new Error("An achievement name is required.");

  await prisma.achievement.create({ data: { name, description } });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Achievement" });
  revalidatePath("/admin/achievements");
}

export async function toggleAchievement(achievementId: string) {
  const user = await requireRole([...STAFF_ROLES]);
  const a = await prisma.achievement.findUniqueOrThrow({ where: { id: achievementId } });
  await prisma.achievement.update({ where: { id: achievementId }, data: { isEnabled: !a.isEnabled } });
  await recordAudit({ userId: user.id, action: "UPDATE", entityType: "Achievement", entityId: achievementId });
  revalidatePath("/admin/achievements");
}

/**
 * Manually awards an achievement to a student. There is no automatic
 * detection logic yet (e.g. "100 Questions Completed" is not computed and
 * auto-awarded) — see docs/PHASE_LOG.md. Manual award is the only
 * mechanism in this phase, and is honestly presented as such rather than
 * implying achievements unlock themselves.
 */
export async function awardAchievement(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const studentId = String(formData.get("studentId") ?? "");
  const achievementId = String(formData.get("achievementId") ?? "");
  if (!studentId || !achievementId) throw new Error("Select a student and an achievement.");

  await prisma.userAchievement.upsert({
    where: { userId_achievementId: { userId: studentId, achievementId } },
    update: {},
    create: { userId: studentId, achievementId },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "UserAchievement" });
  revalidatePath("/admin/achievements");
}
