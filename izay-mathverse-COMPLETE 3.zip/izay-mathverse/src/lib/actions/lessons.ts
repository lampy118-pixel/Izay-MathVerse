"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { LessonStatus } from "@prisma/client";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

/**
 * Creates a new lesson directly under a curriculum Topic (spec §15) with no
 * source-code changes required. New lessons start as DRAFT and are appended
 * to the end of the topic's lesson order.
 */
export async function createLesson(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const topicId = String(formData.get("topicId") ?? "");
  const title = String(formData.get("title") ?? "").trim();

  if (!topicId || !title) {
    throw new Error("A topic and a lesson title are required.");
  }

  const lastLesson = await prisma.lesson.findFirst({
    where: { topicId },
    orderBy: { sortOrder: "desc" },
  });

  const lesson = await prisma.lesson.create({
    data: {
      topicId,
      authorId: user.id,
      title,
      status: "DRAFT",
      sortOrder: (lastLesson?.sortOrder ?? -1) + 1,
    },
  });

  await recordAudit({
    userId: user.id,
    action: "CREATE",
    entityType: "Lesson",
    entityId: lesson.id,
    after: { title: lesson.title },
  });

  redirect(`/lessons/${lesson.id}/edit`);
}

/**
 * Full lesson-editor save (spec §16 field list, minus the parts that
 * depend on later phases — practice questions attach once the Question
 * Bank exists in Phase 4).
 */
export async function updateLessonContent(lessonId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const before = await prisma.lesson.findUniqueOrThrow({ where: { id: lessonId } });

  const learningIndicatorId =
    String(formData.get("learningIndicatorId") ?? "") || null;

  const updated = await prisma.lesson.update({
    where: { id: lessonId },
    data: {
      title: String(formData.get("title") ?? "").trim(),
      description: String(formData.get("description") ?? "") || null,
      learningIndicatorId,
      learningObjective: String(formData.get("learningObjective") ?? "") || null,
      introduction: String(formData.get("introduction") ?? "") || null,
      definitions: String(formData.get("definitions") ?? "") || null,
      mainExplanation: String(formData.get("mainExplanation") ?? "") || null,
      examples: String(formData.get("examples") ?? "") || null,
      realLifeApplications: String(formData.get("realLifeApplications") ?? "") || null,
      formulae: String(formData.get("formulae") ?? "") || null,
      notes: String(formData.get("notes") ?? "") || null,
    },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Lesson",
    entityId: lessonId,
    before: { title: before.title },
    after: { title: updated.title },
  });

  revalidatePath(`/lessons/${lessonId}/edit`);
}

/**
 * Lesson status transitions (spec §16 buttons: Save Draft / Preview /
 * Publish / Archive; spec §19 statuses). Preview has no server action — it
 * just opens the same content the student viewer renders, gated by role
 * rather than status, so a teacher can always preview a Draft.
 */
export async function setLessonStatus(lessonId: string, status: LessonStatus) {
  const user = await requireRole([...STAFF_ROLES]);

  const before = await prisma.lesson.findUniqueOrThrow({ where: { id: lessonId } });

  const updated = await prisma.lesson.update({
    where: { id: lessonId },
    data: {
      status,
      publishedAt: status === "PUBLISHED" && !before.publishedAt ? new Date() : before.publishedAt,
    },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Lesson",
    entityId: lessonId,
    before: { status: before.status },
    after: { status: updated.status },
  });

  revalidatePath(`/lessons/${lessonId}/edit`);
}

/**
 * Lesson reordering within its topic (spec §18). Implemented as an
 * up/down swap of `sortOrder` with the adjacent lesson — a fully working,
 * database-backed reorder. Drag-and-drop is a pure frontend interaction
 * layer that can be added on top of this same swap logic later without
 * changing how order is stored.
 */
export async function moveLesson(lessonId: string, direction: "up" | "down") {
  const user = await requireRole([...STAFF_ROLES]);

  const lesson = await prisma.lesson.findUniqueOrThrow({ where: { id: lessonId } });

  const neighbor = await prisma.lesson.findFirst({
    where: {
      topicId: lesson.topicId,
      sortOrder: direction === "up" ? { lt: lesson.sortOrder } : { gt: lesson.sortOrder },
    },
    orderBy: { sortOrder: direction === "up" ? "desc" : "asc" },
  });

  if (!neighbor) return; // already at the boundary

  await prisma.$transaction([
    prisma.lesson.update({
      where: { id: lesson.id },
      data: { sortOrder: neighbor.sortOrder },
    }),
    prisma.lesson.update({
      where: { id: neighbor.id },
      data: { sortOrder: lesson.sortOrder },
    }),
  ]);

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Lesson",
    entityId: lesson.id,
    before: { sortOrder: lesson.sortOrder },
    after: { sortOrder: neighbor.sortOrder },
  });

  revalidatePath(`/curriculum`);
}

// --- Attached content: images, videos, GeoGebra/Desmos, materials, resources ---
// (spec §20-24)

export async function addLessonImage(lessonId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const url = String(formData.get("url") ?? "").trim();
  const kind = String(formData.get("kind") ?? "image");
  const caption = String(formData.get("caption") ?? "") || null;
  if (!url) throw new Error("An image URL is required.");

  await prisma.lessonImage.create({
    data: { lessonId, url, kind, caption, sortOrder: 0 },
  });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "LessonImage" });
  revalidatePath(`/lessons/${lessonId}/edit`);
}

export async function addLessonVideo(lessonId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const title = String(formData.get("title") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const source = String(formData.get("source") ?? "YOUTUBE") as "YOUTUBE" | "UPLOADED";
  if (!title || !url) throw new Error("A video title and URL are required.");

  await prisma.video.create({
    data: { lessonId, title, url, source },
  });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Video" });
  revalidatePath(`/lessons/${lessonId}/edit`);
}

export async function addLessonMaterial(lessonId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const title = String(formData.get("title") ?? "").trim();
  const fileUrl = String(formData.get("fileUrl") ?? "").trim();
  const fileType = String(formData.get("fileType") ?? "OTHER") as
    | "PDF" | "PPT" | "PPTX" | "DOC" | "DOCX" | "IMAGE" | "WORKSHEET" | "WORKED_SOLUTION" | "OTHER";
  if (!title || !fileUrl) throw new Error("A material title and file URL are required.");

  await prisma.lessonMaterial.create({
    data: { title, fileUrl, fileType, uploadedById: user.id, materialLessonId: lessonId },
  });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "LessonMaterial" });
  revalidatePath(`/lessons/${lessonId}/edit`);
}

export async function addGeogebraActivity(lessonId: string, topicId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const title = String(formData.get("title") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const description = String(formData.get("description") ?? "") || null;
  if (!title || !url) throw new Error("A GeoGebra title and URL are required.");

  await prisma.geogebraActivity.create({
    data: { title, url, description, lessonId, topicId },
  });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "GeogebraActivity" });
  revalidatePath(`/lessons/${lessonId}/edit`);
}

export async function addDesmosActivity(lessonId: string, topicId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const title = String(formData.get("title") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const description = String(formData.get("description") ?? "") || null;
  if (!title || !url) throw new Error("A Desmos title and URL are required.");

  await prisma.desmosActivity.create({
    data: { title, url, description, lessonId, topicId },
  });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "DesmosActivity" });
  revalidatePath(`/lessons/${lessonId}/edit`);
}

export async function addExternalResource(lessonId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const title = String(formData.get("title") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const provider = String(formData.get("provider") ?? "OTHER") as
    | "YOUTUBE" | "GEOGEBRA" | "DESMOS" | "GOOGLE_FORMS" | "KAHOOT" | "KHAN_ACADEMY" | "OTHER";
  const description = String(formData.get("description") ?? "") || null;
  if (!title || !url) throw new Error("A resource title and URL are required.");

  await prisma.externalResource.create({
    data: { title, url, provider, description, lessonId, status: "ACTIVE" },
  });
  await recordAudit({ userId: user.id, action: "CREATE", entityType: "ExternalResource" });
  revalidatePath(`/lessons/${lessonId}/edit`);
}
