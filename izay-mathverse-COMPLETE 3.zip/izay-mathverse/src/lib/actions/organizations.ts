"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/**
 * Creates a new Organization/School (spec §4: schools are configurable DB
 * records, never hard-coded). Admin/Super Admin only, backend-enforced.
 */
export async function createOrganization(formData: FormData) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN"]);

  const name = String(formData.get("name") ?? "").trim();
  const type = String(formData.get("type") ?? "SCHOOL") as "SCHOOL" | "INDEPENDENT";
  const address = String(formData.get("address") ?? "").trim() || null;
  const contactEmail = String(formData.get("contactEmail") ?? "").trim() || null;
  const contactPhone = String(formData.get("contactPhone") ?? "").trim() || null;
  const brandColor = String(formData.get("brandColor") ?? "").trim() || null;

  if (!name) {
    throw new Error("Organization name is required.");
  }

  let slug = slugify(name);
  const existing = await prisma.organization.findUnique({ where: { slug } });
  if (existing) {
    slug = `${slug}-${Date.now().toString(36)}`;
  }

  const org = await prisma.organization.create({
    data: { name, slug, type, address, contactEmail, contactPhone, brandColor },
  });

  await recordAudit({
    userId: user.id,
    action: "CREATE",
    entityType: "Organization",
    entityId: org.id,
    after: org,
  });

  revalidatePath("/admin/organizations");
  redirect("/admin/organizations");
}

export async function toggleOrganizationActive(organizationId: string) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN"]);

  const org = await prisma.organization.findUniqueOrThrow({
    where: { id: organizationId },
  });

  const updated = await prisma.organization.update({
    where: { id: organizationId },
    data: { isActive: !org.isActive },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Organization",
    entityId: org.id,
    before: { isActive: org.isActive },
    after: { isActive: updated.isActive },
  });

  revalidatePath("/admin/organizations");
}
