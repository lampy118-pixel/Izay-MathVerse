"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

export async function createTimetableEntry(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const classId = String(formData.get("classId") ?? "");
  const dateStr = String(formData.get("date") ?? "");
  const startTime = String(formData.get("startTime") ?? "").trim();
  const endTime = String(formData.get("endTime") ?? "").trim();
  const topicLabel = String(formData.get("topicLabel") ?? "").trim() || null;
  const venue = String(formData.get("venue") ?? "").trim() || null;

  if (!classId || !dateStr || !startTime || !endTime) {
    throw new Error("Class, date, and start/end time are required.");
  }

  const entry = await prisma.timetableEntry.create({
    data: {
      classId,
      date: new Date(dateStr),
      startTime,
      endTime,
      topicLabel,
      venue,
      teacherId: user.role === "TEACHER" ? user.id : null,
    },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "TimetableEntry", entityId: entry.id });
  revalidatePath("/timetable");
}

export async function deleteTimetableEntry(entryId: string) {
  const user = await requireRole([...STAFF_ROLES]);
  await prisma.timetableEntry.delete({ where: { id: entryId } });
  await recordAudit({ userId: user.id, action: "DELETE", entityType: "TimetableEntry", entityId: entryId });
  revalidatePath("/timetable");
}
