"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import type { CourseStatus } from "@prisma/client";

/**
 * Flips a course between AVAILABLE and RESTRICTED (spec §7, §45). This is
 * the exact mechanism that lets Core Mathematics go live later with no
 * source-code change — it is a single database update, gated to
 * Admin/Super Admin and fully audited.
 */
export async function setCourseStatus(courseId: string, status: CourseStatus) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN"]);

  const course = await prisma.course.findUniqueOrThrow({ where: { id: courseId } });

  const updated = await prisma.course.update({
    where: { id: courseId },
    data: { status },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Course",
    entityId: courseId,
    before: { status: course.status },
    after: { status: updated.status },
  });

  revalidatePath("/admin/courses");
  revalidatePath("/student");
}
