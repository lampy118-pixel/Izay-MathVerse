"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import type { AnnouncementAudience } from "@prisma/client";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

/**
 * Posts an announcement (spec §54) and fans out a Notification (spec §55)
 * to every matching student, computed from real enrollment/organization
 * data — never a guessed or approximate audience.
 */
export async function createAnnouncement(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();
  const audience = String(formData.get("audience") ?? "ALL_STUDENTS") as AnnouncementAudience;
  const organizationId = String(formData.get("organizationId") ?? "") || null;
  const classId = String(formData.get("classId") ?? "") || null;

  if (!title || !body) throw new Error("Title and body are required.");

  const announcement = await prisma.announcement.create({
    data: { title, body, audience, authorId: user.id, organizationId, classId },
  });

  let studentIds: string[] = [];
  if (audience === "CLASS" && classId) {
    const enrollments = await prisma.classStudent.findMany({ where: { classId }, select: { studentId: true } });
    studentIds = enrollments.map((e) => e.studentId);
  } else if (audience === "SCHOOL" && organizationId) {
    const students = await prisma.user.findMany({
      where: { role: "STUDENT", organizationId },
      select: { id: true },
    });
    studentIds = students.map((s) => s.id);
  } else {
    const students = await prisma.user.findMany({ where: { role: "STUDENT" }, select: { id: true } });
    studentIds = students.map((s) => s.id);
  }

  if (studentIds.length > 0) {
    await prisma.notification.createMany({
      data: studentIds.map((studentId) => ({
        userId: studentId,
        type: "ANNOUNCEMENT" as const,
        title,
        body,
        linkUrl: "/student/announcements",
      })),
    });
  }

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Announcement", entityId: announcement.id });
  revalidatePath("/announcements");
}

export async function markNotificationRead(notificationId: string) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN", "TEACHER", "STUDENT"]);
  await prisma.notification.updateMany({
    where: { id: notificationId, userId: user.id },
    data: { isRead: true },
  });
  revalidatePath("/student/notifications");
}
