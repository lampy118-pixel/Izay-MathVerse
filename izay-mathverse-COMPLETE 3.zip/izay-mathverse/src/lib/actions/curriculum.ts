"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

/**
 * Curriculum Import — implements spec §46 exactly:
 *   1. Teacher/Admin submits a structured payload (JSON for now; CSV/Excel
 *      parsers can be added later without changing this review flow).
 *   2. It is stored as a PENDING CurriculumImportBatch — nothing touches the
 *      live curriculum tree yet.
 *   3. An Import Preview screen renders the parsed structure for review.
 *   4. Only on explicit confirmation does confirmCurriculumImport() write
 *      real Strand/SubStrand/Topic/ContentStandard/LearningOutcome/
 *      LearningIndicator/Activity/AssessmentNote records, all scoped to a
 *      new CurriculumVersion (so re-imports never destroy history — §47).
 *
 * Expected JSON shape (one AcademicLevel):
 * {
 *   "level": { "name": "SHS 1", "code": "1" },
 *   "strands": [
 *     {
 *       "name": "Modelling with Algebra", "code": "1",
 *       "subStrands": [
 *         {
 *           "name": "Number and Algebraic Patterns", "code": "1",
 *           "topics": [
 *             {
 *               "name": "Binary Operations, Sets and Binomial Theorem",
 *               "learningOutcomes": [{ "code": "1.1.1.LO.1", "statement": "..." }],
 *               "contentStandards": [
 *                 {
 *                   "code": "1.1.1.CS.1", "statement": "...",
 *                   "learningIndicators": [
 *                     {
 *                       "code": "1.1.1.LI.1", "statement": "...",
 *                       "pedagogicalApproach": "...",
 *                       "activities": [{ "title": "...", "description": "..." }],
 *                       "assessmentNotes": [
 *                         { "code": "1.1.1.AS.1", "dokLevel": 1, "dokLabel": "Recall and Reproduction", "sampleItem": "..." }
 *                       ]
 *                     }
 *                   ]
 *                 }
 *               ]
 *             }
 *           ]
 *         }
 *       ]
 *     }
 *   ]
 * }
 */
export async function stageCurriculumImport(formData: FormData) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN", "TEACHER"]);

  const courseId = String(formData.get("courseId") ?? "");
  const rawPayload = String(formData.get("payload") ?? "");

  if (!courseId || !rawPayload.trim()) {
    throw new Error("A course and a curriculum payload are required.");
  }

  // Validate it's parseable JSON before staging — fail fast with a clear
  // error rather than storing garbage the preview screen can't render.
  try {
    JSON.parse(rawPayload);
  } catch {
    throw new Error("The submitted payload is not valid JSON.");
  }

  const batch = await prisma.curriculumImportBatch.create({
    data: {
      courseId,
      submittedById: user.id,
      sourceFormat: "JSON",
      rawPayload,
      status: "PENDING",
    },
  });

  await recordAudit({
    userId: user.id,
    action: "CREATE",
    entityType: "CurriculumImportBatch",
    entityId: batch.id,
  });

  redirect(`/curriculum/import/${batch.id}`);
}

interface ImportPayload {
  level: { name: string; code: string };
  strands: Array<{
    name: string;
    code: string;
    subStrands: Array<{
      name: string;
      code: string;
      topics: Array<{
        name: string;
        learningOutcomes?: Array<{ code: string; statement: string }>;
        contentStandards?: Array<{
          code: string;
          statement: string;
          learningIndicators?: Array<{
            code: string;
            statement: string;
            pedagogicalApproach?: string;
            activities?: Array<{ title: string; description: string }>;
            assessmentNotes?: Array<{
              code: string;
              dokLevel: number;
              dokLabel: string;
              sampleItem: string;
            }>;
          }>;
        }>;
      }>;
    }>;
  }>;
}

/**
 * Writes a PENDING batch's parsed structure into the live curriculum tree
 * inside a single transaction, under a fresh CurriculumVersion. Rejects
 * (does not delete) the batch on failure so the admin can see what was
 * attempted.
 */
export async function confirmCurriculumImport(batchId: string) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN", "TEACHER"]);

  const batch = await prisma.curriculumImportBatch.findUniqueOrThrow({
    where: { id: batchId },
  });

  if (batch.status !== "PENDING") {
    throw new Error("This import batch has already been reviewed.");
  }

  const data = JSON.parse(batch.rawPayload) as ImportPayload;

  await prisma.$transaction(async (tx) => {
    const version = await tx.curriculumVersion.create({
      data: {
        courseId: batch.courseId,
        versionLabel: `Import ${new Date().toISOString().slice(0, 10)}`,
        isActive: true,
        sourceDocument: `Import batch ${batch.id}`,
      },
    });

    const level = await tx.academicLevel.create({
      data: {
        courseId: batch.courseId,
        curriculumVersionId: version.id,
        name: data.level.name,
        code: data.level.code,
      },
    });

    for (const [sIdx, strand] of data.strands.entries()) {
      const strandRow = await tx.strand.create({
        data: {
          academicLevelId: level.id,
          name: strand.name,
          code: strand.code,
          sortOrder: sIdx,
        },
      });

      for (const [ssIdx, subStrand] of strand.subStrands.entries()) {
        const subStrandRow = await tx.subStrand.create({
          data: {
            strandId: strandRow.id,
            name: subStrand.name,
            code: subStrand.code,
            sortOrder: ssIdx,
          },
        });

        for (const [tIdx, topic] of subStrand.topics.entries()) {
          const topicRow = await tx.topic.create({
            data: {
              subStrandId: subStrandRow.id,
              name: topic.name,
              sortOrder: tIdx,
            },
          });

          for (const [loIdx, lo] of (topic.learningOutcomes ?? []).entries()) {
            await tx.learningOutcome.create({
              data: {
                topicId: topicRow.id,
                code: lo.code,
                statement: lo.statement,
                sortOrder: loIdx,
              },
            });
          }

          for (const [csIdx, cs] of (topic.contentStandards ?? []).entries()) {
            const csRow = await tx.contentStandard.create({
              data: {
                topicId: topicRow.id,
                code: cs.code,
                statement: cs.statement,
                sortOrder: csIdx,
              },
            });

            for (const [liIdx, li] of (cs.learningIndicators ?? []).entries()) {
              const liRow = await tx.learningIndicator.create({
                data: {
                  contentStandardId: csRow.id,
                  code: li.code,
                  statement: li.statement,
                  pedagogicalApproach: li.pedagogicalApproach,
                  sortOrder: liIdx,
                },
              });

              for (const [aIdx, activity] of (li.activities ?? []).entries()) {
                await tx.activity.create({
                  data: {
                    learningIndicatorId: liRow.id,
                    title: activity.title,
                    description: activity.description,
                    sortOrder: aIdx,
                  },
                });
              }

              for (const note of li.assessmentNotes ?? []) {
                await tx.assessmentNote.create({
                  data: {
                    learningIndicatorId: liRow.id,
                    code: note.code,
                    dokLevel: note.dokLevel,
                    dokLabel: note.dokLabel,
                    sampleItem: note.sampleItem,
                  },
                });
              }
            }
          }
        }
      }
    }

    await tx.curriculumImportBatch.update({
      where: { id: batch.id },
      data: { status: "CONFIRMED", reviewedAt: new Date() },
    });
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "CurriculumImportBatch",
    entityId: batch.id,
    after: { status: "CONFIRMED" },
  });

  revalidatePath("/curriculum");
  redirect(`/curriculum/${batch.courseId}`);
}

export async function rejectCurriculumImport(batchId: string) {
  const user = await requireRole(["SUPER_ADMIN", "ADMIN", "TEACHER"]);

  await prisma.curriculumImportBatch.update({
    where: { id: batchId },
    data: { status: "REJECTED", reviewedAt: new Date() },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "CurriculumImportBatch",
    entityId: batchId,
    after: { status: "REJECTED" },
  });

  revalidatePath("/curriculum/import");
  redirect("/curriculum");
}
