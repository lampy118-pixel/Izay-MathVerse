"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";
import type { AttendanceStatus } from "@prisma/client";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

/**
 * Saves a full day's attendance for a class in one submission — the form
 * posts one status field per enrolled student (`status_<studentId>`).
 * Upserts against the (classId, studentId, date) unique constraint so
 * re-saving the same day corrects rather than duplicates records.
 */
export async function saveAttendance(classId: string, dateStr: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const date = new Date(dateStr);
  const enrollments = await prisma.classStudent.findMany({ where: { classId } });

  for (const enrollment of enrollments) {
    const status = formData.get(`status_${enrollment.studentId}`);
    if (!status) continue;

    await prisma.attendance.upsert({
      where: { classId_studentId_date: { classId, studentId: enrollment.studentId, date } },
      update: { status: status as AttendanceStatus, takenById: user.id },
      create: {
        classId,
        studentId: enrollment.studentId,
        date,
        status: status as AttendanceStatus,
        takenById: user.id,
      },
    });
  }

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Attendance",
    entityId: classId,
    after: { date: dateStr },
  });

  revalidatePath(`/attendance/${classId}`);
}
