"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

/**
 * Adds a course-level resource not tied to a specific lesson — used for
 * WASSCE Preparation (past questions, mock tests, revision notes, worked
 * solutions — spec §41) and general downloadable materials (spec §58).
 * The `category` free-text field lets a teacher label what kind of
 * resource it is without a schema migration for a fixed category enum.
 */
export async function addCourseMaterial(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const courseId = String(formData.get("courseId") ?? "");
  const title = String(formData.get("title") ?? "").trim();
  const fileUrl = String(formData.get("fileUrl") ?? "").trim();
  const fileType = String(formData.get("fileType") ?? "OTHER") as
    | "PDF" | "PPT" | "PPTX" | "DOC" | "DOCX" | "IMAGE" | "WORKSHEET" | "WORKED_SOLUTION" | "OTHER";

  if (!courseId || !title || !fileUrl) {
    throw new Error("Course, title, and file URL are required.");
  }

  await prisma.lessonMaterial.create({
    data: { courseId, title, fileUrl, fileType, uploadedById: user.id },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "LessonMaterial" });
  revalidatePath("/wassce");
  revalidatePath("/student/wassce");
  revalidatePath("/student/downloads");
}
