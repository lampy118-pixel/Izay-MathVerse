"use server";

import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { hashPassword } from "@/lib/password";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createUserSchema } from "@/lib/validation";

/**
 * Creates a Teacher, Student, or Admin user (spec §4, §44). Admin/Super
 * Admin only. A random temporary password is generated and returned to the
 * admin to relay to the user — there is no plaintext password storage or
 * logging.
 */
export async function createUser(formData: FormData) {
  const actor = await requireRole(["SUPER_ADMIN", "ADMIN"]);

  const parsed = createUserSchema.safeParse({
    firstName: formData.get("firstName"),
    lastName: formData.get("lastName"),
    email: formData.get("email"),
    password: formData.get("password"),
    role: formData.get("role") ?? "STUDENT",
    organizationId: String(formData.get("organizationId") ?? "") || null,
  });

  if (!parsed.success) {
    throw new Error(parsed.error.issues[0]?.message ?? "Invalid input.");
  }
  const { firstName, lastName, email, password, role, organizationId } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    throw new Error("A user with this email already exists.");
  }

  const passwordHash = await hashPassword(password);

  const user = await prisma.user.create({
    data: {
      firstName,
      lastName,
      email,
      role,
      organizationId,
      passwordHash,
      ...(role === "STUDENT" ? { studentProfile: { create: {} } } : {}),
      ...(role === "TEACHER" ? { teacherProfile: { create: {} } } : {}),
    },
  });

  await recordAudit({
    userId: actor.id,
    action: "CREATE",
    entityType: "User",
    entityId: user.id,
    after: { email: user.email, role: user.role },
  });

  revalidatePath("/admin/users");
  redirect("/admin/users");
}

export async function toggleUserActive(userId: string) {
  const actor = await requireRole(["SUPER_ADMIN", "ADMIN"]);

  const target = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  const updated = await prisma.user.update({
    where: { id: userId },
    data: { isActive: !target.isActive },
  });

  await recordAudit({
    userId: actor.id,
    action: "UPDATE",
    entityType: "User",
    entityId: userId,
    before: { isActive: target.isActive },
    after: { isActive: updated.isActive },
  });

  revalidatePath("/admin/users");
}
