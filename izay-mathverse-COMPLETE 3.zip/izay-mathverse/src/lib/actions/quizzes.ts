"use server";

import { prisma } from "@/lib/prisma";
import { requireRole, assertOwnRecord } from "@/lib/rbac";
import { recordAudit } from "@/lib/audit";
import { gradeAnswer } from "@/lib/grading";
import { findGradeForPercentage } from "@/lib/grade-lookup";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { LessonStatus } from "@prisma/client";

const STAFF_ROLES = ["SUPER_ADMIN", "ADMIN", "TEACHER"] as const;

interface SnapshotQuestion {
  questionId: string;
  questionText: string;
  imageUrl: string | null;
  type: string;
  marks: number;
  options: Array<{ id: string; text: string }>;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// --- Teacher/Admin: quiz management ---

export async function createQuiz(formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  const courseId = String(formData.get("courseId") ?? "");
  const title = String(formData.get("title") ?? "").trim();
  if (!courseId || !title) throw new Error("A course and title are required.");

  const quiz = await prisma.quiz.create({
    data: {
      courseId,
      title,
      authorId: user.id,
      numberOfQuestions: Number(formData.get("numberOfQuestions") ?? 5) || 5,
      totalMarks: Number(formData.get("totalMarks") ?? 5) || 5,
      durationMinutes: Number(formData.get("durationMinutes") ?? 15) || 15,
      attemptsAllowed: Number(formData.get("attemptsAllowed") ?? 1) || 1,
      status: "DRAFT",
    },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "Quiz", entityId: quiz.id });
  redirect(`/quizzes/${quiz.id}/edit`);
}

export async function updateQuizSettings(quizId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);

  await prisma.quiz.update({
    where: { id: quizId },
    data: {
      title: String(formData.get("title") ?? "").trim(),
      description: String(formData.get("description") ?? "") || null,
      numberOfQuestions: Number(formData.get("numberOfQuestions") ?? 5) || 5,
      totalMarks: Number(formData.get("totalMarks") ?? 5) || 5,
      durationMinutes: Number(formData.get("durationMinutes") ?? 15) || 15,
      attemptsAllowed: Number(formData.get("attemptsAllowed") ?? 1) || 1,
      randomSelection: formData.get("randomSelection") === "on",
      shuffleQuestions: formData.get("shuffleQuestions") === "on",
      shuffleOptions: formData.get("shuffleOptions") === "on",
      hintsEnabled: formData.get("hintsEnabled") === "on",
      solutionsEnabled: formData.get("solutionsEnabled") === "on",
      resultVisibility: String(formData.get("resultVisibility") ?? "AFTER_SUBMISSION") as never,
    },
  });

  await recordAudit({ userId: user.id, action: "UPDATE", entityType: "Quiz", entityId: quizId });
  revalidatePath(`/quizzes/${quizId}/edit`);
}

export async function setQuizStatus(quizId: string, status: LessonStatus) {
  const user = await requireRole([...STAFF_ROLES]);
  await prisma.quiz.update({ where: { id: quizId }, data: { status } });
  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "Quiz",
    entityId: quizId,
    after: { status },
  });
  revalidatePath(`/quizzes/${quizId}/edit`);
}

export async function addQuizQuestion(quizId: string, formData: FormData) {
  const user = await requireRole([...STAFF_ROLES]);
  const questionId = String(formData.get("questionId") ?? "");
  if (!questionId) throw new Error("Select a question to add.");

  const count = await prisma.quizQuestion.count({ where: { quizId } });
  await prisma.quizQuestion.create({
    data: { quizId, questionId, sortOrder: count },
  });

  await recordAudit({ userId: user.id, action: "CREATE", entityType: "QuizQuestion" });
  revalidatePath(`/quizzes/${quizId}/edit`);
}

export async function removeQuizQuestion(quizId: string, quizQuestionId: string) {
  const user = await requireRole([...STAFF_ROLES]);
  await prisma.quizQuestion.delete({ where: { id: quizQuestionId } });
  await recordAudit({ userId: user.id, action: "DELETE", entityType: "QuizQuestion" });
  revalidatePath(`/quizzes/${quizId}/edit`);
}

// --- Student: taking a quiz ---

/**
 * Starts a new attempt: builds and freezes a question-set snapshot (spec
 * §33-35) so later edits or deletions to the underlying Question never
 * change what a student already sees or already submitted. Enforces the
 * attempts-allowed limit and the open/close date window server-side.
 */
export async function startQuizAttempt(quizId: string) {
  const user = await requireRole(["STUDENT"]);

  const quiz = await prisma.quiz.findUniqueOrThrow({
    where: { id: quizId },
    include: { quizQuestions: { include: { question: { include: { options: true } } } } },
  });

  if (quiz.status !== "PUBLISHED" && quiz.status !== "ACTIVE") {
    throw new Error("This quiz is not currently open.");
  }
  const now = new Date();
  if (quiz.startDate && now < quiz.startDate) throw new Error("This quiz has not opened yet.");
  if (quiz.endDate && now > quiz.endDate) throw new Error("This quiz has closed.");

  const priorAttempts = await prisma.quizAttempt.count({
    where: { quizId, studentId: user.id },
  });
  if (priorAttempts >= quiz.attemptsAllowed) {
    throw new Error("You have used all your allowed attempts for this quiz.");
  }

  let pool = quiz.quizQuestions.map((qq) => qq.question);
  if (quiz.randomSelection) {
    pool = shuffle(pool).slice(0, quiz.numberOfQuestions);
  } else {
    pool = pool.slice(0, quiz.numberOfQuestions);
  }
  if (quiz.shuffleQuestions) pool = shuffle(pool);

  const snapshot: SnapshotQuestion[] = pool.map((q) => ({
    questionId: q.id,
    questionText: q.questionText,
    imageUrl: q.imageUrl,
    type: q.type,
    marks: q.marks,
    options: (quiz.shuffleOptions ? shuffle(q.options) : q.options).map((o) => ({
      id: o.id,
      text: o.text,
    })),
  }));

  const attempt = await prisma.quizAttempt.create({
    data: {
      quizId,
      studentId: user.id,
      questionSetSnapshot: JSON.stringify(snapshot),
      maxScore: snapshot.reduce((sum, q) => sum + q.marks, 0),
    },
  });

  redirect(`/student/quizzes/attempt/${attempt.id}`);
}

/**
 * Grades and submits an attempt (spec §31, §36). Grading reads the LIVE
 * Question record (for correctAnswer/isCorrect) but display data comes
 * from the frozen snapshot — so if a question is edited after this
 * attempt starts but before it's submitted, the student still sees what
 * was originally shown, while grading reflects answer-checking logic as
 * of submission time. Once submitted, the score is stored and never
 * recomputed, so later edits/deletions never retroactively change it.
 */
export async function submitQuizAttempt(attemptId: string, formData: FormData) {
  const user = await requireRole(["STUDENT"]);

  const attempt = await prisma.quizAttempt.findUniqueOrThrow({
    where: { id: attemptId },
    include: { quiz: true },
  });
  assertOwnRecord(user.id, attempt.studentId);

  if (attempt.submittedAt) {
    redirect(`/student/quizzes/attempt/${attemptId}/result`);
  }

  // Server-side deadline enforcement (closes the Phase 6 gap: the client
  // timer alone is not a security boundary — spec §50). A grace window
  // absorbs normal network/render latency around the exact cutoff without
  // opening a meaningful cheating window.
  const GRACE_MS = 30_000;
  const deadline = attempt.startedAt.getTime() + attempt.quiz.durationMinutes * 60_000 + GRACE_MS;
  if (Date.now() > deadline) {
    await prisma.quizAttempt.update({
      where: { id: attemptId },
      data: { submittedAt: new Date(), score: 0 },
    });
    await recordAudit({
      userId: user.id,
      action: "UPDATE",
      entityType: "QuizAttempt",
      entityId: attemptId,
      after: { autoSubmittedLate: true },
    });
    redirect(`/student/quizzes/attempt/${attemptId}/result`);
  }

  const snapshot: SnapshotQuestion[] = JSON.parse(attempt.questionSetSnapshot);
  let score = 0;

  for (const item of snapshot) {
    const answer = String(formData.get(`answer_${item.questionId}`) ?? "");
    const liveQuestion = await prisma.question.findUnique({
      where: { id: item.questionId },
      include: { options: true },
    });
    if (!liveQuestion) continue; // deleted since attempt started — skip, can't grade
    const { marksAwarded } = gradeAnswer(liveQuestion, answer);
    score += marksAwarded ?? 0;
  }

  await prisma.quizAttempt.update({
    where: { id: attemptId },
    data: { submittedAt: new Date(), score },
  });

  const maxScore = attempt.maxScore ?? snapshot.reduce((s, q) => s + q.marks, 0);
  const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0;
  const grade = await findGradeForPercentage(percentage);

  await prisma.result.create({
    data: {
      studentId: user.id,
      assessmentType: "QUIZ",
      assessmentRefId: attempt.quizId,
      title: attempt.quiz.title,
      score,
      maxScore,
      percentage,
      gradeId: grade?.id,
    },
  });

  await recordAudit({
    userId: user.id,
    action: "UPDATE",
    entityType: "QuizAttempt",
    entityId: attemptId,
    after: { score, submitted: true },
  });

  redirect(`/student/quizzes/attempt/${attemptId}/result`);
}
