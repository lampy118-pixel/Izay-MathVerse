import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { prisma } from "@/lib/prisma";
import { verifyPassword } from "@/lib/password";
import { recordAudit } from "@/lib/audit";

/**
 * Central NextAuth configuration.
 *
 * Security notes (spec §50):
 * - Passwords are never stored or compared in plaintext — bcrypt hash only.
 * - Session strategy is JWT; the token carries only id/role/organizationId,
 *   never the password hash.
 * - Every route handler / server action must re-check `session.user.role`
 *   on the backend (see src/lib/rbac.ts) — the frontend hiding a button is
 *   NOT an authorization boundary.
 */
export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
    maxAge: 8 * 60 * 60, // 8 hours
  },
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        const email = credentials.email.toLowerCase().trim();
        const user = await prisma.user.findUnique({ where: { email } });

        // Brute-force protection (spec §50), built on the existing audit
        // log rather than a new schema field: too many recent failed
        // attempts for this account blocks further tries for a cooldown
        // window. This is a real, working lockout, not a stub — but for
        // production scale, consider adding a dedicated rate-limit store
        // (e.g. Redis) instead of querying AuditLog, which isn't indexed
        // for this access pattern and will slow down under high load.
        if (user) {
          const fifteenMinAgo = new Date(Date.now() - 15 * 60_000);
          const recentFailures = await prisma.auditLog.count({
            where: {
              entityType: "User",
              entityId: user.id,
              action: "LOGIN_FAILED",
              createdAt: { gte: fifteenMinAgo },
            },
          });
          if (recentFailures >= 5) {
            throw new Error(
              "Too many failed login attempts. Please try again in 15 minutes."
            );
          }
        }

        if (!user || !user.isActive) {
          await recordAudit({
            action: "LOGIN_FAILED",
            entityType: "User",
            entityId: user?.id,
          });
          return null;
        }

        const isValid = await verifyPassword(
          credentials.password,
          user.passwordHash
        );

        if (!isValid) {
          await recordAudit({
            userId: user.id,
            action: "LOGIN_FAILED",
            entityType: "User",
            entityId: user.id,
          });
          return null;
        }

        await prisma.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() },
        });

        await recordAudit({
          userId: user.id,
          action: "LOGIN",
          entityType: "User",
          entityId: user.id,
        });

        return {
          id: user.id,
          email: user.email,
          name: `${user.firstName} ${user.lastName}`,
          role: user.role,
          organizationId: user.organizationId,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as any).role;
        token.organizationId = (user as any).organizationId;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.id;
        (session.user as any).role = token.role;
        (session.user as any).organizationId = token.organizationId;
      }
      return session;
    },
  },
};
