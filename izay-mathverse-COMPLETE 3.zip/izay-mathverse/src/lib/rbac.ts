import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import type { GlobalRole } from "@prisma/client";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: GlobalRole;
  organizationId: string | null;
}

/**
 * Retrieves the current server-side session user, or null if unauthenticated.
 * Use this in Server Components, Route Handlers, and Server Actions.
 */
export async function getSessionUser(): Promise<SessionUser | null> {
  const session = await getServerSession(authOptions);
  if (!session?.user) return null;
  return session.user as unknown as SessionUser;
}

/**
 * Throws if there is no authenticated user, or the user's role is not in
 * `roles`. This is the backend authorization boundary referenced throughout
 * the spec (§50: "Every sensitive operation must be authorized on the
 * backend"). Route handlers and server actions must call this — hiding a
 * button on the frontend is never sufficient on its own.
 */
export async function requireRole(
  roles: GlobalRole[]
): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) {
    throw new AuthError("UNAUTHENTICATED", "You must be signed in.");
  }
  if (!roles.includes(user.role)) {
    throw new AuthError(
      "FORBIDDEN",
      `This action requires one of these roles: ${roles.join(", ")}.`
    );
  }
  return user;
}

export class AuthError extends Error {
  code: "UNAUTHENTICATED" | "FORBIDDEN";
  constructor(code: "UNAUTHENTICATED" | "FORBIDDEN", message: string) {
    super(message);
    this.code = code;
    this.name = "AuthError";
  }
}

/**
 * Ensures a student can only ever act on their own records (spec §50:
 * "Students must only access their own private information.").
 */
export function assertOwnRecord(sessionUserId: string, ownerId: string) {
  if (sessionUserId !== ownerId) {
    throw new AuthError(
      "FORBIDDEN",
      "You do not have permission to access this record."
    );
  }
}
