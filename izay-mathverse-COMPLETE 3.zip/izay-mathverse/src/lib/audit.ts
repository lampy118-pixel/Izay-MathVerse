import { prisma } from "@/lib/prisma";

interface AuditParams {
  userId?: string | null;
  action: "CREATE" | "UPDATE" | "DELETE" | "LOGIN" | "LOGIN_FAILED" | "LOGOUT";
  entityType: string;
  entityId?: string;
  before?: unknown;
  after?: unknown;
  ipAddress?: string | null;
}

/**
 * Records an audit log entry (spec §60). Call this from every sensitive
 * backend mutation — never rely on the frontend to report what happened.
 * Failures to write an audit log are swallowed (logged to console) so a
 * logging outage never blocks the underlying user action.
 */
export async function recordAudit(params: AuditParams): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId ?? null,
        action: params.action,
        entityType: params.entityType,
        entityId: params.entityId,
        beforeData: params.before ? JSON.stringify(params.before) : undefined,
        afterData: params.after ? JSON.stringify(params.after) : undefined,
        ipAddress: params.ipAddress ?? undefined,
      },
    });
  } catch (err) {
    console.error("Failed to write audit log", err);
  }
}
