import { prisma } from "@/lib/prisma";

/**
 * Finds the configured Grade boundary a percentage falls into (spec §38:
 * "no GPA... make grade boundaries configurable"). Boundaries live in the
 * database (seeded in prisma/seed.ts) and are editable there — never
 * hard-coded here.
 */
export async function findGradeForPercentage(percentage: number) {
  return prisma.grade.findFirst({
    where: {
      minPercentage: { lte: percentage },
      maxPercentage: { gte: percentage },
    },
  });
}
