import type { GlobalRole } from "@prisma/client";
import type { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: GlobalRole;
      organizationId: string | null;
    } & DefaultSession["user"];
  }

  interface User {
    id: string;
    role: GlobalRole;
    organizationId: string | null;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    role: GlobalRole;
    organizationId: string | null;
  }
}
