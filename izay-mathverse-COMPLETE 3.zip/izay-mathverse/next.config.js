/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**" },
    ],
  },
  // Security headers (spec §50). CSP is intentionally not set here — this
  // app embeds third-party iframes (YouTube, GeoGebra, Desmos per Phase 3)
  // whose exact origins vary by what teachers add, so a safe default CSP
  // needs to be authored against your actual deployed content rather than
  // guessed at here. Add one before production use; see docs/SECURITY.md.
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
